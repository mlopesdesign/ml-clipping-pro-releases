/* ML Clipping Pro — site: "Carregar mais", filtros que enviam ao mudar e fotos quebradas. */
(function () {
	'use strict';
	var CFG = window.MLCLIP_FRONT || {};

	// Foto que não carrega (link quebrado no veículo): vira o quadro com o nome do veículo — nunca um espaço vazio.
	function placeholder(name) {
		var ph = document.createElement('span');
		ph.className = 'mlclip-ph';
		var r1 = document.createElement('span'); r1.className = 'mlclip-ph-rule';
		var n = document.createElement('span'); n.className = 'mlclip-ph-name'; n.textContent = name || 'Clipping';
		var r2 = document.createElement('span'); r2.className = 'mlclip-ph-rule';
		ph.appendChild(r1); ph.appendChild(n); ph.appendChild(r2);
		return ph;
	}
	// O nome do veículo nunca é quebrado no meio da palavra: se não couber, o corpo diminui.
	function fit(root) {
		Array.prototype.forEach.call(root.querySelectorAll('.mlclip-ph-name'), function (n) {
			// Começa grande (proporcional ao quadro) e diminui até caber sem quebrar palavra.
			var box = n.parentNode ? n.parentNode.clientWidth : 0;
			var size = box ? Math.round(Math.min(30, Math.max(14, box / 9))) : 20, guard = 0;
			n.style.fontSize = size + 'px';
			var maxH = n.parentNode ? n.parentNode.clientHeight * 0.62 : 0;
			while ((n.scrollWidth > n.clientWidth + 1 || (maxH && n.offsetHeight > maxH)) && size > 11 && guard < 30) {
				size -= 1; guard++;
				n.style.fontSize = size + 'px';
			}
		});
	}
	function hideBroken(root) {
		Array.prototype.forEach.call(root.querySelectorAll('.mlclip-fig img'), function (img) {
			function swap() {
				var fig = img.closest('.mlclip-fig');
				if (!fig || fig.querySelector('.mlclip-ph')) { return; }
				var ph = placeholder(fig.getAttribute('data-outlet'));
				img.replaceWith(ph);
				fit(ph);
			}
			if (img.complete && img.naturalWidth === 0) { swap(); } else { img.addEventListener('error', swap); }
		});
	}

	// Mesma regra do servidor: as matérias da última linha dividem a largura toda.
	function spans(n, cols) {
		var out = [], r = cols > 1 ? n % cols : 0, i;
		for (i = 0; i < n; i++) { out.push(1); }
		if (r > 0) {
			var base = Math.floor(cols / r), extra = cols % r;
			for (i = 0; i < r; i++) { out[n - r + i] = base + (i < extra ? 1 : 0); }
		}
		return out;
	}
	function relayout(grid, cols) {
		var items = grid.querySelectorAll(':scope > .mlclip-item');
		var l = spans(items.length, cols), m = spans(items.length, Math.min(2, cols));
		Array.prototype.forEach.call(items, function (it, i) {
			it.style.setProperty('--sl', l[i]);
			it.style.setProperty('--sm', m[i]);
			it.classList.toggle('w-l', l[i] > 1);
			it.classList.toggle('w-m', m[i] > 1);
		});
	}

	function merge(paper, html) {
		var holder = document.createElement('div');
		holder.innerHTML = html;
		var target = paper.querySelector('.mlclip-sections');
		Array.prototype.forEach.call(holder.querySelectorAll('.mlclip-sec'), function (sec) {
			var key = sec.getAttribute('data-key');
			var last = target.querySelector('.mlclip-sec:last-of-type');
			if (last && last.getAttribute('data-key') === key) {
				var grid = last.querySelector('.mlclip-grid');
				Array.prototype.forEach.call(sec.querySelectorAll('.mlclip-item'), function (it) { grid.appendChild(it); });
				relayout(grid, parseInt(paper.getAttribute('data-cols'), 10) || 3);
			} else {
				target.appendChild(sec);
			}
		});
		hideBroken(paper);
		fit(paper);
	}

	function init(paper) {
		hideBroken(paper);
		fit(paper);
		var t;
		window.addEventListener('resize', function () { clearTimeout(t); t = setTimeout(function () { fit(paper); }, 150); });
		var data = {};
		try { data = JSON.parse(paper.getAttribute('data-mlclip') || '{}'); } catch (e) { data = {}; }

		var form = paper.querySelector('.mlclip-filters');
		if (form) {
			Array.prototype.forEach.call(form.querySelectorAll('select'), function (s) {
				s.addEventListener('change', function () { form.submit(); });
			});
		}

		var btn = paper.querySelector('.mlclip-more-btn');
		if (!btn || !window.fetch) { return; }
		btn.addEventListener('click', function (e) {
			e.preventDefault();
			var page = parseInt(btn.getAttribute('data-page'), 10) || 2;
			btn.classList.add('is-loading');
			btn.textContent = CFG.loading;
			var body = new FormData();
			body.append('action', 'mlclip_more');
			body.append('page', page);
			body.append('atts', JSON.stringify(data.atts || {}));
			body.append('filters', JSON.stringify(data.filters || {}));
			fetch(CFG.ajax, { method: 'POST', credentials: 'same-origin', body: body })
				.then(function (r) { return r.json(); })
				.then(function (res) {
					if (!res || !res.success) { throw new Error('x'); }
					merge(paper, res.data.html || '');
					if (res.data.more) {
						btn.setAttribute('data-page', page + 1);
						btn.classList.remove('is-loading');
						btn.textContent = CFG.more;
					} else {
						var wrap = btn.closest('.mlclip-more');
						if (wrap) { wrap.remove(); }
					}
				})
				.catch(function () {
					btn.classList.remove('is-loading');
					btn.textContent = CFG.error;
				});
		});
	}

	function start() { Array.prototype.forEach.call(document.querySelectorAll('.mlclip-paper'), init); }
	if (document.readyState !== 'loading') { start(); } else { document.addEventListener('DOMContentLoaded', start); }
})();
