/* ML Clipping Pro — painel. */
(function () {
	'use strict';
	var CFG = window.MLCLIP_ADMIN || {};
	var T = CFG.i18n || {};

	function ready(fn) { if (document.readyState !== 'loading') { fn(); } else { document.addEventListener('DOMContentLoaded', fn); } }
	function $all(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

	function toast(message, type) {
		var area = document.getElementById('mlclip-toast-area');
		if (!area || !message) { return; }
		var el = document.createElement('div');
		el.className = 'mlclip-toast mlclip-toast-' + (type || 'success');
		el.setAttribute('role', type === 'error' ? 'alert' : 'status');
		el.textContent = message;
		area.appendChild(el);
		requestAnimationFrame(function () { el.classList.add('is-visible'); });
		setTimeout(function () { el.classList.remove('is-visible'); setTimeout(function () { el.remove(); }, 240); }, type === 'error' || type === 'warning' ? 7500 : 4200);
	}

	function post(data) {
		var body = new FormData();
		body.append('nonce', CFG.nonce);
		Object.keys(data).forEach(function (k) {
			var v = data[k];
			if (Array.isArray(v)) { v.forEach(function (x) { body.append(k + '[]', x); }); } else { body.append(k, v); }
		});
		return fetch(CFG.ajax, { method: 'POST', credentials: 'same-origin', body: body }).then(function (r) {
			return r.text().then(function (text) {
				var json;
				try { json = JSON.parse(text); } catch (e) { throw new Error(T.error); }
				if (!json || !json.success) { throw new Error((json && json.data && json.data.message) || T.error); }
				return json.data;
			});
		});
	}

	/* ------------------------------------------------------------ Copiar */
	function copy(text) {
		var done = function () { toast(T.copied, 'success'); };
		if (navigator.clipboard && window.isSecureContext) {
			navigator.clipboard.writeText(text).then(done).catch(function () { fallback(text) ? done() : toast(T.copyFail, 'error'); });
		} else if (fallback(text)) { done(); } else { toast(T.copyFail, 'error'); }
	}
	function fallback(text) {
		var ta = document.createElement('textarea');
		ta.value = text; ta.setAttribute('readonly', ''); ta.style.position = 'fixed'; ta.style.opacity = '0';
		document.body.appendChild(ta); ta.select();
		var ok = false;
		try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
		ta.remove();
		return ok;
	}

	/* ------------------------------------------------------------ Máscara de data */
	function maskDate(v) {
		v = v.replace(/\D/g, '').slice(0, 8);
		if (v.length > 4) { return v.slice(0, 2) + '/' + v.slice(2, 4) + '/' + v.slice(4); }
		if (v.length > 2) { return v.slice(0, 2) + '/' + v.slice(2); }
		return v;
	}

	/* ------------------------------------------------------------ Barra de andamento */
	function progress(box, pct, text, indeterminate) {
		if (!box) { return; }
		box.hidden = false;
		box.classList.toggle('is-indeterminate', !!indeterminate);
		var bar = box.querySelector('.mlclip-progress-bar span');
		if (bar && !indeterminate) { bar.style.width = Math.max(3, Math.min(100, pct)) + '%'; }
		var p = box.querySelector('.mlclip-progress-text');
		if (p) { p.textContent = text || ''; }
		return p;
	}

	/* ------------------------------------------------------------ Buscar agora */
	function runner() {
		var card = document.getElementById('mlclip-runner');
		if (!card) { return; }
		var btn = card.querySelector('[data-run]');
		var box = card.querySelector('.mlclip-progress');
		var running = false;

		function loop(op) {
			post({ action: 'mlclip_run', op: op }).then(function (res) {
				if (res.busy) {
					progress(box, 0, T.busy, true);
					setTimeout(function () { loop('step'); }, 4000);
					return;
				}
				if (res.done) {
					running = false;
					btn.disabled = false;
					var p = progress(box, 100, res.message || '', false);
					if (res.pending > 0 && p) {
						var a = document.createElement('a');
						a.href = CFG.review; a.className = 'mlclip-ab mlclip-ab-sm'; a.textContent = T.goReview + ' (' + res.pending + ')';
						p.appendChild(a);
					}
					toast(res.message, res.errors && res.errors.length ? 'warning' : 'success');
					return;
				}
				var pct;
				if (res.phase === 'collect') {
					pct = res.total ? ((res.total - res.names) / res.total) * 30 : 10;
				} else {
					var done = res.stats ? res.stats.analysed : 0;
					pct = 30 + (done / Math.max(1, done + res.left)) * 70;
				}
				progress(box, pct, res.message, false);
				loop('step');
			}).catch(function (err) {
				running = false;
				btn.disabled = false;
				progress(box, 0, err.message, false);
				toast(err.message, 'error');
			});
		}

		btn.addEventListener('click', function () {
			if (running) { return; }
			running = true;
			btn.disabled = true;
			progress(box, 2, T.starting, true);
			loop('start');
		});

		// Rodada já em andamento (ex.: recarregou a página): continua mostrando.
		post({ action: 'mlclip_run_status' }).then(function (res) {
			if (res.running && !running) {
				running = true; btn.disabled = true;
				progress(box, 5, T.busy, true);
				loop('step');
			}
		}).catch(function () {});
	}

	/* ------------------------------------------------------------ Revisão */
	function review() {
		var form = document.querySelector('.mlclip-review-form');
		if (!form) { return; }
		var all = form.querySelector('[data-check-all]');
		var count = form.querySelector('[data-bulk-count]');
		function boxes() { return $all('input[name="ids[]"]', form); }
		function sync() {
			var n = 0;
			boxes().forEach(function (b) {
				var card = b.closest('.mlclip-rv');
				if (card) { card.classList.toggle('is-checked', b.checked); }
				if (b.checked) { n++; }
			});
			if (count) { count.textContent = n ? n + ' ✓' : ''; }
		}
		if (all) {
			all.addEventListener('change', function () { boxes().forEach(function (b) { b.checked = all.checked; }); sync(); });
		}
		form.addEventListener('change', function (e) { if (e.target.name === 'ids[]') { sync(); } });
		form.addEventListener('submit', function (e) {
			if (!boxes().some(function (b) { return b.checked; })) { e.preventDefault(); toast(T.pickSome, 'warning'); return; }
			var sub = e.submitter;
			if (sub && sub.getAttribute('data-confirm-click') && !window.confirm(sub.getAttribute('data-confirm-click'))) { e.preventDefault(); }
		});

		form.addEventListener('click', function (e) {
			var btn = e.target.closest('[data-review]');
			if (!btn) { return; }
			if (btn.getAttribute('data-confirm-click') && !window.confirm(btn.getAttribute('data-confirm-click'))) { return; }
			var card = btn.closest('.mlclip-rv');
			var op = btn.getAttribute('data-review');
			$all('button', card).forEach(function (b) { b.disabled = true; });
			post({ action: 'mlclip_review', id: card.getAttribute('data-id'), op: op }).then(function (res) {
				toast(res.message, 'success');
				card.classList.add('is-leaving');
				setTimeout(function () {
					card.remove();
					sync();
					updateBadges(res.pending);
					if (!form.querySelector('.mlclip-rv')) {
						var list = form.querySelector('.mlclip-review-list');
						list.innerHTML = '<div class="mlclip-empty-state"><p></p></div>';
						list.querySelector('p').textContent = T.queueEmpty;
					}
				}, 260);
			}).catch(function (err) {
				$all('button', card).forEach(function (b) { b.disabled = false; });
				toast(err.message, 'error');
			});
		});
	}

	function updateBadges(n) {
		$all('.mlclip-tab-count, #toplevel_page_ml-clipping-pro .pending-count, #wp-admin-bar-mlclip-pending .mlclip-ab-count').forEach(function (el) {
			if (n > 0) { el.textContent = n; } else {
				var wrap = el.closest('.awaiting-mod') || el;
				wrap.remove();
			}
		});
	}

	/* ------------------------------------------------------------ Preencher pelo link */
	function fetchLink() {
		var btn = document.querySelector('[data-fetch-link]');
		if (!btn) { return; }
		btn.addEventListener('click', function () {
			var url = document.getElementById('mlclip-url');
			if (!url || !url.value.trim()) { toast(T.needUrl, 'warning'); return; }
			btn.disabled = true;
			var label = btn.textContent;
			btn.textContent = T.fetching;
			post({ action: 'mlclip_fetch_link', url: url.value.trim() }).then(function (d) {
				function set(id, v) { var el = document.getElementById(id); if (el && v) { el.value = v; el.dispatchEvent(new Event('input', { bubbles: true })); } }
				if (d.url) { url.value = d.url; }
				set('mlclip-title', d.title);
				set('mlclip-outlet', d.outlet);
				set('mlclip-date', d.date_br);
				set('mlclip-excerpt', d.excerpt);
				set('mlclip-image', d.image);
				var media = document.getElementById('mlclip-media');
				if (media && d.media) { media.value = d.media; }
				preview();
				toast(d.dup ? T.filled + ' ⚠' : T.filled, d.dup ? 'warning' : 'success');
			}).catch(function (err) { toast(err.message, 'error'); }).then(function () {
				btn.disabled = false; btn.textContent = label;
			});
		});
		var img = document.getElementById('mlclip-image');
		function preview() {
			var box = document.querySelector('.mlclip-image-preview');
			if (!box || !img) { return; }
			box.innerHTML = '';
			if (/^https?:\/\//.test(img.value)) {
				var i = document.createElement('img');
				i.src = img.value; i.alt = ''; i.referrerPolicy = 'no-referrer';
				i.onerror = function () { i.remove(); };
				box.appendChild(i);
			}
		}
		if (img) { img.addEventListener('change', preview); }
	}

	/* ------------------------------------------------------------ Importar */
	function importer() {
		var card = document.getElementById('mlclip-importer');
		if (!card) { return; }
		var btn = card.querySelector('[data-import]');
		var box = card.querySelector('.mlclip-progress');
		function mode() { var r = card.querySelector('input[name="mlclip_imp_mode"]:checked'); return r ? r.value : 'page'; }
		card.addEventListener('change', function (e) {
			if (e.target.name === 'mlclip_imp_mode') {
				$all('.mlclip-imp-panel', card).forEach(function (p) { p.hidden = p.getAttribute('data-mode') !== mode(); });
			}
		});
		function step(total) {
			post({ action: 'mlclip_import', op: 'step' }).then(function (r) {
				var msg = r.done + ' / ' + total + ' · +' + r.added + ' · = ' + r.skipped + (r.failed ? ' · ✕ ' + r.failed : '');
				progress(box, (r.done / Math.max(1, total)) * 100, msg, false);
				if (r.finished) {
					btn.disabled = false;
					toast(msg, r.failed ? 'warning' : 'success');
					return;
				}
				step(total);
			}).catch(function (err) { btn.disabled = false; progress(box, 0, err.message, false); toast(err.message, 'error'); });
		}
		btn.addEventListener('click', function () {
			var names = $all('input[name="mlclip_imp_names[]"]:checked', card).map(function (c) { return c.value; });
			var data = {
				action: 'mlclip_import', op: 'prepare', mode: mode(),
				page_id: (document.getElementById('mlclip-imp-page') || {}).value || 0,
				url: (document.getElementById('mlclip-imp-url') || {}).value || '',
				list: (document.getElementById('mlclip-imp-list') || {}).value || '',
				status: (document.getElementById('mlclip-imp-status') || {}).value || 'publish',
				names: names
			};
			btn.disabled = true;
			progress(box, 2, T.importing, true);
			post(data).then(function (r) { progress(box, 3, '0 / ' + r.total, false); step(r.total); })
				.catch(function (err) { btn.disabled = false; progress(box, 0, err.message, false); toast(err.message, 'error'); });
		});
	}

	/* ------------------------------------------------------------ Reler matérias */
	function repair() {
		var card = document.getElementById('mlclip-repair');
		if (!card) { return; }
		var btn = card.querySelector('[data-repair]');
		var box = card.querySelector('.mlclip-progress');
		function msg(r, total) {
			return r.done + ' / ' + total + ' · ' + T.repFixed + ' ' + r.fixed + ' · ' + T.repDown + ' ' + r.down + ' · ' + T.repNodate + ' ' + r.nodate;
		}
		function done(r, total) {
			btn.disabled = false;
			progress(box, 100, total ? msg(r, total) : T.repNone, false);
			toast(total ? msg(r, total) : T.repNone, 'success');
		}
		function step(total) {
			post({ action: 'mlclip_repair', op: 'step' }).then(function (r) {
				progress(box, (r.done / Math.max(1, total)) * 100, msg(r, total), false);
				if (r.finished) { done(r, total); return; }
				step(total);
			}).catch(function (err) { btn.disabled = false; progress(box, 0, err.message, false); toast(err.message, 'error'); });
		}
		btn.addEventListener('click', function () {
			var un = document.getElementById('mlclip-rep-unpublish');
			btn.disabled = true;
			progress(box, 2, T.reading, true);
			post({ action: 'mlclip_repair', op: 'prepare', unpublish: un && un.checked ? 1 : 0 }).then(function (r) {
				if (r.finished) { done(r, 0); return; }
				progress(box, 3, '0 / ' + r.total, false);
				step(r.total);
			}).catch(function (err) { btn.disabled = false; progress(box, 0, err.message, false); toast(err.message, 'error'); });
		});
	}

	/* ------------------------------------------------------------ Geral */
	ready(function () {
		var root = document.querySelector('.mlclip-admin');
		if (!root) { return; }
		toast(root.getAttribute('data-toast-message'), root.getAttribute('data-toast-type'));

		root.addEventListener('click', function (e) {
			var code = e.target.closest('[data-copy]');
			if (code) { copy(code.getAttribute('data-copy')); }
		});
		root.addEventListener('submit', function (e) {
			var f = e.target;
			var msg = f.getAttribute && f.getAttribute('data-confirm');
			if (msg && !window.confirm(msg)) { e.preventDefault(); }
		});
		$all('[data-confirm-on]', root).forEach(function (c) {
			c.addEventListener('change', function () {
				if (c.checked && !window.confirm(c.getAttribute('data-confirm-on'))) { c.checked = false; }
			});
		});
		$all('[data-autosubmit]', root).forEach(function (s) { s.addEventListener('change', function () { s.form.submit(); }); });

		$all('[data-mask="date"]', root).forEach(function (i) {
			i.value = maskDate(i.value);
			i.addEventListener('input', function () { i.value = maskDate(i.value); });
		});

		$all('[data-color-for]', root).forEach(function (c) {
			var hex = document.getElementById(c.getAttribute('data-color-for'));
			if (!hex) { return; }
			c.addEventListener('input', function () { hex.value = c.value; });
			hex.addEventListener('input', function () { if (/^#[0-9a-f]{6}$/i.test(hex.value)) { c.value = hex.value; } });
		});

		$all('form[data-unsaved]', root).forEach(function (f) {
			var dirty = false;
			f.addEventListener('input', function () { dirty = true; });
			f.addEventListener('change', function () { dirty = true; });
			f.addEventListener('submit', function () { dirty = false; });
			window.addEventListener('beforeunload', function (e) { if (dirty) { e.preventDefault(); e.returnValue = T.unsaved; } });
		});

		// Foto da fila que não carrega: mostra o nome do veículo no lugar.
		$all('.mlclip-rv-thumb img', root).forEach(function (img) {
			function swap() {
				var box = img.parentNode, ph = document.createElement('span');
				ph.className = 'mlclip-rv-ph'; ph.textContent = box.getAttribute('data-outlet') || '';
				img.replaceWith(ph);
			}
			if (img.complete && img.naturalWidth === 0) { swap(); } else { img.addEventListener('error', swap); }
		});

		runner();
		review();
		fetchLink();
		importer();
		repair();
	});
})();
