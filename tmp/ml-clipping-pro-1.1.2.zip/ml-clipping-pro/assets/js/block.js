/* ML Clipping Pro — bloco "Clipping (jornal)" do editor (sem etapa de build). */
(function (wp) {
	'use strict';
	if (!wp || !wp.blocks || !wp.element) { return; }
	var el = wp.element.createElement;
	var __ = wp.i18n.__;
	var be = wp.blockEditor || wp.editor;
	var C = wp.components;
	var SSR = wp.serverSideRender;
	var DATA = window.MLCLIP_BLOCK || { names: [] };

	var yesNo = [
		{ label: __('Padrão (Aparência)', 'ml-clipping-pro'), value: '' },
		{ label: __('Sim', 'ml-clipping-pro'), value: 'sim' },
		{ label: __('Não', 'ml-clipping-pro'), value: 'nao' }
	];

	var icon = el('svg', { viewBox: '0 0 24 24', width: 24, height: 24 },
		el('path', { d: 'M4 4h13v14.5c0 .8.7 1.5 1.5 1.5H5.5A1.5 1.5 0 0 1 4 18.5V4zm2 2v4h9V6H6zm0 6v1.5h9V12H6zm0 3v1.5h9V15H6zM18 8h2v10.5a1.5 1.5 0 0 1-3 0V8h1z' })
	);

	wp.blocks.registerBlockType('ml-clipping-pro/clipping', {
		apiVersion: 2,
		title: __('Clipping (jornal)', 'ml-clipping-pro'),
		description: __('Matérias aprovadas do ML Clipping Pro em layout de jornal, por data.', 'ml-clipping-pro'),
		icon: icon,
		category: 'widgets',
		keywords: ['clipping', 'imprensa', 'jornal', 'notícias'],
		supports: { html: false, align: ['wide', 'full'] },
		edit: function (props) {
			var a = props.attributes;
			var set = function (k) { return function (v) { var o = {}; o[k] = v; props.setAttributes(o); }; };
			var chosen = (a.nomes || '').split(',').filter(Boolean);
			var toggleName = function (slug) {
				return function (on) {
					var list = chosen.filter(function (s) { return s !== slug; });
					if (on) { list.push(slug); }
					props.setAttributes({ nomes: list.join(',') });
				};
			};
			var blockProps = be.useBlockProps ? be.useBlockProps() : {};
			return el('div', blockProps,
				el(be.InspectorControls, null,
					el(C.PanelBody, { title: __('Conteúdo', 'ml-clipping-pro'), initialOpen: true },
						DATA.names.length ? el('p', { className: 'components-base-control__help' }, __('Nomes (nenhum marcado = todos):', 'ml-clipping-pro')) : null,
						DATA.names.map(function (n) {
							return el(C.CheckboxControl, { key: n.value, label: n.label, checked: chosen.indexOf(n.value) !== -1, onChange: toggleName(n.value) });
						}),
						el(C.TextControl, { label: __('Título do jornal', 'ml-clipping-pro'), help: __('Vazio = o da Aparência.', 'ml-clipping-pro'), value: a.titulo, onChange: set('titulo') }),
						el(C.TextControl, { label: __('Linha abaixo do título', 'ml-clipping-pro'), value: a.subtitulo, onChange: set('subtitulo') })
					),
					el(C.PanelBody, { title: __('Layout', 'ml-clipping-pro'), initialOpen: false },
						el(C.RangeControl, { label: __('Colunas (0 = padrão)', 'ml-clipping-pro'), min: 0, max: 4, value: a.colunas, onChange: set('colunas') }),
						el(C.RangeControl, { label: __('Matérias por página (0 = padrão)', 'ml-clipping-pro'), min: 0, max: 100, value: a.por_pagina, onChange: set('por_pagina') }),
						el(C.SelectControl, { label: __('Organizar por', 'ml-clipping-pro'), value: a.agrupar, options: [{ label: __('Padrão (Aparência)', 'ml-clipping-pro'), value: '' }, { label: __('Automático', 'ml-clipping-pro'), value: 'auto' }, { label: __('Mês', 'ml-clipping-pro'), value: 'mes' }, { label: __('Ano', 'ml-clipping-pro'), value: 'ano' }], onChange: set('agrupar') }),
						el(C.SelectControl, { label: __('Cabeçalho do jornal', 'ml-clipping-pro'), value: a.cabecalho, options: yesNo, onChange: set('cabecalho') }),
						el(C.SelectControl, { label: __('Manchete em destaque', 'ml-clipping-pro'), value: a.manchete, options: yesNo, onChange: set('manchete') }),
						el(C.SelectControl, { label: __('Fotos', 'ml-clipping-pro'), value: a.imagens, options: yesNo, onChange: set('imagens') }),
						el(C.SelectControl, { label: __('Resumo', 'ml-clipping-pro'), value: a.resumo, options: yesNo, onChange: set('resumo') }),
						el(C.SelectControl, { label: __('Filtros', 'ml-clipping-pro'), value: a.filtros, options: yesNo, onChange: set('filtros') })
					)
				),
				el(SSR, { block: 'ml-clipping-pro/clipping', attributes: a })
			);
		},
		save: function () { return null; }
	});
})(window.wp);
