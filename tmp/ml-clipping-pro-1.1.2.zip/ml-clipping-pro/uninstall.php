<?php
/**
 * Desinstalação.
 *
 * Por padrão NADA do clipping é apagado: matérias, nomes e configurações ficam guardados
 * e reinstalar volta como estava. Só agendamentos e caches são removidos.
 * Apagar tudo só acontece se o administrador ligou, em Busca e avisos, a opção
 * "Apagar todas as matérias ao excluir o plugin".
 *
 * @package MLClippingPro
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

foreach ( array( 'mlclip_search', 'mlclip_search_continue', 'mlclip_linkcheck', 'mllc_ml_clipping_pro_refresh' ) as $mlclip_hook ) {
	wp_clear_scheduled_hook( $mlclip_hook );
}
wp_unschedule_hook( 'mlclip_archive' );
delete_transient( 'mlclip_github_release' );
delete_transient( 'mlclip_trial_try' );
delete_transient( 'mlclip_lock' );
delete_transient( 'mlclip_gdelt_next' );
delete_option( 'mlclip_job' );
delete_option( 'mlclip_lock' );

$mlclip_settings = get_option( 'mlclip_settings', array() );
if ( ! is_array( $mlclip_settings ) || empty( $mlclip_settings['remove_data'] ) || '1' !== (string) $mlclip_settings['remove_data'] ) {
	return;
}

// --- Daqui para baixo só roda com a opção ligada pelo administrador. ---

// Durante a desinstalação o plugin não está carregado: registra o tipo e a situação "Descartada"
// para o WP_Query enxergar todas as matérias.
register_post_type( 'mlclip_item', array( 'public' => false ) );
register_post_status( 'mlclip_discard', array( 'public' => false, 'internal' => false ) );

$mlclip_ids = get_posts(
	array(
		'post_type'      => 'mlclip_item',
		'post_status'    => array( 'publish', 'pending', 'draft', 'private', 'future', 'trash', 'mlclip_discard' ),
		'posts_per_page' => -1,
		'fields'         => 'ids',
		'no_found_rows'  => true,
	)
);
foreach ( $mlclip_ids as $mlclip_id ) {
	wp_delete_post( (int) $mlclip_id, true );
}
// A taxonomia não está registrada durante a desinstalação: remove os termos pela API depois de registrar.
register_taxonomy( 'mlclip_nome', 'mlclip_item', array( 'public' => false ) );
$mlclip_terms = get_terms(
	array(
		'taxonomy'   => 'mlclip_nome',
		'hide_empty' => false,
		'fields'     => 'ids',
	)
);
if ( is_array( $mlclip_terms ) ) {
	foreach ( $mlclip_terms as $mlclip_term ) {
		wp_delete_term( (int) $mlclip_term, 'mlclip_nome' );
	}
}
foreach ( array( 'mlclip_settings', 'mlclip_runs', 'mlclip_seen', 'mlclip_last_email', 'mlclip_page_id', 'mlclip_installed_version', 'mlclip_trial_error', 'mlclip_cache_v', 'mlclip_lock', 'mllc_ml_clipping_pro' ) as $mlclip_opt ) {
	delete_option( $mlclip_opt );
}
