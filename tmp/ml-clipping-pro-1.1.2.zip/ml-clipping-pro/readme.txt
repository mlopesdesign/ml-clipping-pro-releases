=== ML Clipping Pro ===
Contributors: mlopesdesign
Tags: clipping, imprensa, notícias, assessoria de imprensa, jornal
Requires at least: 6.0
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.1.2
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Clipping de imprensa automático: busca diária das matérias que citam os nomes escolhidos, fila de aprovação, aviso por e-mail e layout de jornal no site.

== Description ==

O ML Clipping Pro acompanha a imprensa para você.

* **Nomes monitorados sem limite** — entidade, pessoa, artista, empresa ou evento, com variações, palavras a excluir, palavras obrigatórias, idioma/país e regra de entrada.
* **Busca automática** (padrão: todo dia, de madrugada) no Google Notícias, no Bing Notícias e no GDELT. Grátis e sem chave.
* **Lê a página de cada matéria** para pegar título, resumo, foto, data real de publicação e o nome do veículo.
* **Nota de relevância (0–100)**: nome no título vale mais que uma citação de passagem. Abaixo da nota mínima a matéria é descartada sozinha e fica guardada.
* **Fila de aprovação**: nada aparece no site sem a sua aprovação (aprovar uma a uma, em lote ou "todas de nota Alta").
* **Aviso de matéria nova**: e-mail (no máximo 1 por dia, nunca vazio), contador vermelho no menu e na barra do WordPress e faixa no Painel.
* **Layout de jornal**: cabeçalho, seções por mês ou ano, manchete em destaque, colunas com filete, filtros por nome, ano, veículo e tipo, "Carregar mais".
* **Links que não se perdem**: cópia de cada matéria aprovada no archive.org e conferência semanal dos links (marca "Fora do ar", nunca apaga).
* **Importação** de clipping antigo: de uma página com links, de uma lista colada ou de posts do Page Links To.
* Mostre no site com o módulo do ML Builder, o bloco "Clipping (jornal)" ou o shortcode `[ml_clipping]`.

Peso no servidor: poucos acessos por dia para cada nome, em lotes pequenos, em segundo plano.

== Installation ==

1. Envie o ZIP em Plugins > Adicionar novo > Enviar plugin e ative.
2. Em Clipping > Nomes monitorados, adicione os nomes.
3. No Painel, clique em "Buscar agora" e revise as matérias em Revisão.
4. Crie a página do clipping (botão no Painel) ou use o módulo/bloco/shortcode.

== Frequently Asked Questions ==

= Publica sozinho? =
Não. Por padrão toda matéria passa pela sua aprovação. A publicação automática existe em Busca e avisos, desligada.

= Apaga alguma coisa? =
Não. Matérias descartadas ficam guardadas; links fora do ar são só marcados. Excluir o plugin não apaga nada (a não ser que você ligue essa opção).

= Atributos do shortcode =
`nomes="etiqueta,outra"` `titulo="…"` `subtitulo="…"` `colunas="1-4"` `por_pagina="24"` `agrupar="auto|mes|ano"` `filtros="sim|nao"` `manchete="sim|nao"` `imagens="sim|nao"` `resumo="sim|nao"` `cabecalho="sim|nao"` `cor="#hex"`.

== Changelog ==

= 1.1.2 =
* Atualização online: "Verificar novamente" (Painel > Atualizações) e o novo link "Verificar atualização" na lista de plugins consultam o GitHub na hora, sem esperar o cache.
* Cache da versão nova caiu de 6 h para 1 h.
* Se a API do GitHub recusar (limite de consultas em hospedagem compartilhada), a versão é lida pela página pública de releases.

= 1.1.1 =
* Busca só traz matéria que existe: link 404/410, domínio extinto ou à venda, "página não encontrada" e link que cai na página inicial ficam de fora.
* Botão Excluir na Revisão, em Matérias (todas as situações) e "Excluir marcadas"; matéria excluída não volta nas buscas.
* Reler matérias e importação: matéria fora do ar e sem cópia no archive.org sai do site e vai para a fila.
* Reler matérias nunca troca a data por uma mais nova: matéria antiga não ganha mais a data de hoje.
* Cópia do archive.org feita nos últimos 30 dias não serve de data (o próprio plugin pede cópia ao aprovar).
* Reler matérias tira a anotação "no archive.org desde" de data recente gravada pela 1.1.0.

= 1.1.0 =
* Veículos aprovados automaticamente: matéria desses domínios (com data conhecida e nota acima da mínima) entra publicada; as demais continuam na fila.
* Reler matérias (aba Importar): completa foto, data e título genérico de matérias já salvas; link fora do ar é lido da cópia do archive.org e marcado.
* Importação: matéria fora do ar ou em domínio à venda usa a cópia do archive.org (data aproximada pelo primeiro registro); sem data vai para a fila e não entra em "Aprovar todas de nota Alta".
* Importação de "Página deste site" executa os shortcodes da página (ex.: listas de links de outros plugins).
* Foto da matéria também pela primeira imagem do texto quando a página não informa uma.
* Quadro sem foto: o nome do veículo nunca é quebrado no meio; o corpo diminui para caber.
* Links do submenu (Revisão, Matérias, Importar...) corrigidos em instalações que davam erro 404.
* Texto de link genérico ("Array", "null"...) não vira título.

= 1.0.0 =
* Primeira versão: nomes monitorados sem limite, busca automática diária (Google Notícias, Bing Notícias, GDELT), leitura da página da matéria, nota de relevância, fila de aprovação com ações em lote, aviso por e-mail/contador/faixa, layout de jornal (shortcode, bloco e ML Builder), importação (página, lista, Page Links To), cópia no archive.org, conferência de links, licença pelo site tools (30 dias de teste) e atualização automática pelo GitHub.
