<?php
/**
 * Configurações gerais (busca, avisos e aparência).
 *
 * Padrões seguros (REGRAS 0.2/0.3): nada publica sozinho, nada apaga dados,
 * nada mexe no tema. A busca roda uma vez por dia, de madrugada.
 *
 * @package MLClippingPro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class MLCLIP_Settings {

	public const OPTION = 'mlclip_settings';

	/**
	 * Intervalos de busca permitidos (chave => segundos).
	 *
	 * @return array<string, int>
	 */
	public static function frequencies(): array {
		return array(
			'12h' => 12 * HOUR_IN_SECONDS,
			'1d'  => DAY_IN_SECONDS,
			'2d'  => 2 * DAY_IN_SECONDS,
			'3d'  => 3 * DAY_IN_SECONDS,
			'5d'  => 5 * DAY_IN_SECONDS,
			'7d'  => 7 * DAY_IN_SECONDS,
		);
	}

	/**
	 * Rótulos dos intervalos.
	 *
	 * @return array<string, string>
	 */
	public static function frequency_labels(): array {
		return array(
			'12h' => __( '2 vezes por dia', 'ml-clipping-pro' ),
			'1d'  => __( 'Todo dia (recomendado)', 'ml-clipping-pro' ),
			'2d'  => __( 'A cada 2 dias', 'ml-clipping-pro' ),
			'3d'  => __( 'A cada 3 dias', 'ml-clipping-pro' ),
			'5d'  => __( 'A cada 5 dias', 'ml-clipping-pro' ),
			'7d'  => __( 'Uma vez por semana', 'ml-clipping-pro' ),
		);
	}

	/**
	 * Valores padrão.
	 *
	 * @return array<string, mixed>
	 */
	public static function defaults(): array {
		return array(
			// Busca.
			'frequency'      => '1d',
			'hour'           => 3,
			'src_google'     => '1',
			'src_bing'       => '1',
			'src_gdelt'      => '1',
			'lookback'       => 30,
			'max_per_run'    => 50,
			'min_score'      => 30,
			'auto_publish'   => '0',
			'preferred'      => array(),
			'auto_outlets'   => array(),
			'blocked'        => array(),
			// Avisos.
			'notify_email'   => '1',
			'notify_to'      => array( (string) get_option( 'admin_email' ) ),
			'notify_admin'   => '1',
			// Manutenção dos links.
			'archive'        => '1',
			'linkcheck'      => '1',
			// Aparência.
			'paper_title'    => __( 'Clipping', 'ml-clipping-pro' ),
			'paper_subtitle' => '',
			'accent'         => '',
			'columns'        => 3,
			'per_page'       => 24,
			'group'          => 'auto',
			'headline'       => '1',
			'images'         => '1',
			'excerpt'        => '1',
			'filters'        => '1',
			'serif'          => '1',
			'new_tab'        => '1',
			// Dados.
			'remove_data'    => '0',
		);
	}

	/**
	 * Configurações completas.
	 *
	 * @return array<string, mixed>
	 */
	public static function all(): array {
		$saved = get_option( self::OPTION, array() );
		return array_merge( self::defaults(), is_array( $saved ) ? $saved : array() );
	}

	/**
	 * Um valor.
	 *
	 * @return mixed
	 */
	public static function get( string $key ) {
		$all = self::all();
		return $all[ $key ] ?? null;
	}

	/**
	 * Liga/desliga.
	 */
	public static function on( string $key ): bool {
		return '1' === (string) self::get( $key );
	}

	/**
	 * Grava a parte "Busca e avisos".
	 *
	 * @param array<string, mixed> $in Entrada.
	 */
	public static function save_search( array $in ): void {
		$s   = self::all();
		$old = (string) $s['frequency'] . '|' . (int) $s['hour'];
		$s['frequency']    = array_key_exists( (string) ( $in['frequency'] ?? '' ), self::frequencies() ) ? (string) $in['frequency'] : '1d';
		$s['hour']         = MLCLIP_Helpers::int_range( $in['hour'] ?? 3, 0, 23, 3 );
		$s['src_google']   = empty( $in['src_google'] ) ? '0' : '1';
		$s['src_bing']     = empty( $in['src_bing'] ) ? '0' : '1';
		$s['src_gdelt']    = empty( $in['src_gdelt'] ) ? '0' : '1';
		$s['lookback']     = MLCLIP_Helpers::int_range( $in['lookback'] ?? 30, 1, 365, 30 );
		$s['max_per_run']  = MLCLIP_Helpers::int_range( $in['max_per_run'] ?? 50, 5, 200, 50 );
		$s['min_score']    = MLCLIP_Helpers::int_range( $in['min_score'] ?? 30, 0, 90, 30 );
		$s['auto_publish'] = empty( $in['auto_publish'] ) ? '0' : '1';
		$s['preferred']    = MLCLIP_Helpers::domains( $in['preferred'] ?? '' );
		$s['auto_outlets'] = MLCLIP_Helpers::domains( $in['auto_outlets'] ?? '' );
		$s['blocked']      = MLCLIP_Helpers::domains( $in['blocked'] ?? '' );
		$s['notify_email'] = empty( $in['notify_email'] ) ? '0' : '1';
		$s['notify_to']    = MLCLIP_Helpers::emails( $in['notify_to'] ?? '' );
		$s['notify_admin'] = empty( $in['notify_admin'] ) ? '0' : '1';
		$s['archive']      = empty( $in['archive'] ) ? '0' : '1';
		$s['linkcheck']    = empty( $in['linkcheck'] ) ? '0' : '1';
		$s['remove_data']  = empty( $in['remove_data'] ) ? '0' : '1';
		if ( ! $s['notify_to'] ) {
			$s['notify_to'] = array( (string) get_option( 'admin_email' ) );
		}
		update_option( self::OPTION, $s, false );
		if ( $old !== $s['frequency'] . '|' . $s['hour'] ) {
			MLCLIP_Engine::reschedule();
		}
	}

	/**
	 * Grava a parte "Aparência".
	 *
	 * @param array<string, mixed> $in Entrada.
	 */
	public static function save_appearance( array $in ): void {
		$s                   = self::all();
		$s['paper_title']    = sanitize_text_field( (string) ( $in['paper_title'] ?? '' ) );
		$s['paper_subtitle'] = sanitize_text_field( (string) ( $in['paper_subtitle'] ?? '' ) );
		$s['accent']         = MLCLIP_Helpers::color( $in['accent'] ?? '' );
		$s['columns']        = MLCLIP_Helpers::int_range( $in['columns'] ?? 3, 1, 4, 3 );
		$s['per_page']       = MLCLIP_Helpers::int_range( $in['per_page'] ?? 24, 6, 100, 24 );
		$s['group']          = MLCLIP_Helpers::choice( $in['group'] ?? 'month', array( 'auto', 'month', 'year' ), 'auto' );
		foreach ( array( 'headline', 'images', 'excerpt', 'filters', 'serif', 'new_tab' ) as $k ) {
			$s[ $k ] = empty( $in[ $k ] ) ? '0' : '1';
		}
		if ( '' === $s['paper_title'] ) {
			$s['paper_title'] = __( 'Clipping', 'ml-clipping-pro' );
		}
		update_option( self::OPTION, $s, false );
	}
}
