<?php
/**
 * Acesso à internet com limites (tempo, tamanho) e texto sempre em UTF-8.
 *
 * @package MLClippingPro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class MLCLIP_Http {

	/**
	 * Identificação do robô (sem dados pessoais).
	 */
	public static function user_agent(): string {
		// Muitos veículos recusam robôs desconhecidos (403) e escondem a data; abre como um navegador comum.
		return 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36';
	}

	/**
	 * GET simples. Devolve [código, corpo, url_final] ou WP_Error.
	 *
	 * @param array<string, mixed> $args Extras do wp_remote_*.
	 * @return array{0:int,1:string,2:string}|\WP_Error
	 */
	public static function get( string $url, array $args = array() ) {
		if ( ! MLCLIP_Helpers::is_url( $url ) ) {
			return new \WP_Error( 'mlclip_http_url', __( 'Link inválido.', 'ml-clipping-pro' ) );
		}
		$args = array_merge(
			array(
				'timeout'             => 15,
				'redirection'         => 5,
				'limit_response_size' => 1572864,
				'user-agent'          => self::user_agent(),
				'headers'             => array(
					'Accept'          => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
					'Accept-Language' => 'pt-BR,pt;q=0.9,en;q=0.6',
				),
			),
			$args
		);
		$res = wp_safe_remote_get( $url, $args );
		return self::result( $res, $url );
	}

	/**
	 * POST de formulário.
	 *
	 * @param array<string, string> $body    Campos.
	 * @param array<string, string> $headers Cabeçalhos.
	 * @return array{0:int,1:string,2:string}|\WP_Error
	 */
	public static function post( string $url, array $body, array $headers = array() ) {
		$res = wp_safe_remote_post(
			$url,
			array(
				'timeout'    => 15,
				'user-agent' => self::user_agent(),
				'headers'    => $headers,
				'body'       => $body,
			)
		);
		return self::result( $res, $url );
	}

	/**
	 * Normaliza a resposta.
	 *
	 * @param array<string, mixed>|\WP_Error $res Resposta.
	 * @return array{0:int,1:string,2:string}|\WP_Error
	 */
	private static function result( $res, string $url ) {
		if ( is_wp_error( $res ) ) {
			return $res;
		}
		$code  = (int) wp_remote_retrieve_response_code( $res );
		$body  = (string) wp_remote_retrieve_body( $res );
		$final = $url;
		if ( isset( $res['http_response'] ) && is_object( $res['http_response'] ) && method_exists( $res['http_response'], 'get_response_object' ) ) {
			$obj = $res['http_response']->get_response_object();
			if ( is_object( $obj ) && ! empty( $obj->url ) ) {
				$final = (string) $obj->url;
			}
		}
		$type = (string) wp_remote_retrieve_header( $res, 'content-type' );
		return array( $code, self::to_utf8( $body, $type ), $final );
	}

	/**
	 * Converte o texto para UTF-8 (sites antigos em ISO-8859-1/Windows-1252).
	 */
	public static function to_utf8( string $body, string $content_type = '' ): string {
		if ( '' === $body ) {
			return '';
		}
		$charset = '';
		if ( preg_match( '/charset=([\w-]+)/i', $content_type, $m ) ) {
			$charset = strtoupper( $m[1] );
		} elseif ( preg_match( '/<meta[^>]+charset=["\']?([\w-]+)/i', substr( $body, 0, 4096 ), $m ) ) {
			$charset = strtoupper( $m[1] );
		} elseif ( preg_match( '/<\?xml[^>]+encoding=["\']([\w-]+)/i', substr( $body, 0, 200 ), $m ) ) {
			$charset = strtoupper( $m[1] );
		}
		if ( '' !== $charset && 'UTF-8' !== $charset && 'UTF8' !== $charset && function_exists( 'mb_convert_encoding' ) ) {
			$conv = @mb_convert_encoding( $body, 'UTF-8', $charset ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- charset desconhecido cai no teste abaixo.
			if ( is_string( $conv ) && '' !== $conv ) {
				return $conv;
			}
		}
		if ( function_exists( 'mb_check_encoding' ) && ! mb_check_encoding( $body, 'UTF-8' ) && function_exists( 'mb_convert_encoding' ) ) {
			return (string) mb_convert_encoding( $body, 'UTF-8', 'Windows-1252' );
		}
		return $body;
	}
}
