<?php
/**
 * Motor da busca automática.
 *
 * Uma rodada é dividida em passos curtos (nunca trava o servidor):
 * 1. coleta: um nome por passo, nas fontes ligadas (Google, Bing, GDELT);
 * 2. análise: 5 matérias por passo — resolve o link real, abre a página, dá a nota e grava;
 * 3. fim: registra o resumo da rodada e manda o aviso.
 *
 * Pelo agendamento do WordPress os passos seguem sozinhos (um evento a cada minuto até acabar);
 * pelo botão "Buscar agora" o painel chama os passos e mostra o andamento.
 *
 * @package MLClippingPro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class MLCLIP_Engine {

	public const HOOK      = 'mlclip_search';
	public const HOOK_NEXT = 'mlclip_search_continue';
	private const JOB      = 'mlclip_job';
	private const SEEN     = 'mlclip_seen';
	private const RUNS     = 'mlclip_runs';
	private const LOCK     = 'mlclip_lock';
	private const BATCH    = 5;

	/**
	 * Ganchos.
	 */
	public static function hooks(): void {
		add_filter( 'cron_schedules', array( __CLASS__, 'schedules' ) ); // phpcs:ignore WordPress.WP.CronInterval.CronSchedulesInterval -- intervalos de 12 h a 7 dias.
		add_action( self::HOOK, array( __CLASS__, 'cron' ) );
		add_action( self::HOOK_NEXT, array( __CLASS__, 'cron_continue' ) );
	}

	/**
	 * Intervalos próprios.
	 *
	 * @param array<string, array<string, mixed>> $s Intervalos.
	 * @return array<string, array<string, mixed>>
	 */
	public static function schedules( $s ) {
		$labels = MLCLIP_Settings::frequency_labels();
		foreach ( MLCLIP_Settings::frequencies() as $key => $seconds ) {
			$s[ 'mlclip_' . $key ] = array(
				'interval' => $seconds,
				'display'  => 'ML Clipping Pro: ' . $labels[ $key ],
			);
		}
		return $s;
	}

	/**
	 * (Re)agenda a busca no horário escolhido (horário do site).
	 */
	public static function reschedule(): void {
		wp_clear_scheduled_hook( self::HOOK );
		$s    = MLCLIP_Settings::all();
		$tz   = wp_timezone();
		$next = new \DateTimeImmutable( 'now', $tz );
		$next = $next->setTime( (int) $s['hour'], 7 );
		if ( $next->getTimestamp() <= time() + 60 ) {
			$next = $next->modify( '+1 day' );
		}
		wp_schedule_event( $next->getTimestamp(), 'mlclip_' . $s['frequency'], self::HOOK );
	}

	/**
	 * Garante o agendamento (ex.: depois de restaurar backup).
	 */
	public static function ensure_scheduled(): void {
		if ( ! wp_next_scheduled( self::HOOK ) ) {
			self::reschedule();
		}
	}

	/**
	 * Próxima busca agendada.
	 */
	public static function next_run(): int {
		return (int) wp_next_scheduled( self::HOOK );
	}

	/* ====================================================================
	 * Agendamento
	 * ================================================================== */

	/**
	 * Evento agendado: começa a rodada e anda até 40 s.
	 */
	public static function cron(): void {
		if ( ! MLCLIP_License::active() ) {
			self::log_run(
				array(
					'trigger' => 'cron',
					'paused'  => __( 'Busca automática pausada: o teste grátis terminou ou a licença não está ativa.', 'ml-clipping-pro' ),
				)
			);
			return;
		}
		$job = self::job();
		if ( $job ) {
			// Rodada anterior parada (aba fechada, servidor reiniciado): continua de onde parou.
			if ( ( time() - (int) $job['updated'] ) >= 5 * MINUTE_IN_SECONDS ) {
				self::run_for( 40 );
			}
			return;
		}
		$res = self::start( 'cron' );
		if ( ! is_wp_error( $res ) ) {
			self::run_for( 40 );
		}
	}

	/**
	 * Continuação da rodada pelo agendamento.
	 */
	public static function cron_continue(): void {
		if ( ! MLCLIP_License::active() ) {
			$job = self::job();
			if ( $job ) {
				// Licença venceu no meio: registra o que já foi achado e encerra.
				delete_option( self::JOB );
				self::unlock();
				self::finish( $job );
			}
			wp_clear_scheduled_hook( self::HOOK_NEXT );
			return;
		}
		if ( self::job() ) {
			self::run_for( 40 );
		} else {
			wp_clear_scheduled_hook( self::HOOK_NEXT );
		}
	}

	/**
	 * Anda com a rodada por alguns segundos; se faltar, agenda a continuação em 1 minuto.
	 */
	private static function run_for( int $seconds ): void {
		self::watchdog();
		$until = time() + $seconds;
		do {
			$res = self::step();
		} while ( empty( $res['done'] ) && empty( $res['busy'] ) && time() < $until );
		wp_clear_scheduled_hook( self::HOOK_NEXT );
		if ( empty( $res['done'] ) ) {
			wp_schedule_single_event( time() + MINUTE_IN_SECONDS, self::HOOK_NEXT );
		}
	}

	/**
	 * Garantia: se o processo morrer no meio (ou a aba do "Buscar agora" for fechada),
	 * o agendamento retoma a rodada sozinho.
	 */
	private static function watchdog(): void {
		if ( ! wp_next_scheduled( self::HOOK_NEXT ) ) {
			wp_schedule_single_event( time() + 3 * MINUTE_IN_SECONDS, self::HOOK_NEXT );
		}
	}

	/**
	 * Trava atômica (uma etapa por vez). Trava de mais de 4 minutos é considerada abandonada.
	 */
	private static function lock(): bool {
		global $wpdb;
		$now = (string) time();
		// INSERT IGNORE: só um processo consegue criar a linha (atômico no banco).
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$wpdb->query( $wpdb->prepare( "INSERT IGNORE INTO {$wpdb->options} (option_name, option_value, autoload) VALUES (%s, %s, 'no')", self::LOCK, $now ) );
		if ( 1 === (int) $wpdb->rows_affected ) {
			wp_cache_delete( self::LOCK, 'options' );
			wp_cache_delete( 'notoptions', 'options' );
			return true;
		}
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$since = (string) $wpdb->get_var( $wpdb->prepare( "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s", self::LOCK ) );
		if ( '' !== $since && ( time() - (int) $since ) > 4 * MINUTE_IN_SECONDS ) {
			// Trava abandonada: só quem trocar o valor antigo fica com ela.
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->query( $wpdb->prepare( "UPDATE {$wpdb->options} SET option_value = %s WHERE option_name = %s AND option_value = %s", $now, self::LOCK, $since ) );
			wp_cache_delete( self::LOCK, 'options' );
			return 1 === (int) $wpdb->rows_affected;
		}
		return false;
	}

	/**
	 * Solta a trava.
	 */
	private static function unlock(): void {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$wpdb->delete( $wpdb->options, array( 'option_name' => self::LOCK ) );
		wp_cache_delete( self::LOCK, 'options' );
	}

	/* ====================================================================
	 * Rodada
	 * ================================================================== */

	/**
	 * Rodada em andamento.
	 *
	 * @return array<string, mixed>|null
	 */
	public static function job(): ?array {
		$job = get_option( self::JOB );
		return is_array( $job ) ? $job : null;
	}

	/**
	 * Começa uma rodada (substitui uma rodada parada há mais de 1 hora).
	 *
	 * @param int $only Só este nome (0 = todos os ligados).
	 * @return array<string, mixed>|\WP_Error
	 */
	public static function start( string $trigger, int $only = 0 ) {
		$current = self::job();
		if ( $current && ( time() - (int) $current['updated'] ) < 10 * MINUTE_IN_SECONDS ) {
			return new \WP_Error( 'mlclip_busy', __( 'Já existe uma busca em andamento. Aguarde terminar.', 'ml-clipping-pro' ) );
		}
		if ( $current ) {
			// Rodada abandonada: registra o que ela já achou (e avisa) antes de começar outra.
			delete_option( self::JOB );
			self::finish( $current );
		}
		$names = array();
		foreach ( MLCLIP_Names::all( true ) as $n ) {
			if ( ! $only || $only === (int) $n['id'] ) {
				$names[] = (int) $n['id'];
			}
		}
		if ( ! $names ) {
			return new \WP_Error( 'mlclip_no_names', __( 'Cadastre (ou ligue) pelo menos um nome em "Nomes monitorados".', 'ml-clipping-pro' ) );
		}
		if ( ! MLCLIP_Settings::on( 'src_google' ) && ! MLCLIP_Settings::on( 'src_bing' ) && ! MLCLIP_Settings::on( 'src_gdelt' ) ) {
			return new \WP_Error( 'mlclip_no_sources', __( 'Ligue pelo menos uma fonte de busca em "Busca e avisos".', 'ml-clipping-pro' ) );
		}
		$job = array(
			'id'        => wp_generate_password( 8, false ),
			'trigger'   => $trigger,
			'started'   => time(),
			'updated'   => time(),
			'names'     => $names,
			'total'     => count( $names ),
			'queue'     => array(),
			'processed' => 0,
			'stats'     => array(
				'found'     => 0,
				'analysed'  => 0,
				'added'     => 0,
				'published' => 0,
				'discarded' => 0,
				'outside'   => 0,
				'failed'    => 0,
			),
			'sources'   => array(),
			'errors'    => array(),
			'new_ids'   => array(),
			'per_name'  => array(),
		);
		update_option( self::JOB, $job, false );
		self::watchdog();
		return $job;
	}

	/**
	 * Um passo da rodada.
	 *
	 * @return array<string, mixed> done, busy, phase, message, stats.
	 */
	public static function step(): array {
		$job = self::job();
		if ( ! $job ) {
			return array( 'done' => true, 'phase' => 'idle' );
		}
		if ( ! self::lock() ) {
			return array( 'done' => false, 'busy' => true, 'phase' => 'busy' );
		}
		$job = self::job(); // Relê depois de travar (outra etapa pode ter acabado agora).
		if ( ! $job ) {
			self::unlock();
			return array( 'done' => true, 'phase' => 'idle' );
		}
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 120 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- alguns servidores bloqueiam.
		}

		try {
			if ( ! empty( $job['names'] ) ) {
				$name_id = (int) array_shift( $job['names'] );
				$job     = self::collect( $job, $name_id );
				$phase   = 'collect';
			} elseif ( ! empty( $job['queue'] ) ) {
				$job   = self::analyse( $job );
				$phase = 'analyse';
			} else {
				$phase = 'finish';
			}
		} catch ( \Throwable $e ) {
			$job['errors'][] = $e->getMessage();
			$job['queue']    = array();
			$job['names']    = array();
			$phase           = 'finish';
		}

		if ( 'finish' === $phase ) {
			delete_option( self::JOB );
			self::unlock();
			wp_clear_scheduled_hook( self::HOOK_NEXT );
			self::finish( $job );
			return array(
				'done'    => true,
				'phase'   => 'finish',
				'stats'   => $job['stats'],
				'errors'  => $job['errors'],
				'message' => self::summary( $job ),
			);
		}

		$job['updated'] = time();
		update_option( self::JOB, $job, false );
		self::unlock();
		return array(
			'done'    => false,
			'phase'   => $phase,
			'stats'   => $job['stats'],
			'left'    => count( $job['queue'] ),
			'names'   => count( $job['names'] ),
			'total'   => (int) $job['total'],
			'message' => self::progress( $job, $phase ),
		);
	}

	/**
	 * Coleta as matérias de um nome nas fontes e põe na fila de análise.
	 *
	 * @param array<string, mixed> $job Rodada.
	 * @return array<string, mixed>
	 */
	private static function collect( array $job, int $name_id ): array {
		$n = MLCLIP_Names::get( $name_id );
		if ( ! $n ) {
			return $job;
		}
		$s    = MLCLIP_Settings::all();
		$days = $n['last_run'] ? (int) ceil( ( time() - (int) $n['last_run'] ) / DAY_IN_SECONDS ) + 2 : (int) $s['lookback'];
		$days = max( 2, min( 365, $days ) );
		$res  = MLCLIP_Sources::search( $n, $days );

		foreach ( $res['errors'] as $source => $message ) {
			$job['errors'][] = $n['name'] . ' · ' . $source . ': ' . $message;
		}
		foreach ( $res['counts'] as $source => $count ) {
			$job['sources'][ $source ] = (int) ( $job['sources'][ $source ] ?? 0 ) + $count;
		}

		$seen    = self::seen();
		$blocked = (array) $s['blocked'];
		$index   = array();
		foreach ( $job['queue'] as $i => $c ) {
			$index[ $c['tkey'] ] = $i;
		}
		$found = 0;
		foreach ( $res['items'] as $c ) {
			if ( '' === $c['title'] || '' === $c['url'] ) {
				continue;
			}
			$found++;
			$host = '' !== $c['host'] ? $c['host'] : MLCLIP_Helpers::host( $c['url'] );
			if ( '' !== $host && MLCLIP_Helpers::host_in( $host, $blocked ) ) {
				continue;
			}
			$tkey = md5( MLCLIP_Helpers::fold( $c['title'] ) );
			$ukey = $c['wrapped'] ? '' : MLCLIP_Helpers::url_key( $c['url'] );
			// Já resolvida (global) ou já recusada para ESTE nome (outro nome ainda pode aceitar).
			if ( isset( $seen[ 't' . $tkey ] ) || isset( $seen[ 'n' . $name_id . 't' . $tkey ] ) || ( '' !== $ukey && isset( $seen[ 'u' . md5( $ukey ) ] ) ) ) {
				continue;
			}
			if ( MLCLIP_Model::exists( $ukey, '' !== $host ? MLCLIP_Model::title_key( $c['title'], $host ) : '' ) || MLCLIP_Model::deleted( $ukey, '' !== $host ? MLCLIP_Model::title_key( $c['title'], $host ) : '' ) ) {
				$seen[ 't' . $tkey ] = time();
				continue;
			}
			// Palavra a excluir já no título: nem entra.
			$tf = MLCLIP_Helpers::fold( $c['title'] . ' ' . $c['summary'] );
			foreach ( (array) $n['exclude'] as $word ) {
				if ( MLCLIP_Helpers::contains( $tf, (string) $word ) ) {
					$seen[ 'n' . $name_id . 't' . $tkey ] = time();
					continue 2;
				}
			}
			$c['host']      = $host;
			$c['tkey']      = $tkey;
			$c['names']     = array( $name_id );
			$c['in_title']  = self::mentions( MLCLIP_Helpers::fold( $c['title'] ), $n ) > 0;
			if ( 'title' === $n['rule'] && ! $c['in_title'] ) {
				$seen[ 'n' . $name_id . 't' . $tkey ] = time();
				$job['stats']['outside']++;
				continue;
			}
			if ( isset( $index[ $tkey ] ) ) {
				// Mesma matéria de outra fonte ou de outro nome: junta.
				$q                = &$job['queue'][ $index[ $tkey ] ];
				$q['names']       = array_values( array_unique( array_merge( $q['names'], array( $name_id ) ) ) );
				$q['in_title']    = $q['in_title'] || $c['in_title'];
				if ( $q['wrapped'] && ! $c['wrapped'] ) {
					$q['url']     = $c['url'];
					$q['wrapped'] = false;
				}
				foreach ( array( 'summary', 'image', 'outlet' ) as $k ) {
					if ( '' === (string) $q[ $k ] && '' !== (string) $c[ $k ] ) {
						$q[ $k ] = $c[ $k ];
					}
				}
				unset( $q );
				continue;
			}
			$index[ $tkey ]  = count( $job['queue'] );
			$job['queue'][]  = $c;
		}
		self::save_seen( $seen );

		// Teto da rodada: primeiro as que têm o nome no título, depois as mais novas.
		usort(
			$job['queue'],
			static function ( $a, $b ) {
				if ( $a['in_title'] !== $b['in_title'] ) {
					return $a['in_title'] ? -1 : 1;
				}
				return (int) $b['date'] <=> (int) $a['date'];
			}
		);
		$limit = (int) $s['max_per_run'] * 2;
		$cut   = count( $job['queue'] ) > $limit;
		if ( $cut ) {
			$job['queue'] = array_slice( $job['queue'], 0, $limit );
		}

		$job['stats']['found']      += $found;
		$job['per_name'][ $name_id ] = 0;
		// Só avança a janela quando todas as fontes responderam e nada ficou de fora pelo teto;
		// senão a próxima busca olha de novo o mesmo período.
		// O GDELT vive ocupado e é só complemento: a falha dele não segura a janela.
		if ( ! array_diff_key( $res['errors'], array( 'gdelt' => 1 ) ) && ! $cut ) {
			MLCLIP_Names::mark_run( $name_id );
		}
		return $job;
	}

	/**
	 * Analisa até 5 matérias da fila: link real, página, nota e gravação.
	 *
	 * @param array<string, mixed> $job Rodada.
	 * @return array<string, mixed>
	 */
	private static function analyse( array $job ): array {
		$s     = MLCLIP_Settings::all();
		$seen  = self::seen();
		$until = time() + 25; // Cada etapa curta: o servidor nunca fica preso.
		for ( $i = 0; $i < self::BATCH && ! empty( $job['queue'] ) && time() < $until; $i++ ) {
			if ( (int) $job['stats']['added'] >= (int) $s['max_per_run'] ) {
				$job['queue'] = array();
				break;
			}
			$c = array_shift( $job['queue'] );
			$job['stats']['analysed']++;

			$url = $c['wrapped'] ? MLCLIP_Sources::resolve_google( (string) $c['url'] ) : (string) $c['url'];
			if ( '' === $url ) {
				// Falha passageira (limite do Google, rede): não marca; tenta de novo na próxima busca.
				$job['stats']['failed']++;
				continue;
			}
			$ukey = MLCLIP_Helpers::url_key( $url );
			if ( MLCLIP_Model::exists( $ukey ) || MLCLIP_Model::deleted( $ukey ) ) {
				$seen[ 't' . $c['tkey'] ]   = time();
				$seen[ 'u' . md5( $ukey ) ] = time();
				continue;
			}

			// Só entra matéria que existe: 404/410, domínio extinto ou à venda, "página não encontrada"
			// e link que cai na página inicial ficam de fora (Google/Bing guardam links mortos).
			list( $alive, $page ) = MLCLIP_Extractor::check( $url );
			if ( 'dead' === $alive ) {
				$seen[ 't' . $c['tkey'] ]   = time();
				$seen[ 'u' . md5( $ukey ) ] = time();
				$job['stats']['dead']       = (int) ( $job['stats']['dead'] ?? 0 ) + 1;
				continue;
			}
			if ( null === $page ) {
				// Página com bloqueio para robôs ou paywall: usa os dados da fonte.
				$page = array(
					'url'     => $url,
					'host'    => MLCLIP_Helpers::host( $url ),
					'title'   => '',
					'excerpt' => '',
					'image'   => '',
					'outlet'  => '',
					'date'    => 0,
					'media'   => 'texto',
					'body'    => '',
				);
			}
			if ( MLCLIP_Helpers::host_in( (string) $page['host'], (array) $s['blocked'] ) ) {
				$seen[ 't' . $c['tkey'] ] = time();
				continue;
			}
			$final_key = MLCLIP_Helpers::url_key( (string) $page['url'] );
			if ( $final_key !== $ukey && ( MLCLIP_Model::exists( $final_key ) || MLCLIP_Model::deleted( $final_key ) ) ) {
				$seen[ 't' . $c['tkey'] ] = time();
				continue;
			}

			$data = array(
				'title'   => '' !== $page['title'] ? $page['title'] : $c['title'],
				'url'     => $page['url'],
				'excerpt' => '' !== $page['excerpt'] ? $page['excerpt'] : MLCLIP_Helpers::excerpt( (string) $c['summary'], 320 ),
				'image'   => '' !== $page['image'] ? $page['image'] : (string) $c['image'],
				'outlet'  => '' !== (string) $c['outlet'] ? (string) $c['outlet'] : (string) $page['outlet'],
				'date'    => $page['date'] ? (int) $page['date'] : ( (int) $c['date'] ? (int) $c['date'] : time() ),
				'media'   => $page['media'],
				'origin'  => $c['origin'],
				'names'   => $c['names'],
			);
			if ( MLCLIP_Model::exists( '', MLCLIP_Model::title_key( $data['title'], (string) $page['host'] ) ) ) {
				$seen[ 't' . $c['tkey'] ] = time();
				continue;
			}

			$verdict = self::score( $c, $page, $data );
			if ( 'outside' === $verdict['status'] ) {
				// Fora da regra dos nomes que a acharam: só esses nomes deixam de olhar para ela.
				foreach ( (array) $c['names'] as $nid ) {
					$seen[ 'n' . (int) $nid . 't' . $c['tkey'] ] = time();
				}
				$job['stats']['outside']++;
				continue;
			}
			$data['score']   = $verdict['score'];
			$data['reasons'] = implode( ' · ', $verdict['reasons'] );
			if ( $verdict['score'] < (int) $s['min_score'] || 'discard' === $verdict['status'] ) {
				$data['status'] = MLCLIP_Model::DISCARD;
			} elseif ( MLCLIP_Settings::on( 'auto_publish' ) ) {
				$data['status'] = 'publish';
			} elseif ( ( $page['date'] || (int) $c['date'] ) && false === strpos( (string) $data['reasons'], '; confira' ) && MLCLIP_Helpers::host_in( (string) $page['host'], (array) MLCLIP_Settings::get( 'auto_outlets' ) ) ) {
				// Veículo de confiança do administrador: entra direto, mas só com data conhecida.
				$data['status']   = 'publish';
				$data['reasons'] .= ' · ' . __( 'Veículo aprovado automaticamente', 'ml-clipping-pro' );
			} else {
				$data['status'] = 'pending';
			}

			$id                         = MLCLIP_Model::save( $data );
			$seen[ 't' . $c['tkey'] ]   = time();
			$seen[ 'u' . md5( $ukey ) ] = time();
			if ( is_wp_error( $id ) ) {
				if ( 'mlclip_dup' !== $id->get_error_code() ) {
					$job['stats']['failed']++;
				}
				continue;
			}
			if ( MLCLIP_Model::DISCARD === $data['status'] ) {
				$job['stats']['discarded']++;
			} else {
				$job['stats']['added']++;
				if ( 'publish' === $data['status'] ) {
					$job['stats']['published']++;
				}
				$job['new_ids'][] = (int) $id;
				foreach ( (array) $c['names'] as $nid ) {
					$job['per_name'][ (int) $nid ] = (int) ( $job['per_name'][ (int) $nid ] ?? 0 ) + 1;
				}
			}
		}
		self::save_seen( $seen );
		return $job;
	}

	/**
	 * Nota de relevância (0–100) e decisão de entrada.
	 *
	 * @param array<string, mixed> $c    Candidato.
	 * @param array<string, mixed> $page Página.
	 * @param array<string, mixed> $data Dados finais.
	 * @return array{score:int,status:string,reasons:array<int,string>}
	 */
	public static function score( array $c, array $page, array $data ): array {
		$names   = array();
		foreach ( (array) $c['names'] as $nid ) {
			$n = MLCLIP_Names::get( (int) $nid );
			if ( $n ) {
				$names[] = $n;
			}
		}
		if ( ! $names ) {
			return array( 'score' => 0, 'status' => 'outside', 'reasons' => array() );
		}
		$title   = MLCLIP_Helpers::fold( (string) $data['title'] . ' ' . (string) $c['title'] );
		$summary = MLCLIP_Helpers::fold( (string) $data['excerpt'] . ' ' . (string) $c['summary'] );
		$body    = (string) $page['body'];
		$lead    = substr( $body, 0, 900 );

		$best     = array( 'score' => -1, 'status' => 'outside', 'reasons' => array() );
		$excluded = '';
		foreach ( $names as $n ) {
			$reasons  = array();
			$in_title = self::mentions( $title, $n ) > 0;
			$in_sum   = self::mentions( $summary, $n ) > 0;
			$in_lead  = '' !== $lead && self::mentions( $lead, $n ) > 0;
			$count    = '' !== $body ? self::mentions( $body, $n ) : 0;

			// Regra de entrada do nome.
			if ( 'title' === $n['rule'] && ! $in_title ) {
				continue;
			}
			if ( 'title_summary' === $n['rule'] && ! $in_title && ! $in_sum ) {
				continue;
			}
			if ( 'any' === $n['rule'] && ! $in_title && ! $in_sum && ! $count && '' !== $body ) {
				continue;
			}

			// Palavra a excluir deste nome: este nome recusa (outro nome da mesma matéria ainda pode aceitar).
			foreach ( (array) $n['exclude'] as $word ) {
				if ( MLCLIP_Helpers::contains( $title . ' ' . $summary . ' ' . $lead, (string) $word ) ) {
					$excluded = sprintf( /* translators: %s: word. */ __( 'Palavra excluída: %s', 'ml-clipping-pro' ), $word );
					continue 2;
				}
			}

			$score = 0;
			if ( $in_title ) {
				$score    += 50;
				$reasons[] = __( 'Nome no título', 'ml-clipping-pro' );
			}
			if ( $in_sum ) {
				$score    += 20;
				$reasons[] = __( 'Nome no resumo', 'ml-clipping-pro' );
			}
			if ( $in_lead ) {
				$score    += 15;
				$reasons[] = __( 'Nome no início do texto', 'ml-clipping-pro' );
			}
			if ( $count > 0 ) {
				$score    += min( 15, 3 * $count );
				/* translators: %d: count. */
				$reasons[] = sprintf( _n( 'Citado %d vez', 'Citado %d vezes', $count, 'ml-clipping-pro' ), $count );
			}
			if ( '' === $body && ! $in_title && ! $in_sum ) {
				// Página não abriu (bloqueio de robô/paywall) e a fonte achou pelo texto: nota mínima de revisão.
				$score    += 20;
				$reasons[] = __( 'Página não pôde ser lida; confira', 'ml-clipping-pro' );
			}
			if ( MLCLIP_Helpers::host_in( (string) $page['host'], (array) MLCLIP_Settings::get( 'preferred' ) ) ) {
				$score    += 15;
				$reasons[] = __( 'Veículo preferido', 'ml-clipping-pro' );
			}
			if ( ! empty( $n['required'] ) ) {
				$has = false;
				foreach ( (array) $n['required'] as $word ) {
					if ( MLCLIP_Helpers::contains( $title . ' ' . $summary . ' ' . $body, (string) $word ) ) {
						$has = true;
						break;
					}
				}
				if ( ! $has ) {
					$score     = min( $score, 10 );
					$reasons[] = __( 'Sem as palavras obrigatórias', 'ml-clipping-pro' );
				}
			}
			$score = min( 100, $score );
			if ( $score > $best['score'] ) {
				$best = array( 'score' => $score, 'status' => 'ok', 'reasons' => $reasons );
			}
		}
		if ( $best['score'] < 0 ) {
			if ( '' !== $excluded ) {
				return array( 'score' => 0, 'status' => 'discard', 'reasons' => array( $excluded ) );
			}
			return array( 'score' => 0, 'status' => 'outside', 'reasons' => array() );
		}
		return $best;
	}

	/**
	 * Quantas vezes o nome (ou uma variação) aparece no texto dobrado.
	 *
	 * @param array<string, mixed> $n Nome.
	 */
	private static function mentions( string $folded, array $n ): int {
		if ( '' === $folded ) {
			return 0;
		}
		$total = 0;
		$hay   = ' ' . $folded . ' ';
		foreach ( MLCLIP_Names::forms( $n ) as $form ) {
			$needle = MLCLIP_Helpers::fold( $form );
			if ( '' !== $needle ) {
				$total += substr_count( $hay, ' ' . $needle . ' ' );
			}
		}
		return $total;
	}

	/**
	 * Fim da rodada: histórico, contadores por nome e aviso.
	 *
	 * @param array<string, mixed> $job Rodada.
	 */
	private static function finish( array $job ): void {
		foreach ( (array) $job['per_name'] as $nid => $count ) {
			MLCLIP_Names::mark_new( (int) $nid, (int) $count );
		}
		self::log_run(
			array(
				'trigger'  => $job['trigger'],
				'started'  => (int) $job['started'],
				'finished' => time(),
				'stats'    => $job['stats'],
				'sources'  => $job['sources'],
				'errors'   => array_slice( (array) $job['errors'], 0, 10 ),
			)
		);
		// Sempre confere: matérias que ficaram para "o próximo e-mail" saem assim que o limite diário permitir.
		MLCLIP_Notify::after_run();
	}

	/**
	 * Registra uma rodada no histórico (últimas 15).
	 *
	 * @param array<string, mixed> $run Dados.
	 */
	private static function log_run( array $run ): void {
		$runs = get_option( self::RUNS, array() );
		$runs = is_array( $runs ) ? $runs : array();
		$run['time'] = time();
		array_unshift( $runs, $run );
		update_option( self::RUNS, array_slice( $runs, 0, 15 ), false );
	}

	/**
	 * Histórico das rodadas.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public static function runs(): array {
		$runs = get_option( self::RUNS, array() );
		return is_array( $runs ) ? $runs : array();
	}

	/**
	 * Mensagem de andamento.
	 *
	 * @param array<string, mixed> $job Rodada.
	 */
	private static function progress( array $job, string $phase ): string {
		if ( 'collect' === $phase && ! empty( $job['names'] ) ) {
			/* translators: 1: done, 2: total. */
			return sprintf( __( 'Procurando nas fontes… nome %1$d de %2$d', 'ml-clipping-pro' ), (int) $job['total'] - count( $job['names'] ), (int) $job['total'] );
		}
		/* translators: 1: analysed, 2: remaining, 3: added. */
		return sprintf( __( 'Lendo as matérias… %1$d lidas, %2$d na fila, %3$d novas', 'ml-clipping-pro' ), (int) $job['stats']['analysed'], count( $job['queue'] ), (int) $job['stats']['added'] );
	}

	/**
	 * Resumo final.
	 *
	 * @param array<string, mixed> $job Rodada.
	 */
	private static function summary( array $job ): string {
		$st = $job['stats'];
		if ( (int) $st['added'] > 0 ) {
			$msg = sprintf(
				/* translators: 1: added, 2: discarded. */
				_n( 'Busca concluída: %1$d matéria nova para revisar (%2$d descartadas pela nota).', 'Busca concluída: %1$d matérias novas para revisar (%2$d descartadas pela nota).', (int) $st['added'], 'ml-clipping-pro' ),
				(int) $st['added'],
				(int) $st['discarded']
			);
		} else {
			/* translators: %d: discarded. */
			$msg = sprintf( __( 'Busca concluída: nenhuma matéria nova (%d descartadas pela nota).', 'ml-clipping-pro' ), (int) $st['discarded'] );
		}
		if ( ! empty( $job['errors'] ) ) {
			$msg .= ' ' . __( 'Alguma fonte não respondeu; veja o histórico no Painel.', 'ml-clipping-pro' );
		}
		return $msg;
	}

	/* ====================================================================
	 * Matérias já vistas (não reabre a mesma página todo dia)
	 * ================================================================== */

	/**
	 * @return array<string, int>
	 */
	private static function seen(): array {
		$seen = get_option( self::SEEN, array() );
		return is_array( $seen ) ? $seen : array();
	}

	/**
	 * Guarda (90 dias, no máximo 8.000 entradas).
	 *
	 * @param array<string, int> $seen Lista.
	 */
	private static function save_seen( array $seen ): void {
		$limit = time() - 90 * DAY_IN_SECONDS;
		$seen  = array_filter(
			$seen,
			static function ( $ts ) use ( $limit ) {
				return (int) $ts >= $limit;
			}
		);
		if ( count( $seen ) > 8000 ) {
			arsort( $seen );
			$seen = array_slice( $seen, 0, 8000, true );
		}
		update_option( self::SEEN, $seen, false );
	}

	/**
	 * Esquece as matérias vistas (para reprocessar tudo na próxima busca).
	 */
	public static function forget_seen(): void {
		delete_option( self::SEEN );
	}
}
