<?php
/**
 * Atualização automática pelo GitHub (padrão ML — motor aprovado do ml-duplicate-posts-pages).
 *
 * - Consulta https://api.github.com/repos/mlopesdesign/ml-clipping-pro-releases/releases/latest.
 * - Pacote = release asset com o nome do slug (slug-X.Y.Z.zip). Sem fallback para zipball,
 *   "Source code" ou qualquer outro ZIP: release sem o asset certo não é oferecida.
 * - Preenche response E no_update, responde plugins_api e envia os ícones.
 * - Compara com a versão que o WordPress leu do arquivo ($transient->checked), não com a
 *   constante carregada na memória (evita "nova versão" fantasma logo após atualizar).
 * - Cache de 6 h só para respostas boas; erro de rede/HTTP/JSON não é cacheado nem quebra o painel.
 *
 * @package MLClippingPro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class MLCLIP_GitHub_Updater {

	private const TRANSIENT_KEY = 'mlclip_github_release';
	private const TRANSIENT_TTL = HOUR_IN_SECONDS;
	private const TESTED        = '7.1';
	private const REQUIRES      = '6.0';
	private const REQUIRES_PHP  = '7.4';

	/**
	 * Ganchos.
	 */
	public static function init(): void {
		add_filter( 'pre_set_site_transient_update_plugins', array( __CLASS__, 'check_for_update' ) );
		add_filter( 'plugins_api', array( __CLASS__, 'plugin_info' ), 20, 3 );
		add_filter( 'plugin_row_meta', array( __CLASS__, 'plugin_row_meta' ), 10, 2 );
		add_action( 'upgrader_process_complete', array( __CLASS__, 'flush_after_upgrade' ), 10, 2 );
	}

	/**
	 * Slug = pasta do plugin (nunca o nome do repositório).
	 */
	private static function slug(): string {
		return dirname( MLCLIP_BASENAME );
	}

	/**
	 * Injeta a oferta (ou o "sem atualização") no transient do WordPress.
	 *
	 * @param mixed $transient Transient update_plugins.
	 * @return mixed
	 */
	public static function check_for_update( $transient ) {
		if ( empty( $transient ) || ! is_object( $transient ) || empty( $transient->checked ) ) {
			return $transient;
		}
		$installed = isset( $transient->checked[ MLCLIP_BASENAME ] ) ? (string) $transient->checked[ MLCLIP_BASENAME ] : '';
		if ( '' === $installed ) {
			return $transient;
		}

		$release = self::get_latest_release();
		if ( ! $release || empty( $release['version'] ) || empty( $release['package'] ) ) {
			return $transient;
		}

		$item = (object) array(
			'id'            => MLCLIP_BASENAME,
			'slug'          => self::slug(),
			'plugin'        => MLCLIP_BASENAME,
			'new_version'   => $release['version'],
			'url'           => MLCLIP_GITHUB_REPO_URL,
			'package'       => $release['package'],
			'icons'         => self::icons(),
			'banners'       => array(),
			'banners_rtl'   => array(),
			'tested'        => self::TESTED,
			'requires'      => self::REQUIRES,
			'requires_php'  => self::REQUIRES_PHP,
			'compatibility' => new \stdClass(),
		);

		if ( version_compare( $release['version'], $installed, '>' ) ) {
			if ( ! isset( $transient->response ) || ! is_array( $transient->response ) ) {
				$transient->response = array();
			}
			$transient->response[ MLCLIP_BASENAME ] = $item;
			if ( isset( $transient->no_update ) && is_array( $transient->no_update ) ) {
				unset( $transient->no_update[ MLCLIP_BASENAME ] );
			}
			return $transient;
		}

		// Sem atualização: no_update habilita o botão de atualização automática do WordPress.
		$item->new_version = $installed;
		if ( ! isset( $transient->no_update ) || ! is_array( $transient->no_update ) ) {
			$transient->no_update = array();
		}
		$transient->no_update[ MLCLIP_BASENAME ] = $item;
		if ( isset( $transient->response ) && is_array( $transient->response ) ) {
			unset( $transient->response[ MLCLIP_BASENAME ] );
		}
		return $transient;
	}

	/**
	 * Ícones ML (sem eles o WordPress mostra o ícone genérico).
	 *
	 * @return array<string, string>
	 */
	private static function icons(): array {
		$base = MLCLIP_URL . 'assets/images/';
		return array(
			'1x'      => $base . 'icon-128x128.png',
			'2x'      => $base . 'icon-256x256.png',
			'default' => $base . 'icon-256x256.png',
		);
	}

	/**
	 * Janela "Ver detalhes".
	 *
	 * @param mixed  $result Resultado.
	 * @param string $action Ação.
	 * @param object $args   Argumentos.
	 * @return mixed
	 */
	public static function plugin_info( $result, $action, $args ) {
		if ( 'plugin_information' !== $action || empty( $args->slug ) || self::slug() !== $args->slug ) {
			return $result;
		}
		$release = self::get_latest_release();
		return (object) array(
			'name'          => 'ML Clipping Pro',
			'slug'          => self::slug(),
			'version'       => ! empty( $release['version'] ) ? $release['version'] : MLCLIP_VERSION,
			'author'        => '<a href="https://mlopesdesign.com.br/">ML Lopes Design</a>',
			'homepage'      => 'https://tools.mlopesdesign.com.br/produtos/',
			'download_link' => ! empty( $release['package'] ) ? $release['package'] : '',
			'requires'      => self::REQUIRES,
			'requires_php'  => self::REQUIRES_PHP,
			'tested'        => self::TESTED,
			'last_updated'  => ! empty( $release['published'] ) ? $release['published'] : '',
			'icons'         => self::icons(),
			'sections'      => array(
				'description' => esc_html__( 'Clipping de imprensa automático: busca diária das matérias que citam os nomes escolhidos, fila de aprovação, aviso por e-mail e layout de jornal no site.', 'ml-clipping-pro' ),
				'changelog'   => ! empty( $release['changelog'] ) ? $release['changelog'] : esc_html__( 'Consulte as notas da versão.', 'ml-clipping-pro' ),
			),
		);
	}

	/**
	 * Links na linha do plugin.
	 *
	 * @param array<int, string> $meta        Links.
	 * @param string             $plugin_file Arquivo.
	 * @return array<int, string>
	 */
	public static function plugin_row_meta( $meta, $plugin_file ) {
		if ( MLCLIP_BASENAME !== $plugin_file ) {
			return $meta;
		}
		$meta[] = '<a href="' . esc_url( MLCLIP_Helpers::admin_url( 'dashboard' ) ) . '">' . esc_html__( 'Painel', 'ml-clipping-pro' ) . '</a>';
		if ( current_user_can( 'update_plugins' ) ) {
			$meta[] = '<a href="' . esc_url( admin_url( 'update-core.php?force-check=1&mlclip-check-update=1' ) ) . '">' . esc_html__( 'Verificar atualização', 'ml-clipping-pro' ) . '</a>';
		}
		// "Notas das versões" só quando já existe uma release publicada (antes disso o link daria 404).
		$release = get_transient( self::TRANSIENT_KEY );
		if ( is_array( $release ) && ! empty( $release['version'] ) ) {
			$meta[] = '<a href="' . esc_url( MLCLIP_GITHUB_REPO_URL . '/releases' ) . '" target="_blank" rel="noopener noreferrer">' . esc_html__( 'Notas das versões', 'ml-clipping-pro' ) . '</a>';
		}
		return $meta;
	}

	/**
	 * Depois de atualizar este plugin, descarta o cache da release.
	 *
	 * @param object               $upgrader Upgrader.
	 * @param array<string, mixed> $options  Opções.
	 */
	public static function flush_after_upgrade( $upgrader, $options ): void {
		if ( 'plugin' === ( $options['type'] ?? '' ) && in_array( MLCLIP_BASENAME, (array) ( $options['plugins'] ?? array() ), true ) ) {
			delete_transient( self::TRANSIENT_KEY );
		}
	}

	/**
	 * Última release (cache de 6 h só quando a resposta é válida).
	 *
	 * @return array<string, string>|null
	 */
	private static function get_latest_release(): ?array {
		// "Verificar novamente" (Painel > Atualizações) ou "Verificar atualização" no plugin: pergunta na hora.
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- só descarta cache, com permissão.
		$force  = is_admin() && ( isset( $_GET['force-check'] ) || isset( $_GET['mlclip-check-update'] ) ) && current_user_can( 'update_plugins' );
		$cached = $force ? false : get_transient( self::TRANSIENT_KEY );
		if ( is_array( $cached ) ) {
			return $cached;
		}

		$url      = sprintf( 'https://api.github.com/repos/%s/%s/releases/latest', rawurlencode( MLCLIP_GITHUB_OWNER ), rawurlencode( MLCLIP_GITHUB_REPO ) );
		$response = wp_remote_get(
			$url,
			array(
				'timeout' => 12,
				'headers' => array(
					'Accept'     => 'application/vnd.github+json',
					'User-Agent' => 'WordPress/' . get_bloginfo( 'version' ) . '; ' . home_url( '/' ),
				),
			)
		);
		$code = is_wp_error( $response ) ? 0 : (int) wp_remote_retrieve_response_code( $response );
		if ( $code < 200 || $code >= 300 ) {
			// API fora ou limite de consultas do GitHub (comum em hospedagem compartilhada): pela página pública.
			return self::latest_from_page();
		}
		$body = json_decode( (string) wp_remote_retrieve_body( $response ), true );
		if ( ! is_array( $body ) || empty( $body['tag_name'] ) ) {
			return null;
		}

		$version = ltrim( (string) $body['tag_name'], 'vV' );
		$package = self::find_release_package( $body, $version );
		if ( '' === $package ) {
			// Release sem o ZIP do slug: incompleta, não é oferecida.
			return null;
		}

		$release = array(
			'version'   => $version,
			'package'   => $package,
			'changelog' => ! empty( $body['body'] ) ? wp_kses_post( wpautop( (string) $body['body'] ) ) : '',
			'published' => ! empty( $body['published_at'] ) ? (string) $body['published_at'] : '',
		);
		set_transient( self::TRANSIENT_KEY, $release, self::TRANSIENT_TTL );
		return $release;
	}

	/**
	 * Última versão sem a API (sem limite de consultas): o endereço /releases/latest redireciona
	 * para /releases/tag/vX.Y.Z e o ZIP segue o nome padrão slug-X.Y.Z.zip.
	 *
	 * @return array<string, string>|null
	 */
	private static function latest_from_page(): ?array {
		$base = sprintf( 'https://github.com/%s/%s/releases', rawurlencode( MLCLIP_GITHUB_OWNER ), rawurlencode( MLCLIP_GITHUB_REPO ) );
		$res  = wp_remote_head( $base . '/latest', array( 'timeout' => 10, 'redirection' => 0 ) );
		if ( is_wp_error( $res ) ) {
			return null;
		}
		$loc = (string) wp_remote_retrieve_header( $res, 'location' );
		if ( ! preg_match( '#/releases/tag/v?(\d+\.\d+\.\d+)#', $loc, $m ) ) {
			return null;
		}
		$version = $m[1];
		$package = $base . '/download/v' . $version . '/' . self::slug() . '-' . $version . '.zip';
		$head    = wp_remote_head( $package, array( 'timeout' => 10, 'redirection' => 0 ) );
		$code    = is_wp_error( $head ) ? 0 : (int) wp_remote_retrieve_response_code( $head );
		if ( $code < 200 || $code >= 400 ) {
			return null; // Release sem o ZIP do slug: não oferece.
		}
		$release = array(
			'version'   => $version,
			'package'   => esc_url_raw( $package ),
			'changelog' => '',
			'published' => '',
		);
		set_transient( self::TRANSIENT_KEY, $release, self::TRANSIENT_TTL );
		return $release;
	}

	/**
	 * Só o asset do próprio slug e da própria versão.
	 *
	 * @param array<string, mixed> $release Release.
	 */
	private static function find_release_package( array $release, string $version ): string {
		if ( empty( $release['assets'] ) || ! is_array( $release['assets'] ) ) {
			return '';
		}
		$names = array(
			self::slug() . '-' . $version . '.zip',
			self::slug() . '-v' . $version . '.zip',
		);
		foreach ( $release['assets'] as $asset ) {
			if ( ! empty( $asset['name'] ) && in_array( $asset['name'], $names, true ) && ! empty( $asset['browser_download_url'] ) ) {
				return esc_url_raw( (string) $asset['browser_download_url'] );
			}
		}
		return '';
	}
}
