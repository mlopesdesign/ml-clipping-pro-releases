<?php
/**
 * Fontes de busca gratuitas e sem chave: Google Notícias (RSS), Bing Notícias (RSS) e GDELT.
 *
 * Cada fonte devolve "candidatos" no mesmo formato:
 * title, url, outlet, host, date (timestamp), summary, image, origin, wrapped (link do Google a resolver).
 *
 * Testado do PC do Marcio em 04/11/2026: Google 54 itens, Bing 12 itens para "Cacique de Ramos";
 * link do Google resolvido pelo batchexecute; GDELT exige 1 consulta a cada 5 segundos.
 *
 * @package MLClippingPro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class MLCLIP_Sources {

	/**
	 * Parâmetros regionais por idioma/país.
	 *
	 * @return array{hl:string,gl:string,ceid:string,bing:string,cc:string,gdelt:string}
	 */
	private static function region( string $region ): array {
		$map = array(
			'pt-BR' => array( 'hl' => 'pt-BR', 'gl' => 'BR', 'ceid' => 'BR:pt-419', 'bing' => 'pt-BR', 'cc' => 'BR', 'gdelt' => 'sourcelang:portuguese' ),
			'pt-PT' => array( 'hl' => 'pt-PT', 'gl' => 'PT', 'ceid' => 'PT:pt-150', 'bing' => 'pt-PT', 'cc' => 'PT', 'gdelt' => 'sourcelang:portuguese' ),
			'en-US' => array( 'hl' => 'en-US', 'gl' => 'US', 'ceid' => 'US:en', 'bing' => 'en-US', 'cc' => 'US', 'gdelt' => 'sourcelang:english' ),
			'es-ES' => array( 'hl' => 'es', 'gl' => 'ES', 'ceid' => 'ES:es', 'bing' => 'es-ES', 'cc' => 'ES', 'gdelt' => 'sourcelang:spanish' ),
			'es-AR' => array( 'hl' => 'es-419', 'gl' => 'AR', 'ceid' => 'AR:es-419', 'bing' => 'es-AR', 'cc' => 'AR', 'gdelt' => 'sourcelang:spanish' ),
		);
		return $map[ $region ] ?? $map['pt-BR'];
	}

	/**
	 * Expressão de busca: "nome" OR "variação", com exclusões.
	 *
	 * @param array<string, mixed> $n Nome.
	 */
	private static function query( array $n, bool $with_excludes = true ): string {
		$forms = array();
		foreach ( MLCLIP_Names::forms( $n ) as $form ) {
			$forms[] = '"' . str_replace( '"', '', $form ) . '"';
		}
		$q = count( $forms ) > 1 ? implode( ' OR ', $forms ) : (string) reset( $forms );
		if ( $with_excludes ) {
			foreach ( (array) $n['exclude'] as $word ) {
				$q .= ' -"' . str_replace( '"', '', (string) $word ) . '"';
			}
		}
		return $q;
	}

	/**
	 * Busca em todas as fontes ligadas.
	 *
	 * @param array<string, mixed> $n    Nome.
	 * @param int                  $days Janela em dias.
	 * @return array{items: array<int, array<string, mixed>>, errors: array<string, string>, counts: array<string, int>}
	 */
	public static function search( array $n, int $days ): array {
		$items  = array();
		$errors = array();
		$counts = array();
		$map    = array(
			'google' => 'src_google',
			'bing'   => 'src_bing',
			'gdelt'  => 'src_gdelt',
		);
		foreach ( $map as $source => $option ) {
			if ( ! MLCLIP_Settings::on( $option ) ) {
				continue;
			}
			$res = call_user_func( array( __CLASS__, $source ), $n, $days );
			if ( is_wp_error( $res ) ) {
				$errors[ $source ] = $res->get_error_message();
				$counts[ $source ] = 0;
				continue;
			}
			$counts[ $source ] = count( $res );
			$items             = array_merge( $items, $res );
		}
		return array(
			'items'  => $items,
			'errors' => $errors,
			'counts' => $counts,
		);
	}

	/**
	 * Lê RSS com segurança.
	 *
	 * @return \SimpleXMLElement|\WP_Error
	 */
	private static function rss( string $url ) {
		$res = MLCLIP_Http::get( $url, array( 'headers' => array( 'Accept' => 'application/rss+xml,application/xml;q=0.9,*/*;q=0.5' ) ) );
		if ( is_wp_error( $res ) ) {
			return $res;
		}
		if ( 200 !== $res[0] ) {
			/* translators: %d: HTTP status. */
			return new \WP_Error( 'mlclip_rss_http', sprintf( __( 'A fonte respondeu com erro %d.', 'ml-clipping-pro' ), $res[0] ) );
		}
		if ( ! function_exists( 'simplexml_load_string' ) ) {
			return new \WP_Error( 'mlclip_rss_xml', __( 'O servidor não tem a extensão SimpleXML do PHP.', 'ml-clipping-pro' ) );
		}
		$prev = libxml_use_internal_errors( true );
		$xml  = simplexml_load_string( $res[1], 'SimpleXMLElement', LIBXML_NOCDATA | LIBXML_NONET );
		libxml_clear_errors();
		libxml_use_internal_errors( $prev );
		if ( ! $xml || ! isset( $xml->channel ) ) {
			return new \WP_Error( 'mlclip_rss_parse', __( 'A fonte devolveu uma resposta que não é RSS.', 'ml-clipping-pro' ) );
		}
		return $xml;
	}

	/* ------------------------------------------------------------ Google */

	/**
	 * Google Notícias.
	 *
	 * @param array<string, mixed> $n Nome.
	 * @return array<int, array<string, mixed>>|\WP_Error
	 */
	public static function google( array $n, int $days ) {
		$r   = self::region( (string) $n['region'] );
		$q   = self::query( $n ) . ' when:' . max( 1, min( 365, $days ) ) . 'd';
		$url = add_query_arg(
			array(
				'q'    => rawurlencode( $q ),
				'hl'   => $r['hl'],
				'gl'   => $r['gl'],
				'ceid' => rawurlencode( $r['ceid'] ),
			),
			'https://news.google.com/rss/search'
		);
		$xml = self::rss( $url );
		if ( is_wp_error( $xml ) ) {
			return $xml;
		}
		$out = array();
		foreach ( $xml->channel->item as $item ) {
			$outlet = trim( (string) $item->source );
			$title  = trim( (string) $item->title );
			if ( '' !== $outlet && substr( $title, -strlen( ' - ' . $outlet ) ) === ' - ' . $outlet ) {
				$title = trim( substr( $title, 0, -strlen( ' - ' . $outlet ) ) );
			}
			$source_url = isset( $item->source['url'] ) ? (string) $item->source['url'] : '';
			$out[]      = array(
				'title'   => $title,
				'url'     => (string) $item->link,
				'wrapped' => true,
				'outlet'  => $outlet,
				'host'    => MLCLIP_Helpers::host( $source_url ),
				'date'    => MLCLIP_Helpers::timestamp( (string) $item->pubDate ),
				'summary' => '',
				'image'   => '',
				'origin'  => 'google',
			);
		}
		return $out;
	}

	/**
	 * Resolve o link "embrulhado" do Google Notícias para o link real do veículo.
	 * Devolve '' quando não foi possível (o candidato é descartado sem gravar link do Google).
	 */
	public static function resolve_google( string $link ): string {
		if ( ! preg_match( '#news\.google\.com/(?:rss/)?articles/([A-Za-z0-9_-]+)#', $link, $m ) ) {
			return MLCLIP_Helpers::is_url( $link ) ? $link : '';
		}
		$id = $m[1];

		// Formato antigo: o link real está dentro do próprio identificador (base64 + protobuf).
		$raw = base64_decode( strtr( $id, '-_', '+/' ) . str_repeat( '=', ( 4 - strlen( $id ) % 4 ) % 4 ), true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- formato público do Google Notícias.
		if ( is_string( $raw ) && preg_match( '#https?://[\x21-\x7e]+#', $raw, $u ) && false === strpos( $u[0], 'news.google.com' ) && MLCLIP_Helpers::is_url( $u[0] ) ) {
			return $u[0];
		}

		// Formato atual: assinatura e data na página do artigo + batchexecute.
		$page = MLCLIP_Http::get( 'https://news.google.com/rss/articles/' . $id, array( 'timeout' => 10 ) );
		if ( is_wp_error( $page ) || 200 !== $page[0] ) {
			return '';
		}
		if ( ! preg_match( '/data-n-a-sg="([^"]+)"/', $page[1], $sg ) || ! preg_match( '/data-n-a-ts="([^"]+)"/', $page[1], $ts ) ) {
			return '';
		}
		$inner = wp_json_encode(
			array(
				'garturlreq',
				array( array( 'X', 'X', array( 'X', 'X' ), null, null, 1, 1, 'US:en', null, 1, null, null, null, null, null, 0, 1 ), 'X', 'X', 1, array( 1, 1, 1 ), 1, 1, null, 0, 0, null, 0 ),
				$id,
				(int) $ts[1],
				$sg[1],
			)
		);
		$freq = wp_json_encode( array( array( array( 'Fbv4je', $inner, null, 'generic' ) ) ) );
		$res  = MLCLIP_Http::post(
			'https://news.google.com/_/DotsSplashUi/data/batchexecute',
			array( 'f.req' => (string) $freq ),
			array( 'Content-Type' => 'application/x-www-form-urlencoded;charset=UTF-8' )
		);
		if ( is_wp_error( $res ) || 200 !== $res[0] ) {
			return '';
		}
		if ( preg_match( '/garturlres\\\\",\\\\"(https?:[^"\\\\]+)/', $res[1], $u ) ) {
			$url = str_replace( array( '\\u003d', '\\u0026' ), array( '=', '&' ), $u[1] );
			return MLCLIP_Helpers::is_url( $url ) ? $url : '';
		}
		return '';
	}

	/* ------------------------------------------------------------ Bing */

	/**
	 * Bing Notícias.
	 *
	 * @param array<string, mixed> $n Nome.
	 * @return array<int, array<string, mixed>>|\WP_Error
	 */
	public static function bing( array $n, int $days ) {
		$r   = self::region( (string) $n['region'] );
		$url = add_query_arg(
			array(
				'q'       => rawurlencode( self::query( $n ) ),
				'format'  => 'rss',
				'setlang' => $r['bing'],
				'cc'      => $r['cc'],
				'qft'     => rawurlencode( 'sortbydate="1"' ),
			),
			'https://www.bing.com/news/search'
		);
		$xml = self::rss( $url );
		if ( is_wp_error( $xml ) ) {
			return $xml;
		}
		$limit = time() - ( max( 1, $days ) + 1 ) * DAY_IN_SECONDS;
		$out   = array();
		foreach ( $xml->channel->item as $item ) {
			$link = (string) $item->link;
			if ( preg_match( '/[?&]url=([^&]+)/', $link, $m ) ) {
				$link = rawurldecode( $m[1] );
			}
			if ( ! MLCLIP_Helpers::is_url( $link ) ) {
				continue;
			}
			$date = MLCLIP_Helpers::timestamp( (string) $item->pubDate );
			if ( $date && $date < $limit ) {
				continue;
			}
			$ns     = $item->children( 'News', true );
			$outlet = isset( $ns->Source ) ? trim( (string) $ns->Source ) : '';
			$image  = isset( $ns->Image ) ? (string) $ns->Image : '';
			$out[]  = array(
				'title'   => trim( (string) $item->title ),
				'url'     => $link,
				'wrapped' => false,
				'outlet'  => $outlet,
				'host'    => MLCLIP_Helpers::host( $link ),
				'date'    => $date,
				'summary' => MLCLIP_Helpers::excerpt( (string) $item->description, 400 ),
				'image'   => MLCLIP_Helpers::is_url( $image ) ? $image : '',
				'origin'  => 'bing',
			);
		}
		return $out;
	}

	/* ------------------------------------------------------------ GDELT */

	/**
	 * GDELT (base mundial de notícias). Limite do serviço: 1 consulta a cada 5 segundos.
	 *
	 * @param array<string, mixed> $n Nome.
	 * @return array<int, array<string, mixed>>|\WP_Error
	 */
	public static function gdelt( array $n, int $days ) {
		$wait = (int) get_transient( 'mlclip_gdelt_next' ) - time();
		if ( $wait > 0 ) {
			sleep( min( 6, $wait ) );
		}
		set_transient( 'mlclip_gdelt_next', time() + 6, MINUTE_IN_SECONDS );

		$r     = self::region( (string) $n['region'] );
		$forms = array();
		foreach ( MLCLIP_Names::forms( $n ) as $form ) {
			// GDELT recusa frases muito curtas; nomes de 1 palavra curtos ficam de fora desta fonte.
			if ( strlen( $form ) >= 4 ) {
				$forms[] = '"' . str_replace( '"', '', $form ) . '"';
			}
		}
		if ( ! $forms ) {
			return array();
		}
		$q   = ( count( $forms ) > 1 ? '(' . implode( ' OR ', $forms ) . ')' : $forms[0] ) . ' ' . $r['gdelt'];
		$url = add_query_arg(
			array(
				'query'      => rawurlencode( $q ),
				'mode'       => 'artlist',
				'format'     => 'json',
				'maxrecords' => 75,
				'timespan'   => max( 1, min( 90, $days ) ) . 'd',
				'sort'       => 'datedesc',
			),
			'https://api.gdeltproject.org/api/v2/doc/doc'
		);
		$res = MLCLIP_Http::get( $url, array( 'headers' => array( 'Accept' => 'application/json' ) ) );
		if ( is_wp_error( $res ) ) {
			return $res;
		}
		$data = json_decode( $res[1], true );
		if ( 200 !== $res[0] || ! is_array( $data ) ) {
			// O GDELT responde texto quando está sobrecarregado; não é erro do site.
			return new \WP_Error( 'mlclip_gdelt', __( 'O GDELT está ocupado agora; tenta de novo na próxima busca.', 'ml-clipping-pro' ) );
		}
		$out = array();
		foreach ( (array) ( $data['articles'] ?? array() ) as $a ) {
			$link = (string) ( $a['url'] ?? '' );
			if ( ! MLCLIP_Helpers::is_url( $link ) ) {
				continue;
			}
			$image = (string) ( $a['socialimage'] ?? '' );
			$out[] = array(
				'title'   => trim( (string) ( $a['title'] ?? '' ) ),
				'url'     => $link,
				'wrapped' => false,
				'outlet'  => '',
				'host'    => MLCLIP_Helpers::host( (string) ( $a['domain'] ?? $link ) ),
				'date'    => MLCLIP_Helpers::timestamp( (string) ( $a['seendate'] ?? '' ) ),
				'summary' => '',
				'image'   => MLCLIP_Helpers::is_url( $image ) ? $image : '',
				'origin'  => 'gdelt',
			);
		}
		return $out;
	}
}
