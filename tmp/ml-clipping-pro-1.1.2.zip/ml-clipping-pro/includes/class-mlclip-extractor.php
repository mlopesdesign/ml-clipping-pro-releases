<?php
/**
 * Lê a página original da matéria e tira título, resumo, foto, data real, veículo
 * e o começo do texto (usado na nota de relevância). Usa as marcações que os veículos
 * publicam para redes sociais (og:), JSON-LD e <time>.
 *
 * @package MLClippingPro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class MLCLIP_Extractor {

	/**
	 * Hosts de vídeo.
	 *
	 * @var array<int, string>
	 */
	private const VIDEO_HOSTS = array( 'youtube.com', 'youtu.be', 'globoplay.globo.com', 'vimeo.com', 'dailymotion.com', 'tiktok.com' );

	/**
	 * Abre o link e extrai os dados.
	 *
	 * @return array<string, mixed>|\WP_Error
	 */
	public static function fetch( string $url ) {
		$res = MLCLIP_Http::get( $url );
		if ( is_wp_error( $res ) ) {
			return $res;
		}
		if ( $res[0] >= 400 || '' === $res[1] ) {
			/* translators: %d: HTTP status. */
			return new \WP_Error( 'mlclip_page', sprintf( __( 'A página da matéria respondeu com erro %d.', 'ml-clipping-pro' ), $res[0] ) );
		}
		return self::parse( $res[1], $res[2] ? $res[2] : $url );
	}

	/**
	 * Extrai os dados de um HTML.
	 *
	 * @return array<string, mixed>
	 */
	public static function parse( string $html, string $url ): array {
		$meta = self::metas( $html );
		$ld   = self::json_ld( $html );

		$canonical = '';
		if ( ! empty( $meta['og:url'] ) && MLCLIP_Helpers::is_url( $meta['og:url'] ) ) {
			$canonical = $meta['og:url'];
		} elseif ( preg_match( '/<link[^>]+rel=["\']canonical["\'][^>]*>/i', $html, $m ) && preg_match( '/href=["\']([^"\']+)["\']/i', $m[0], $h ) ) {
			$canonical = html_entity_decode( $h[1], ENT_QUOTES, 'UTF-8' );
		}
		// O canônico só vale se for do mesmo site (evita páginas que apontam para a home).
		if ( '' !== $canonical && ( ! MLCLIP_Helpers::is_url( $canonical ) || MLCLIP_Helpers::host( $canonical ) !== MLCLIP_Helpers::host( $url ) || '' === trim( (string) wp_parse_url( $canonical, PHP_URL_PATH ), '/' ) ) ) {
			$canonical = '';
		}
		$final = '' !== $canonical ? $canonical : $url;
		$host  = MLCLIP_Helpers::host( $final );

		$html_title = preg_match( '/<title[^>]*>(.*?)<\/title>/is', $html, $m ) ? self::clean( $m[1] ) : '';
		$title      = self::first( $meta, array( 'og:title', 'twitter:title' ) );
		if ( '' === $title && ! empty( $ld['headline'] ) ) {
			$title = (string) $ld['headline'];
		}
		if ( '' === $title ) {
			$title = $html_title;
		}
		$title = self::clean( $title );

		$desc = self::first( $meta, array( 'og:description', 'description', 'twitter:description' ) );
		if ( '' === $desc && ! empty( $ld['description'] ) ) {
			$desc = (string) $ld['description'];
		}

		$image = self::first( $meta, array( 'og:image:secure_url', 'og:image', 'twitter:image', 'twitter:image:src' ) );
		if ( '' === $image && ! empty( $ld['image'] ) ) {
			$image = (string) $ld['image'];
		}
		if ( '' === $image && preg_match( '/<link[^>]+rel=["\']image_src["\'][^>]*href=["\']([^"\']+)["\']/i', $html, $m ) ) {
			$image = html_entity_decode( $m[1], ENT_QUOTES, 'UTF-8' );
		}
		if ( '' === $image ) {
			$image = self::content_image( $html );
		}
		$image = self::absolute( $image, $url );
		$image = MLCLIP_Helpers::is_url( $image ) ? $image : '';

		$site = self::clean( self::first( $meta, array( 'og:site_name', 'application-name' ) ) );
		if ( '' === $site && ! empty( $ld['publisher'] ) ) {
			$site = self::clean( (string) $ld['publisher'] );
		}
		// Nomes genéricos de plataforma não são o veículo.
		if ( in_array( MLCLIP_Helpers::fold( $site ), array( 'blogger', 'wordpress', 'wordpress com', 'blogspot', 'medium', 'wix', 'home', 'inicio', 'noticias' ), true ) ) {
			$site = '';
		}
		// Sem og:site_name: o último pedaço do <title> ("Matéria - Correio Carioca") costuma ser o veículo.
		if ( '' === $site ) {
			$site = self::site_from_title( '' !== $html_title ? $html_title : $title, $host );
		}
		$outlet = '' !== $site ? $site : MLCLIP_Helpers::outlet_from_host( $host );
		$title  = self::strip_outlet( $title, $outlet, $host );

		$type  = strtolower( self::first( $meta, array( 'og:type' ) ) );
		$video = 0 === strpos( $type, 'video' ) || MLCLIP_Helpers::host_in( $host, self::VIDEO_HOSTS );
		$date  = self::date( $meta, $ld, $html, $final, $title, $video );

		return array(
			'url'     => $final,
			'host'    => $host,
			'title'   => $title,
			'excerpt' => MLCLIP_Helpers::excerpt( $desc, 320 ),
			'image'   => $image,
			'outlet'  => $outlet,
			'date'    => $date,
			'media'   => $video ? 'video' : 'texto',
			'body'    => self::body_text( $html ),
		);
	}

	/**
	 * Todas as <meta> da página: property/name/itemprop → content.
	 *
	 * @return array<string, string>
	 */
	private static function metas( string $html ): array {
		$out  = array();
		$head = substr( $html, 0, 300000 );
		if ( ! preg_match_all( '/<meta\s[^>]*>/i', $head, $tags ) ) {
			return $out;
		}
		foreach ( $tags[0] as $tag ) {
			if ( ! preg_match( '/(?:property|name|itemprop)\s*=\s*["\']([^"\']+)["\']/i', $tag, $k ) || ! preg_match( '/content\s*=\s*("([^"]*)"|\'([^\']*)\')/i', $tag, $v ) ) {
				continue;
			}
			$key = strtolower( trim( $k[1] ) );
			if ( ! isset( $out[ $key ] ) ) {
				$out[ $key ] = html_entity_decode( '' !== ( $v[2] ?? '' ) ? $v[2] : ( $v[3] ?? '' ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );
			}
		}
		return $out;
	}

	/**
	 * Primeiro valor preenchido.
	 *
	 * @param array<string, string> $meta Metas.
	 * @param array<int, string>    $keys Chaves.
	 */
	private static function first( array $meta, array $keys ): string {
		foreach ( $keys as $k ) {
			if ( ! empty( $meta[ $k ] ) ) {
				return trim( (string) $meta[ $k ] );
			}
		}
		return '';
	}

	/**
	 * Dados do JSON-LD (NewsArticle, Article, VideoObject...).
	 *
	 * @return array<string, string>
	 */
	private static function json_ld( string $html ): array {
		$out = array();
		if ( ! preg_match_all( '/<script[^>]+application\/ld\+json[^>]*>(.*?)<\/script>/is', $html, $blocks ) ) {
			return $out;
		}
		foreach ( $blocks[1] as $json ) {
			$data = json_decode( trim( $json ), true );
			if ( ! is_array( $data ) ) {
				continue;
			}
			$nodes = isset( $data['@graph'] ) && is_array( $data['@graph'] ) ? $data['@graph'] : ( isset( $data[0] ) ? $data : array( $data ) );
			foreach ( $nodes as $node ) {
				if ( ! is_array( $node ) ) {
					continue;
				}
				$type = isset( $node['@type'] ) ? implode( ',', (array) $node['@type'] ) : '';
				if ( ! preg_match( '/Article|Posting|VideoObject|WebPage|Report/i', $type ) ) {
					continue;
				}
				foreach ( array( 'datePublished', 'uploadDate', 'dateCreated', 'headline', 'description' ) as $key ) {
					if ( empty( $out[ $key ] ) && ! empty( $node[ $key ] ) && is_string( $node[ $key ] ) ) {
						$out[ $key ] = $node[ $key ];
					}
				}
				if ( empty( $out['image'] ) && ! empty( $node['image'] ) ) {
					$img = $node['image'];
					if ( is_array( $img ) ) {
						$img = $img['url'] ?? ( $img[0]['url'] ?? ( $img[0] ?? '' ) );
					}
					$out['image'] = is_string( $img ) ? $img : '';
				}
				if ( empty( $out['publisher'] ) && ! empty( $node['publisher']['name'] ) && is_string( $node['publisher']['name'] ) ) {
					$out['publisher'] = $node['publisher']['name'];
				}
			}
		}
		return $out;
	}

	/**
	 * Data real de publicação (0 = não encontrada).
	 *
	 * @param array<string, string> $meta Metas.
	 * @param array<string, string> $ld   JSON-LD.
	 */
	private static function date( array $meta, array $ld, string $html, string $url, string $title = '', bool $video = false ): int {
		$found   = self::date_meta( $meta, $ld, $html );
		$in_url  = self::date_from_url( $url );
		// O endereço com /AAAA/MM/ é mais confiável que metadados de atualização do site.
		if ( $in_url && ( ! $found || abs( $found - $in_url ) > 45 * DAY_IN_SECONDS ) ) {
			return $in_url;
		}
		// Data escrita no título ("RJ2 - 13/02/2024") só vale sem metadado, ou em página de vídeo cujo
		// metadado é a data de hoje (portal de vídeo põe a data da página). Matéria citando outra data mantém o metadado.
		$text = self::date_in_text( $title );
		if ( $text && ( ! $found || ( $video && $found > time() - 36 * HOUR_IN_SECONDS ) ) ) {
			return $text;
		}
		if ( $found ) {
			return $found;
		}
		// Data de atualização só depois das datas de publicação, do endereço e do título.
		foreach ( array( 'article:modified_time', 'og:updated_time' ) as $k ) {
			$ts = MLCLIP_Helpers::timestamp( (string) ( $meta[ $k ] ?? '' ) );
			if ( $ts ) {
				return $ts;
			}
		}
		return self::date_in_text( substr( (string) preg_replace( '/\s+/', ' ', wp_strip_all_tags( (string) preg_replace( '#<(script|style|nav|header|footer|aside)\b[^>]*>.*?</\1>#is', ' ', $html ) ) ), 0, 6000 ) );
	}

	/**
	 * Data nos metadados da página.
	 *
	 * @param array<string, string> $meta Metas.
	 * @param array<string, string> $ld   JSON-LD.
	 */
	private static function date_meta( array $meta, array $ld, string $html ): int {
		$candidates = array(
			$meta['article:published_time'] ?? '',
			$ld['datePublished'] ?? '',
			$ld['uploadDate'] ?? '',
			$meta['datepublished'] ?? '',
			$meta['og:published_time'] ?? '',
			$meta['date'] ?? '',
			$meta['dc.date'] ?? '',
			$meta['dc.date.issued'] ?? '',
			$meta['sailthru.date'] ?? '',
			$meta['parsely-pub-date'] ?? '',
			$ld['dateCreated'] ?? '',
		);
		foreach ( $candidates as $value ) {
			$ts = MLCLIP_Helpers::timestamp( (string) $value );
			if ( $ts ) {
				return $ts;
			}
		}
		if ( preg_match( '/<time[^>]+datetime=["\']([^"\']+)["\']/i', $html, $m ) ) {
			$ts = MLCLIP_Helpers::timestamp( $m[1] );
			if ( $ts ) {
				return $ts;
			}
		}
		if ( preg_match( '/<abbr[^>]+class=["\'][^"\']*published[^"\']*["\'][^>]+title=["\']([^"\']+)["\']/i', $html, $m ) ) {
			$ts = MLCLIP_Helpers::timestamp( $m[1] );
			if ( $ts ) {
				return $ts;
			}
		}
		return 0;
	}

	/**
	 * Primeira data escrita no texto: 13/02/2024 ou 13 de fevereiro de 2024.
	 */
	public static function date_in_text( string $text ): int {
		if ( '' === $text ) {
			return 0;
		}
		if ( preg_match( '#\b(0?[1-9]|[12]\d|3[01])/(0?[1-9]|1[0-2])/((?:19|20)\d{2})\b#', $text, $m ) ) {
			return MLCLIP_Helpers::timestamp( sprintf( '%04d-%02d-%02d 12:00:00', $m[3], $m[2], $m[1] ) );
		}
		$months = array( 'janeiro' => 1, 'fevereiro' => 2, 'marco' => 3, 'abril' => 4, 'maio' => 5, 'junho' => 6, 'julho' => 7, 'agosto' => 8, 'setembro' => 9, 'outubro' => 10, 'novembro' => 11, 'dezembro' => 12 );
		$f      = MLCLIP_Helpers::fold( $text );
		if ( preg_match( '/\b(0?[1-9]|[12]\d|3[01]) de (' . implode( '|', array_keys( $months ) ) . ') de ((?:19|20)\d{2})\b/', $f, $m ) ) {
			return MLCLIP_Helpers::timestamp( sprintf( '%04d-%02d-%02d 12:00:00', $m[3], $months[ $m[2] ], $m[1] ) );
		}
		return 0;
	}

	/**
	 * Veículo a partir do fim do título ("… - Correio Carioca" / "… | O Dia").
	 */
	private static function site_from_title( string $title, string $host ): string {
		$parts = preg_split( '/\s+[|\-–—]\s+/u', $title );
		if ( count( $parts ) < 2 ) {
			return '';
		}
		$last  = trim( (string) end( $parts ) );
		$words = count( preg_split( '/\s+/', $last ) );
		$base  = MLCLIP_Helpers::fold( (string) explode( '.', $host )[0] );
		$flat  = str_replace( ' ', '', MLCLIP_Helpers::fold( $last ) );
		// Aceita quando tem o nome do domínio, ou é curto, sem números e sem pontuação de manchete.
		if ( '' !== $base && ( false !== strpos( $flat, $base ) || false !== strpos( $base, $flat ) ) ) {
			return $last;
		}
		if ( $words <= 3 && ! preg_match( '/[0-9!?:;,]/u', $last ) ) {
			return $last;
		}
		return '';
	}

	/**
	 * Tira o nome do veículo do fim do título ("Matéria - G1" → "Matéria").
	 */
	public static function strip_outlet( string $title, string $outlet, string $host ): string {
		$base  = MLCLIP_Helpers::fold( (string) explode( '.', preg_replace( '/^(www|m|g1|noticias)\./', '', $host ) )[0] );
		$names = array_filter( array( MLCLIP_Helpers::fold( $outlet ), $base ) );
		for ( $i = 0; $i < 3; $i++ ) {
			if ( ! preg_match( '/^(.{12,}?)\s+[|\-–—]\s+([^|\-–—]{1,60})$/u', $title, $m ) ) {
				break;
			}
			$tail = MLCLIP_Helpers::fold( $m[2] );
			$flat = str_replace( ' ', '', $tail );
			$hit  = false;
			foreach ( $names as $n ) {
				$nf = str_replace( ' ', '', $n );
				if ( '' !== $nf && ( false !== strpos( $flat, $nf ) || false !== strpos( $nf, $flat ) ) ) {
					$hit = true;
					break;
				}
			}
			if ( ! $hit ) {
				break;
			}
			$title = trim( $m[1] );
		}
		return $title;
	}

	/**
	 * Primeira foto de verdade do conteúdo (fora logos, ícones, avatares, anúncios e imagens pequenas).
	 */
	private static function content_image( string $html ): string {
		$area = (string) preg_replace( '#<(header|nav|footer|aside|script|style|noscript)\b[^>]*>.*?</\1>#is', ' ', $html );
		if ( preg_match( '#<article\b[^>]*>(.*)</article>#is', $area, $m ) || preg_match( '#<main\b[^>]*>(.*)</main>#is', $area, $m ) ) {
			$area = $m[1];
		}
		if ( ! preg_match_all( '/<img\s[^>]*>/i', $area, $tags ) ) {
			return '';
		}
		foreach ( array_slice( $tags[0], 0, 40 ) as $tag ) {
			$src = '';
			foreach ( array( 'data-src', 'data-lazy-src', 'data-original', 'src' ) as $attr ) {
				if ( preg_match( '/\s' . $attr . '\s*=\s*["\']([^"\']+)["\']/i', $tag, $a ) && 0 !== strpos( $a[1], 'data:' ) ) {
					$src = html_entity_decode( $a[1], ENT_QUOTES, 'UTF-8' );
					break;
				}
			}
			if ( '' === $src && preg_match( '/\ssrcset\s*=\s*["\']([^"\'\s,]+)/i', $tag, $a ) ) {
				$src = html_entity_decode( $a[1], ENT_QUOTES, 'UTF-8' );
			}
			// Palavras testadas só no endereço e em class/id/alt (nunca na tag inteira: loading="lazy" etc.).
			$meta = '';
			foreach ( array( 'class', 'id', 'alt' ) as $attr ) {
				if ( preg_match( '/\s' . $attr . '\s*=\s*["\']([^"\']*)["\']/i', $tag, $a ) ) {
					$meta .= ' ' . $a[1];
				}
			}
			if ( '' === $src || preg_match( '/(logo|icon|avatar|gravatar|sprite|banner-?ad|publicidade|pixel|emoji|placeholder|\.svg|\.gif)(\b|_|-|\.|$)/i', $src . ' ' . $meta ) ) {
				continue;
			}
			$w = preg_match( '/\swidth\s*=\s*["\']?(\d+)/i', $tag, $a ) ? (int) $a[1] : 0;
			$h = preg_match( '/\sheight\s*=\s*["\']?(\d+)/i', $tag, $a ) ? (int) $a[1] : 0;
			if ( ( $w && $w < 300 ) || ( $h && $h < 160 ) ) {
				continue;
			}
			return $src;
		}
		return '';
	}

	/**
	 * Endereço absoluto (imagens com caminho relativo ou "//").
	 */
	private static function absolute( string $src, string $base ): string {
		$src = trim( $src );
		if ( '' === $src || preg_match( '#^https?://#i', $src ) ) {
			return $src;
		}
		$scheme = (string) wp_parse_url( $base, PHP_URL_SCHEME );
		$host   = (string) wp_parse_url( $base, PHP_URL_HOST );
		if ( '' === $host ) {
			return '';
		}
		$scheme = '' !== $scheme ? $scheme : 'https';
		if ( 0 === strpos( $src, '//' ) ) {
			return $scheme . ':' . $src;
		}
		if ( 0 === strpos( $src, '/' ) ) {
			return $scheme . '://' . $host . $src;
		}
		$path = (string) wp_parse_url( $base, PHP_URL_PATH );
		$dir  = '' !== $path ? substr( $path, 0, (int) strrpos( $path, '/' ) + 1 ) : '/';
		return $scheme . '://' . $host . $dir . $src;
	}

	/**
	 * Confere se a matéria ainda existe no veículo.
	 *
	 * @return array{0:string,1:array<string,mixed>|null} ['ok'|'dead'|'unknown', dados lidos]
	 */
	public static function check( string $url, int $timeout = 15 ): array {
		$res = MLCLIP_Http::get( $url, array( 'timeout' => $timeout ) );
		if ( is_wp_error( $res ) ) {
			$host = MLCLIP_Helpers::host( $url );
			// Domínio que não existe mais = fora do ar; outros erros (tempo, rede) = não deu para saber.
			return array( '' !== $host && gethostbyname( $host . '.' ) === $host . '.' ? 'dead' : 'unknown', null );
		}
		if ( in_array( (int) $res[0], array( 404, 410 ), true ) ) {
			return array( 'dead', null );
		}
		if ( $res[0] >= 400 || '' === $res[1] ) {
			return array( 'unknown', null ); // 403/5xx: bloqueio para robôs ou instabilidade.
		}
		$final = $res[2] ? $res[2] : $url;
		$d     = self::parse( $res[1], $final );
		return array( self::not_found( $d, $url, $final ) ? 'dead' : 'ok', $d );
	}

	/**
	 * Página que abriu (200) mas não é mais a matéria: domínio à venda, "página não encontrada"
	 * com status 200, ou o link caiu na página inicial do site.
	 *
	 * @param array<string, mixed> $d Dados extraídos.
	 */
	public static function not_found( array $d, string $requested, string $final ): bool {
		if ( self::is_parked( $d ) ) {
			return true;
		}
		$path  = trim( (string) wp_parse_url( $requested, PHP_URL_PATH ), '/' );
		$fpath = trim( (string) wp_parse_url( $final, PHP_URL_PATH ), '/' );
		if ( '' !== $path && '' === $fpath ) {
			return true;
		}
		$t = MLCLIP_Helpers::fold( (string) $d['title'] );
		return (bool) preg_match( '/^(erro )?404\b|\b(pagina nao encontrada|pagina inexistente|conteudo nao encontrado|conteudo indisponivel|materia nao encontrada|noticia nao encontrada|page not found|not found|nao encontramos|ops!? ?a pagina|esta pagina nao existe|link quebrado)\b/', $t );
	}

	/**
	 * Domínio estacionado / à venda (o link não leva mais à matéria).
	 *
	 * @param array<string, mixed> $d Dados extraídos.
	 */
	public static function is_parked( array $d ): bool {
		$text = MLCLIP_Helpers::fold( (string) $d['title'] . ' ' . (string) $d['excerpt'] );
		if ( preg_match( '/\b(buy this domain|domain is for sale|domain for sale|this domain may be for sale|dominio a venda|dominio esta a venda|this domain is parked|domain parking|parked domain|parked free|hugedomains|sedo domain parking)\b/', $text ) ) {
			return true;
		}
		// Título igual ao endereço só conta quando a página não tem mais nada (sem resumo, foto nem texto).
		return '' !== (string) $d['host'] && '' === (string) $d['excerpt'] && '' === (string) $d['image'] && strlen( (string) ( $d['body'] ?? '' ) ) < 200
			&& MLCLIP_Helpers::fold( (string) $d['title'] ) === MLCLIP_Helpers::fold( (string) $d['host'] );
	}

	/**
	 * Abre a matéria; se ela saiu do ar (404/410, domínio à venda) ou não abrir, usa a cópia do
	 * Arquivo da Internet (archive.org) para título, resumo, foto e data. Com $need_date, quando a
	 * página não informa a data, usa o primeiro registro no archive.org como data aproximada.
	 *
	 * @return array<string, mixed> Dados + dead (bool), archive_url, date_note.
	 */
	public static function fetch_full( string $url, bool $need_date = false ): array {
		$base = array(
			'url'         => $url,
			'host'        => MLCLIP_Helpers::host( $url ),
			'title'       => '',
			'excerpt'     => '',
			'image'       => '',
			'outlet'      => MLCLIP_Helpers::outlet_from_host( MLCLIP_Helpers::host( $url ) ),
			'date'        => 0,
			'media'       => 'texto',
			'body'        => '',
			'dead'        => false,
			'archive_url' => '',
			'date_note'   => '',
		);
		$res  = MLCLIP_Http::get( $url, array( 'timeout' => 10 ) );
		$live = null;
		if ( ! is_wp_error( $res ) && $res[0] < 400 && '' !== $res[1] ) {
			$final = $res[2] ? $res[2] : $url;
			$path  = trim( (string) wp_parse_url( $url, PHP_URL_PATH ), '/' );
			$fpath = trim( (string) wp_parse_url( $final, PHP_URL_PATH ), '/' );
			$live  = self::parse( $res[1], $final );
			if ( self::not_found( $live, $url, $final ) ) {
				// Domínio à venda, ou a matéria sumiu e o link cai na página inicial do site.
				$base['dead'] = true;
				$live         = null;
			} elseif ( $need_date && (int) $live['date'] > time() - 36 * HOUR_IN_SECONDS ) {
				// Clipping antigo com data "de hoje": é o cabeçalho/portal, não a matéria.
				$live['date'] = 0;
			}
		} elseif ( ! is_wp_error( $res ) && in_array( (int) $res[0], array( 404, 410 ), true ) ) {
			$base['dead'] = true;
		} elseif ( is_wp_error( $res ) && '' !== $base['host'] && gethostbyname( $base['host'] . '.' ) === $base['host'] . '.' ) {
			// Domínio que não existe mais.
			$base['dead'] = true;
		}
		if ( $live ) {
			$out = array_merge( $base, $live );
			if ( ! $need_date || $out['date'] ) {
				return $out;
			}
		} else {
			$out = $base;
		}

		// Cópia mais antiga no archive.org: dados da matéria e data aproximada.
		$snap = self::earliest_snapshot( $url );
		if ( ! $snap ) {
			return $out;
		}
		if ( ! $live || '' === $out['image'] || '' === $out['title'] ) {
			$got = MLCLIP_Http::get( 'https://web.archive.org/web/' . $snap['ts'] . 'id_/' . $url, array( 'timeout' => 12, 'redirection' => 0 ) );
			if ( ! is_wp_error( $got ) && $got[0] < 400 && '' !== $got[1] ) {
				$old = self::parse( $got[1], $url );
				if ( ! self::is_parked( $old ) ) {
					foreach ( array( 'title', 'excerpt', 'image', 'date', 'media', 'body' ) as $k ) {
						if ( 'date' === $k && ! empty( $old['date'] ) && (int) $old['date'] > (int) $snap['time'] - 10 * DAY_IN_SECONDS && (int) $old['date'] !== self::date_from_url( $url ) ) {
							// Data colada no dia em que a cópia foi feita: costuma ser a data do cabeçalho do site, não da matéria.
							continue;
						}
						if ( empty( $out[ $k ] ) && ! empty( $old[ $k ] ) ) {
							$out[ $k ] = $old[ $k ];
							if ( 'image' === $k && ! $live && 0 !== strpos( (string) $old[ $k ], 'https://web.archive.org/' ) ) {
								// Site fora do ar: a foto também só existe na cópia do archive.org.
								$out[ $k ] = 'https://web.archive.org/web/' . $snap['ts'] . 'im_/' . $old[ $k ];
							}
						}
					}
					if ( ! $live ) {
						$out['outlet'] = (string) $old['outlet'];
						$out['host']   = MLCLIP_Helpers::host( $url );
					}
				}
			}
		}
		if ( $out['dead'] ) {
			$out['archive_url'] = 'https://web.archive.org/web/' . $snap['ts'] . '/' . $url;
		}
		// Cópia recente não diz nada sobre a idade da matéria (o próprio plugin pede cópia ao aprovar).
		if ( $need_date && ! $out['date'] && (int) $snap['time'] < time() - 30 * DAY_IN_SECONDS ) {
			$out['date']      = $snap['time'];
			$out['date_note'] = 'archive';
		}
		return $out;
	}

	/**
	 * Título provisório tirado do endereço (/cacique-de-ramos-lanca-exposicao/ → "Cacique de ramos lanca exposicao").
	 * Só para matéria sem título em lugar nenhum; sempre vai para conferência.
	 */
	public static function title_from_url( string $url ): string {
		$path = trim( (string) wp_parse_url( $url, PHP_URL_PATH ), '/' );
		$best = '';
		foreach ( array_reverse( explode( '/', $path ) ) as $seg ) {
			$seg = preg_replace( '/\.(html?|php|aspx?)$/i', '', rawurldecode( $seg ) );
			$seg = preg_replace( '/[-_]\d{4,}$/', '', (string) $seg );
			$words = array_values( array_filter( preg_split( '/[-_+]+/', (string) $seg ) ) );
			if ( count( $words ) >= 3 ) {
				$best = implode( ' ', $words );
				break;
			}
		}
		if ( '' === $best ) {
			return '';
		}
		$best = function_exists( 'mb_strtolower' ) ? mb_strtolower( $best, 'UTF-8' ) : strtolower( $best );
		return ( function_exists( 'mb_strtoupper' ) ? mb_strtoupper( mb_substr( $best, 0, 1 ) ) . mb_substr( $best, 1 ) : ucfirst( $best ) );
	}

	/**
	 * Primeiro registro da página no archive.org.
	 *
	 * @return array{ts:string,time:int}|null
	 */
	public static function earliest_snapshot( string $url ): ?array {
		$res = MLCLIP_Http::get( add_query_arg( array( 'url' => rawurlencode( $url ), 'timestamp' => '19960101' ), 'https://archive.org/wayback/available' ), array( 'timeout' => 8, 'headers' => array( 'Accept' => 'application/json' ) ) );
		if ( is_wp_error( $res ) || 200 !== $res[0] ) {
			return null;
		}
		$data = json_decode( $res[1], true );
		$snap = $data['archived_snapshots']['closest'] ?? null;
		// Só cópia que respondeu 200 (redirecionamento costuma levar à página inicial).
		if ( ! is_array( $snap ) || empty( $snap['available'] ) || '200' !== (string) ( $snap['status'] ?? '' ) || empty( $snap['timestamp'] ) || ! preg_match( '/^\d{14}$/', (string) $snap['timestamp'] ) ) {
			return null;
		}
		$ts   = (string) $snap['timestamp'];
		$time = MLCLIP_Helpers::timestamp( substr( $ts, 0, 4 ) . '-' . substr( $ts, 4, 2 ) . '-' . substr( $ts, 6, 2 ) . ' 12:00:00' );
		return $time ? array( 'ts' => $ts, 'time' => $time ) : null;
	}

	/**
	 * Data no próprio link: /2025/02/13/ ou /2025/02/ (dia 1).
	 */
	public static function date_from_url( string $url ): int {
		$path = (string) wp_parse_url( $url, PHP_URL_PATH );
		if ( preg_match( '#/(19|20)(\d{2})/(0[1-9]|1[0-2])/(0[1-9]|[12]\d|3[01])/#', $path, $m ) ) {
			return MLCLIP_Helpers::timestamp( $m[1] . $m[2] . '-' . $m[3] . '-' . $m[4] . ' 12:00:00' );
		}
		if ( preg_match( '#/(19|20)(\d{2})/(0[1-9]|1[0-2])/#', $path, $m ) ) {
			return MLCLIP_Helpers::timestamp( $m[1] . $m[2] . '-' . $m[3] . '-01 12:00:00' );
		}
		return 0;
	}

	/**
	 * Começo do texto da matéria (sem menus, scripts e rodapé), já "dobrado" para comparação.
	 */
	private static function body_text( string $html ): string {
		$html = preg_replace( '#<(script|style|noscript|svg|nav|header|footer|aside|form|iframe)\b[^>]*>.*?</\1>#is', ' ', $html );
		if ( preg_match( '#<article\b[^>]*>(.*)</article>#is', (string) $html, $m ) ) {
			$html = $m[1];
		} elseif ( preg_match( '#<body\b[^>]*>(.*)</body>#is', (string) $html, $m ) ) {
			$html = $m[1];
		}
		$text = MLCLIP_Helpers::fold( (string) $html );
		return substr( $text, 0, 20000 );
	}

	/**
	 * Título limpo (sem " | Veículo" no fim quando muito longo).
	 */
	private static function clean( string $text ): string {
		$text = trim( preg_replace( '/\s+/u', ' ', html_entity_decode( wp_strip_all_tags( $text ), ENT_QUOTES | ENT_HTML5, 'UTF-8' ) ) );
		return sanitize_text_field( $text );
	}
}
