<?php
/**
 * Licença pelo site tools.mlopesdesign.com.br (ML License Hub, cliente ML_License_Client_V2).
 *
 * Padrão ML (15/10 e 17/10/2026): 1 licença = 1 site; teste grátis de 30 dias iniciado
 * sozinho na primeira visita ao painel; aceita chave do Pacote Agência; sem teste/licença
 * válidos o painel deixa de gravar — o clipping continua no ar, a busca automática pausa e nada é apagado.
 *
 * @package MLClippingPro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class MLCLIP_License {

	private const API_BASE   = 'https://tools.mlopesdesign.com.br/wp-json/mllh/v1';
	private const PUBLIC_KEY = 'VGZQp2X3RJMuDmQBlIEXS4fqsZD1CnFlIJgfVtY/pHo=';
	private const PRODUCT_ID = 'ml-clipping-pro';

	/**
	 * Ações de leitura ou da própria licença que nunca são travadas.
	 */
	private const FREE_ACTIONS = array( 'mlclip_license', 'mlclip_more', 'mlclip_run_status' );

	/**
	 * Cliente.
	 *
	 * @var \ML_License_Client_V2|null
	 */
	private static $client = null;

	/**
	 * Ganchos.
	 */
	public static function hooks(): void {
		// Instancia cedo para agendar a renovação diária do token de licença.
		self::client();
		add_action( 'admin_init', array( __CLASS__, 'enforce' ), 1 );
	}

	/**
	 * Cliente compartilhado.
	 */
	public static function client(): \ML_License_Client_V2 {
		if ( null === self::$client ) {
			self::$client = new \ML_License_Client_V2(
				array(
					'api_base'   => self::API_BASE,
					'product'    => self::PRODUCT_ID,
					'public_key' => self::PUBLIC_KEY,
					'version'    => MLCLIP_VERSION,
				)
			);
		}
		return self::$client;
	}

	/**
	 * Teste ou licença válidos.
	 */
	public static function active(): bool {
		return self::client()->is_premium();
	}

	/**
	 * Primeira visita ao painel: começa o teste de 30 dias sozinho (uma vez por site).
	 */
	public static function maybe_auto_trial(): void {
		$state = self::client()->state();
		if ( ! empty( $state['active'] ) || ! empty( $state['trial_used'] ) || 'none' !== ( $state['mode'] ?? 'none' ) ) {
			return;
		}
		// Sem rede, não tenta de novo a cada clique: espera 1 hora.
		if ( get_transient( 'mlclip_trial_try' ) ) {
			return;
		}
		set_transient( 'mlclip_trial_try', 1, HOUR_IN_SECONDS );
		$res = self::client()->start_trial();
		if ( is_wp_error( $res ) ) {
			update_option( 'mlclip_trial_error', $res->get_error_message(), false );
		} else {
			delete_option( 'mlclip_trial_error' );
		}
	}

	/**
	 * Recusa (403) ações de escrita do painel sem teste/licença válidos.
	 */
	public static function enforce(): void {
		$action = '';
		// phpcs:disable WordPress.Security.NonceVerification -- só lê o nome da ação para decidir o bloqueio.
		if ( wp_doing_ajax() && isset( $_REQUEST['action'] ) ) {
			$action = sanitize_key( wp_unslash( $_REQUEST['action'] ) );
		} elseif ( isset( $GLOBALS['pagenow'] ) && 'admin-post.php' === $GLOBALS['pagenow'] && isset( $_REQUEST['action'] ) ) {
			$action = sanitize_key( wp_unslash( $_REQUEST['action'] ) );
		}
		// phpcs:enable
		if ( '' === $action || 0 !== strpos( $action, 'mlclip_' ) || in_array( $action, self::FREE_ACTIONS, true ) ) {
			return;
		}
		if ( self::active() ) {
			return;
		}
		$message = __( 'Licença necessária: o teste grátis terminou ou a licença não está ativa. O clipping continua no ar no site; ative a licença para buscar, aprovar e editar matérias.', 'ml-clipping-pro' );
		if ( wp_doing_ajax() ) {
			wp_send_json_error( array( 'message' => $message ), 403 );
		}
		// Volta para a tela de onde veio com o aviso em vermelho (sem tela de erro do WordPress).
		if ( current_user_can( 'manage_options' ) && class_exists( 'MLCLIP_Admin' ) ) {
			MLCLIP_Admin::flash( $message, 'error' );
			$back = wp_get_referer();
			wp_safe_redirect( $back ? $back : MLCLIP_Helpers::admin_url( 'license' ) );
			exit;
		}
		wp_die( esc_html( $message ), esc_html__( 'Licença necessária', 'ml-clipping-pro' ), array( 'response' => 403, 'back_link' => true ) );
	}

	/**
	 * Ativa chave, inicia teste, confere ou libera o site.
	 *
	 * @return true|\WP_Error
	 */
	public static function handle( string $op, string $key = '' ) {
		$client = self::client();
		switch ( $op ) {
			case 'activate':
				$key = trim( $key );
				if ( '' === $key || false !== strpos( $key, '•' ) ) {
					return new \WP_Error( 'mlclip_key', __( 'Informe a chave da licença.', 'ml-clipping-pro' ) );
				}
				$res = $client->activate( $key );
				break;
			case 'trial':
				$res = $client->start_trial();
				break;
			case 'refresh':
				$res = $client->refresh();
				break;
			case 'deactivate':
				$res = $client->deactivate();
				break;
			default:
				return new \WP_Error( 'mlclip_op', __( 'Ação desconhecida.', 'ml-clipping-pro' ) );
		}
		return is_wp_error( $res ) ? $res : true;
	}

	/**
	 * Dados para a tela.
	 *
	 * @return array<string, mixed>
	 */
	public static function view(): array {
		$state  = self::client()->state();
		$active = ! empty( $state['active'] );
		$mode   = (string) ( $state['mode'] ?? 'none' );
		$plan   = strtolower( (string) ( $state['plan'] ?? '' ) );
		$labels = array(
			'trial'    => __( 'Teste grátis', 'ml-clipping-pro' ),
			'monthly'  => __( 'Mensal', 'ml-clipping-pro' ),
			'annual'   => __( 'Anual', 'ml-clipping-pro' ),
			'yearly'   => __( 'Anual', 'ml-clipping-pro' ),
			'lifetime' => __( 'Vitalícia', 'ml-clipping-pro' ),
			'courtesy' => __( 'Cortesia', 'ml-clipping-pro' ),
			'manual'   => __( 'Cortesia', 'ml-clipping-pro' ),
			'bundle'   => __( 'Pacote Agência', 'ml-clipping-pro' ),
		);

		if ( $active && 'trial' === $mode ) {
			$tone    = 'trial';
			$label   = __( 'Teste grátis', 'ml-clipping-pro' );
			$days    = isset( $state['days_left'] ) ? (int) $state['days_left'] : null;
			$message = null === $days ? __( 'Teste grátis ativo neste site.', 'ml-clipping-pro' ) : sprintf( /* translators: %d: days. */ _n( 'Teste grátis ativo: falta %d dia.', 'Teste grátis ativo: faltam %d dias.', $days, 'ml-clipping-pro' ), $days );
		} elseif ( $active ) {
			$tone    = 'ok';
			$label   = __( 'Licença ativa', 'ml-clipping-pro' );
			$message = __( 'Licença ativa neste site.', 'ml-clipping-pro' );
		} else {
			$tone  = 'error';
			$label = __( 'Sem licença', 'ml-clipping-pro' );
			if ( 'trial_expired' === ( $state['status'] ?? '' ) ) {
				$message = __( 'O teste grátis terminou. O clipping continua no ar no site; ative uma licença para voltar a buscar, aprovar e editar matérias.', 'ml-clipping-pro' );
			} elseif ( '' !== (string) ( $state['message'] ?? '' ) ) {
				$message = (string) $state['message'];
			} else {
				$message = __( 'Comece o teste grátis de 30 dias ou ative a sua licença.', 'ml-clipping-pro' );
			}
		}

		$expires = '';
		if ( ! empty( $state['expires_at'] ) ) {
			$ts = strtotime( (string) $state['expires_at'] );
			if ( $ts ) {
				$expires = wp_date( get_option( 'date_format', 'd/m/Y' ), $ts );
			}
		}

		return array(
			'active'          => $active,
			'mode'            => $mode,
			'tone'            => $tone,
			'label'           => $label,
			'message'         => $message,
			'plan'            => $labels[ $plan ] ?? ( '' !== $plan ? ucfirst( $plan ) : '—' ),
			'expires'         => $expires,
			'key_masked'      => (string) ( $state['key_masked'] ?? '' ),
			'can_start_trial' => ! $active && empty( $state['trial_used'] ) && 'license' !== $mode,
			'buy_url'         => 'https://tools.mlopesdesign.com.br/produtos/',
			'account_url'     => 'https://tools.mlopesdesign.com.br/minha-conta/',
		);
	}

	/**
	 * Evento de cron do cliente (para desagendar).
	 */
	public static function cron_hook(): string {
		return self::client()->cron_hook();
	}
}
