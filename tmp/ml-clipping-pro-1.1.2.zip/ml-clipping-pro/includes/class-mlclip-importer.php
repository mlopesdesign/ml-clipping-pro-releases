<?php
/**
 * Importa um clipping que já existe no site (ou em qualquer lugar):
 * - de uma página com lista de links (página deste site ou endereço de outro site);
 * - de uma lista de links colada (um por linha, opcional "Título | link");
 * - de posts que usam o plugin Page Links To (meta _links_to).
 *
 * Cada link é aberto para preencher título, resumo, foto, data real e veículo.
 * Roda em lotes de 4 pelo painel, com andamento na tela.
 *
 * @package MLClippingPro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class MLCLIP_Importer {

	private const BATCH = 2;

	/**
	 * Domínios que não são matérias (redes sociais, compartilhamento, contato).
	 *
	 * @var array<int, string>
	 */
	private const SKIP_HOSTS = array( 'facebook.com', 'fb.com', 'twitter.com', 'x.com', 'instagram.com', 'wa.me', 'whatsapp.com', 't.me', 'linkedin.com', 'pinterest.com', 'tiktok.com', 'google.com', 'goo.gl', 'maps.app.goo.gl', 'wordpress.org', 'gravatar.com', 'mlopesdesign.com.br' );

	/**
	 * Chave do lote do usuário.
	 */
	private static function key(): string {
		return 'mlclip_import_' . get_current_user_id();
	}

	/**
	 * Monta a lista de links a importar.
	 *
	 * @param array<string, mixed> $in Entrada do formulário.
	 * @return array<string, mixed>|\WP_Error
	 */
	public static function prepare( array $in ) {
		$mode  = MLCLIP_Helpers::choice( $in['mode'] ?? '', array( 'page', 'url', 'list', 'plt' ), 'list' );
		$items = array();
		switch ( $mode ) {
			case 'page':
				$pid  = absint( $in['page_id'] ?? 0 );
				$post = $pid ? get_post( $pid ) : null;
				if ( ! $post || 'trash' === $post->post_status || ! in_array( $post->post_type, array( 'page', 'post' ), true ) || '' !== (string) $post->post_password || ! current_user_can( 'read_post', $pid ) ) {
					return new \WP_Error( 'mlclip_imp_page', __( 'Escolha a página do site que tem a lista de links.', 'ml-clipping-pro' ) );
				}
				$html  = (string) $post->post_content;
				$html  = function_exists( 'do_blocks' ) ? do_blocks( $html ) : $html;
				// Página montada por shortcode de outro plugin (ex.: [wp_links_page]): usa o HTML final.
				$html  = do_shortcode( $html );
				$items = self::links_from_html( $html, home_url( '/' ) );
				break;
			case 'url':
				$url = esc_url_raw( trim( (string) ( $in['url'] ?? '' ) ) );
				if ( ! MLCLIP_Helpers::is_url( $url ) ) {
					return new \WP_Error( 'mlclip_imp_url', __( 'Informe o endereço completo da página (começando com http).', 'ml-clipping-pro' ) );
				}
				$res = MLCLIP_Http::get( $url );
				if ( is_wp_error( $res ) ) {
					return $res;
				}
				if ( 200 !== $res[0] ) {
					/* translators: %d: HTTP status. */
					return new \WP_Error( 'mlclip_imp_http', sprintf( __( 'A página respondeu com erro %d.', 'ml-clipping-pro' ), $res[0] ) );
				}
				$items = self::links_from_html( $res[1], $url );
				break;
			case 'plt':
				$items = self::links_from_page_links_to();
				break;
			default:
				$items = self::links_from_list( (string) ( $in['list'] ?? '' ) );
		}
		if ( ! $items ) {
			return new \WP_Error( 'mlclip_imp_empty', __( 'Nenhum link de matéria encontrado.', 'ml-clipping-pro' ) );
		}
		$status = MLCLIP_Helpers::choice( $in['status'] ?? 'publish', array( 'publish', 'pending' ), 'publish' );
		$names  = array_values( array_filter( array_map( 'absint', (array) ( $in['names'] ?? array() ) ) ) );
		$job    = array(
			'items'   => array_values( $items ),
			'total'   => count( $items ),
			'done'    => 0,
			'added'   => 0,
			'skipped' => 0,
			'failed'  => 0,
			'nodate'  => 0,
			'status'  => $status,
			'names'   => $names,
		);
		set_transient( self::key(), $job, 2 * HOUR_IN_SECONDS );
		return $job;
	}

	/**
	 * Processa o próximo lote.
	 *
	 * @return array<string, mixed>|\WP_Error
	 */
	public static function step() {
		$job = get_transient( self::key() );
		if ( ! is_array( $job ) ) {
			return new \WP_Error( 'mlclip_imp_none', __( 'Nenhuma importação em andamento.', 'ml-clipping-pro' ) );
		}
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 120 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- alguns servidores bloqueiam.
		}
		$t0 = microtime( true );
		for ( $i = 0; $i < self::BATCH && ! empty( $job['items'] ) && microtime( true ) - $t0 < 6; $i++ ) {
			$it = array_shift( $job['items'] );
			$job['done']++;
			$url = (string) $it['url'];
			if ( MLCLIP_Model::exists( MLCLIP_Helpers::url_key( $url ) ) ) {
				$job['skipped']++;
				continue;
			}
			// Matéria fora do ar (comum em clipping antigo): os dados vêm da cópia do archive.org.
			$page = MLCLIP_Extractor::fetch_full( $url, true );
			if ( MLCLIP_Helpers::url_key( (string) $page['url'] ) !== MLCLIP_Helpers::url_key( $url ) && MLCLIP_Model::exists( MLCLIP_Helpers::url_key( (string) $page['url'] ) ) ) {
				$job['skipped']++;
				continue;
			}
			$title = '' !== (string) $it['title'] ? (string) $it['title'] : (string) $page['title'];
			if ( '' !== (string) $page['title'] && ( '' === (string) $it['title'] || self::looks_generic( (string) $it['title'] ) ) ) {
				$title = (string) $page['title'];
			}
			$title   = MLCLIP_Extractor::strip_outlet( $title, (string) $page['outlet'], (string) $page['host'] );
			$from_url = false;
			if ( '' === $title || MLCLIP_Repair::generic_title( $title, (string) $page['host'] ) ) {
				// Sem título em lugar nenhum: provisório pelo endereço (ou o site), sempre para conferir.
				$guess    = MLCLIP_Extractor::title_from_url( $url );
				$title    = '' !== $guess ? $guess : (string) $page['host'];
				$from_url = true;
			}
			$date    = 'archive' === $page['date_note'] ? 0 : (int) $page['date'];
			$reasons = __( 'Importada', 'ml-clipping-pro' );
			if ( $from_url ) {
				$reasons .= ' · ' . __( 'Título não encontrado; confira', 'ml-clipping-pro' );
			}
			if ( $page['dead'] ) {
				$reasons .= ' · ' . __( 'Fora do ar no veículo', 'ml-clipping-pro' );
				if ( '' === (string) $page['archive_url'] ) {
					$reasons .= ' · ' . __( 'Fora do ar e sem cópia; confira', 'ml-clipping-pro' );
				}
			}
			// Data escrita no texto do link ("RJ2 - 13/02/2024") vale mais que a página.
			$hint = MLCLIP_Extractor::date_in_text( (string) $it['title'] );
			if ( $hint ) {
				$date = $hint;
			} elseif ( $date > time() - 36 * HOUR_IN_SECONDS ) {
				// Clipping antigo com data "de hoje": é a data da página (portal de vídeo), não da matéria.
				$date = 0;
			}
			$status  = ( $from_url || ( $page['dead'] && '' === (string) $page['archive_url'] ) ) ? 'pending' : (string) $job['status'];
			if ( ! $date ) {
				$date = (int) $it['date'] ? (int) $it['date'] : MLCLIP_Extractor::date_from_url( $url );
			}
			if ( ! $date ) {
				// Sem data a matéria iria para o mês atual no site: fica na fila para conferir.
				// O primeiro registro no archive.org é só um limite (a matéria é dessa data ou anterior).
				$first   = 'archive' === $page['date_note'] ? (int) $page['date'] : 0;
				$date    = $first ? $first : time();
				$status  = 'pending';
				$job['nodate']++;
				$reasons .= ' · ' . __( 'Data não encontrada; confira', 'ml-clipping-pro' );
				if ( $first ) {
					/* translators: %s: date. */
					$reasons .= ' · ' . sprintf( __( 'no archive.org desde %s', 'ml-clipping-pro' ), wp_date( 'd/m/Y', $first ) );
				}
			}
			$id = MLCLIP_Model::save(
				array(
					'title'   => $title,
					'url'     => (string) $page['url'],
					'excerpt' => (string) $page['excerpt'],
					'image'   => (string) $page['image'],
					'outlet'  => (string) $page['outlet'],
					'date'    => $date,
					'media'   => (string) $page['media'],
					'origin'  => 'import',
					'score'   => 100,
					'reasons' => $reasons,
					'status'  => $status,
					'names'   => (array) $job['names'],
					'link'    => $page['dead'] ? 'down' : '',
					'archive' => (string) $page['archive_url'],
				)
			);
			if ( is_wp_error( $id ) ) {
				'mlclip_dup' === $id->get_error_code() ? $job['skipped']++ : $job['failed']++;
				continue;
			}
			$job['added']++;
		}
		$done = empty( $job['items'] );
		if ( $done ) {
			delete_transient( self::key() );
		} else {
			set_transient( self::key(), $job, 2 * HOUR_IN_SECONDS );
		}
		unset( $job['items'] );
		$job['finished'] = $done;
		return $job;
	}

	/**
	 * Texto de link genérico ("leia mais", "clique aqui", o próprio endereço).
	 */
	private static function looks_generic( string $text ): bool {
		$f = MLCLIP_Helpers::fold( $text );
		return strlen( $f ) < 12 || (bool) preg_match( '/^(leia|clique|saiba|veja|confira|acesse|link|materia|http|www|array|null|undefined|object)/', $f );
	}

	/**
	 * Links externos de um HTML.
	 *
	 * @return array<int, array{url:string,title:string,date:int}>
	 */
	public static function links_from_html( string $html, string $base ): array {
		$own   = MLCLIP_Helpers::host( $base );
		$site  = MLCLIP_Helpers::host( home_url( '/' ) );
		$items = array();
		// Só o conteúdo da página: cabeçalho, menus, barra lateral e rodapé ficam de fora.
		$html = (string) preg_replace( '#<(header|nav|footer|aside|script|style|form)\b[^>]*>.*?</\1>#is', ' ', $html );
		foreach ( array( '#<main\b[^>]*>(.*)</main>#is', '#<article\b[^>]*>(.*)</article>#is', '#<div[^>]+class=["\'][^"\']*(?:entry-content|post-content|page-content)[^"\']*["\'][^>]*>(.*)#is' ) as $re ) {
			if ( preg_match( $re, $html, $mm ) && false !== stripos( $mm[1], '<a ' ) ) {
				$html = $mm[1];
				break;
			}
		}
		if ( ! preg_match_all( '/<a\s[^>]*href\s*=\s*["\']([^"\']+)["\'][^>]*>(.*?)<\/a>/is', $html, $m, PREG_SET_ORDER ) ) {
			return $items;
		}
		foreach ( $m as $a ) {
			$url  = html_entity_decode( trim( $a[1] ), ENT_QUOTES, 'UTF-8' );
			$host = MLCLIP_Helpers::host( $url );
			if ( '' === $host || ! MLCLIP_Helpers::is_url( $url ) || $host === $own || $host === $site || MLCLIP_Helpers::host_in( $host, self::SKIP_HOSTS ) ) {
				continue;
			}
			if ( preg_match( '/\.(jpe?g|png|gif|webp|svg|pdf|zip|mp3)(\?|$)/i', $url ) || '' === trim( (string) wp_parse_url( $url, PHP_URL_PATH ), '/' ) ) {
				continue;
			}
			// YouTube: só vídeos (canais e playlists não são matérias).
			if ( MLCLIP_Helpers::host_in( $host, array( 'youtube.com' ) ) && ! preg_match( '#/(watch|shorts|live)\b#', (string) wp_parse_url( $url, PHP_URL_PATH ) ) ) {
				continue;
			}
			$key = MLCLIP_Helpers::url_key( $url );
			if ( isset( $items[ $key ] ) ) {
				continue;
			}
			$text          = MLCLIP_Helpers::excerpt( (string) $a[2], 300 );
			$items[ $key ] = array(
				'url'   => $url,
				'title' => self::looks_generic( $text ) ? '' : $text,
				'date'  => 0,
			);
		}
		return array_values( $items );
	}

	/**
	 * Links colados (um por linha; aceita "Título | link" ou "link | Título").
	 *
	 * @return array<int, array{url:string,title:string,date:int}>
	 */
	public static function links_from_list( string $text ): array {
		$items = array();
		foreach ( preg_split( '/\r\n|\r|\n/', $text ) as $line ) {
			$line = trim( $line );
			if ( '' === $line ) {
				continue;
			}
			$title = '';
			$url   = $line;
			if ( false !== strpos( $line, '|' ) ) {
				list( $a, $b ) = array_map( 'trim', explode( '|', $line, 2 ) );
				if ( MLCLIP_Helpers::is_url( $a ) ) {
					$url   = $a;
					$title = $b;
				} else {
					$url   = $b;
					$title = $a;
				}
			} elseif ( preg_match( '#https?://\S+#', $line, $m ) ) {
				$url   = $m[0];
				$title = trim( str_replace( $m[0], '', $line ), " \t-–:" );
			}
			$url = esc_url_raw( $url );
			if ( ! MLCLIP_Helpers::is_url( $url ) ) {
				continue;
			}
			$key = MLCLIP_Helpers::url_key( $url );
			if ( ! isset( $items[ $key ] ) ) {
				$items[ $key ] = array(
					'url'   => $url,
					'title' => sanitize_text_field( $title ),
					'date'  => 0,
				);
			}
		}
		return array_values( $items );
	}

	/**
	 * Posts com o link externo do plugin Page Links To.
	 *
	 * @return array<int, array{url:string,title:string,date:int}>
	 */
	public static function links_from_page_links_to(): array {
		$posts = get_posts(
			array(
				'post_type'      => 'any',
				'post_status'    => 'publish',
				'has_password'   => false,
				'posts_per_page' => 1000,
				'no_found_rows'  => true,
				'meta_key'       => '_links_to', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
			)
		);
		$items = array();
		foreach ( $posts as $p ) {
			$url = trim( (string) get_post_meta( $p->ID, '_links_to', true ) );
			if ( ! MLCLIP_Helpers::is_url( $url ) || MLCLIP_Helpers::host( $url ) === MLCLIP_Helpers::host( home_url( '/' ) ) ) {
				continue;
			}
			$key = MLCLIP_Helpers::url_key( $url );
			if ( ! isset( $items[ $key ] ) ) {
				$items[ $key ] = array(
					'url'   => $url,
					'title' => (string) $p->post_title,
					'date'  => (int) get_post_time( 'U', true, $p ),
				);
			}
		}
		return array_values( $items );
	}

	/**
	 * Quantos posts com Page Links To existem (para mostrar a opção só quando faz sentido).
	 */
	public static function page_links_to_count(): int {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(DISTINCT post_id) FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value LIKE %s", '_links_to', 'http%' ) );
	}
}
