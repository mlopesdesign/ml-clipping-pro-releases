<?php
/**
 * Painel do clipping (identidade visual ML Lopes Design), feito para quem não é técnico.
 *
 * Abas: Painel, Revisão, Matérias, Nomes monitorados, Busca e avisos, Importar, Aparência e Licença.
 * Toda gravação passa por admin-post.php (nonce + permissão); busca, importação e revisão rápida
 * usam AJAX com nonce. CSS/JS só carregam na tela do plugin.
 *
 * @package MLClippingPro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class MLCLIP_Admin {

	public const SLUG  = 'ml-clipping-pro';
	public const CAP   = 'edit_others_posts';
	private const ADMIN = 'manage_options';

	/**
	 * Ganchos.
	 */
	public static function hooks(): void {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_filter( 'submenu_file', array( __CLASS__, 'submenu_file' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_filter( 'plugin_action_links_' . MLCLIP_BASENAME, array( __CLASS__, 'action_links' ) );

		foreach ( array( 'save_name', 'name_action', 'save_item', 'item_action', 'bulk', 'save_search', 'save_appearance', 'test_email', 'create_page', 'forget_seen', 'license' ) as $action ) {
			add_action( 'admin_post_mlclip_' . $action, array( __CLASS__, 'handle_' . $action ) );
		}
		foreach ( array( 'run', 'run_status', 'fetch_link', 'import', 'repair', 'review' ) as $action ) {
			add_action( 'wp_ajax_mlclip_' . $action, array( __CLASS__, 'ajax_' . $action ) );
		}
	}

	/**
	 * Menu com o contador vermelho de matérias aguardando revisão.
	 */
	public static function menu(): void {
		$icon  = 'data:image/svg+xml;base64,' . base64_encode( '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path fill="#a7aaad" d="M3 3h11v12.5c0 .8.7 1.5 1.5 1.5H4.5A1.5 1.5 0 0 1 3 15.5V3zm2 2v3h7V5H5zm0 5v1.4h7V10H5zm0 2.8v1.4h7v-1.4H5zM15 6h2v9.5a1.5 1.5 0 0 1-3 0V6h1z"/></svg>' ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- ícone SVG do menu.
		$count = MLCLIP_Settings::on( 'notify_admin' ) ? MLCLIP_Model::pending_count() : 0;
		$badge = $count > 0 ? ' <span class="awaiting-mod count-' . (int) $count . '"><span class="pending-count">' . (int) $count . '</span></span>' : '';
		add_menu_page( __( 'ML Clipping Pro', 'ml-clipping-pro' ), __( 'Clipping', 'ml-clipping-pro' ) . $badge, self::CAP, self::SLUG, array( __CLASS__, 'page' ), $icon, 26 );
		foreach ( self::tabs() as $tab => $label ) {
			$cap = in_array( $tab, array( 'search', 'appearance', 'license' ), true ) ? self::ADMIN : self::CAP;
			if ( 'review' === $tab && $count > 0 ) {
				$label .= $badge;
			}
			add_submenu_page( self::SLUG, wp_strip_all_tags( $label ), $label, $cap, 'dashboard' === $tab ? self::SLUG : self::sub( $tab ), 'dashboard' === $tab ? array( __CLASS__, 'page' ) : '' );
		}
	}

	/**
	 * Abas.
	 *
	 * @return array<string, string>
	 */
	private static function tabs(): array {
		return array(
			'dashboard'  => __( 'Painel', 'ml-clipping-pro' ),
			'review'     => __( 'Revisão', 'ml-clipping-pro' ),
			'items'      => __( 'Matérias', 'ml-clipping-pro' ),
			'names'      => __( 'Nomes monitorados', 'ml-clipping-pro' ),
			'search'     => __( 'Busca e avisos', 'ml-clipping-pro' ),
			'import'     => __( 'Importar', 'ml-clipping-pro' ),
			'appearance' => __( 'Aparência', 'ml-clipping-pro' ),
			'license'    => __( 'Licença', 'ml-clipping-pro' ),
		);
	}

	/**
	 * Marca no menu lateral o submenu da aba aberta.
	 *
	 * @param string|null $submenu_file Submenu atual.
	 * @return string|null
	 */
	public static function submenu_file( $submenu_file ) {
		global $plugin_page;
		if ( self::SLUG !== $plugin_page ) {
			return $submenu_file;
		}
		$tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return ( '' === $tab || 'dashboard' === $tab ) ? self::SLUG : self::sub( $tab );
	}

	/**
	 * Slug do submenu de uma aba. Precisa ser "admin.php?page=..." — só "slug&tab=" vira
	 * wp-admin/slug&tab=... (404) em instalações onde o WP não acha o hook da página.
	 *
	 * @param string $tab Aba.
	 * @return string
	 */
	private static function sub( string $tab ): string {
		return 'admin.php?page=' . self::SLUG . '&tab=' . $tab;
	}

	/**
	 * Link na lista de plugins.
	 *
	 * @param array<int|string, string> $links Links.
	 * @return array<int|string, string>
	 */
	public static function action_links( $links ) {
		array_unshift( $links, '<a href="' . esc_url( MLCLIP_Helpers::admin_url( 'dashboard' ) ) . '">' . esc_html__( 'Clipping', 'ml-clipping-pro' ) . '</a>' );
		return $links;
	}

	/**
	 * CSS/JS do painel (só na tela do plugin).
	 *
	 * @param string $hook Tela.
	 */
	public static function assets( $hook ): void {
		if ( 'toplevel_page_' . self::SLUG !== (string) $hook ) {
			return;
		}
		wp_enqueue_style( 'mlclip-admin', MLCLIP_URL . 'assets/css/admin.css', array(), MLCLIP_VERSION );
		wp_enqueue_script( 'mlclip-admin', MLCLIP_URL . 'assets/js/admin.js', array(), MLCLIP_VERSION, true );
		wp_localize_script(
			'mlclip-admin',
			'MLCLIP_ADMIN',
			array(
				'ajax'   => admin_url( 'admin-ajax.php' ),
				'nonce'  => wp_create_nonce( 'mlclip_ajax' ),
				'review' => MLCLIP_Helpers::admin_url( 'review' ),
				'i18n'   => array(
					'copied'     => __( 'Shortcode copiado.', 'ml-clipping-pro' ),
					'copyFail'   => __( 'Não foi possível copiar. Selecione e copie manualmente.', 'ml-clipping-pro' ),
					'error'      => __( 'Não foi possível concluir. Tente de novo.', 'ml-clipping-pro' ),
					'starting'   => __( 'Começando a busca…', 'ml-clipping-pro' ),
					'busy'       => __( 'Aguardando a etapa anterior terminar…', 'ml-clipping-pro' ),
					'goReview'   => __( 'Revisar agora', 'ml-clipping-pro' ),
					'fetching'   => __( 'Lendo a página da matéria…', 'ml-clipping-pro' ),
					'filled'     => __( 'Campos preenchidos pela página da matéria. Confira e salve.', 'ml-clipping-pro' ),
					'needUrl'    => __( 'Cole o link da matéria primeiro.', 'ml-clipping-pro' ),
					'importing'  => __( 'Importando…', 'ml-clipping-pro' ),
					'reading'    => __( 'Procurando matérias para reler…', 'ml-clipping-pro' ),
					'repFixed'   => __( 'completadas', 'ml-clipping-pro' ),
					'repDown'    => __( 'fora do ar', 'ml-clipping-pro' ),
					'repNodate'  => __( 'ainda sem data', 'ml-clipping-pro' ),
					'repNone'    => __( 'Nenhuma matéria precisa ser relida.', 'ml-clipping-pro' ),
					'approved'   => __( 'Aprovada: já aparece no site.', 'ml-clipping-pro' ),
					'discarded'  => __( 'Descartada (dá para recuperar em Matérias > Descartadas).', 'ml-clipping-pro' ),
					'pickSome'   => __( 'Marque pelo menos uma matéria.', 'ml-clipping-pro' ),
					'unsaved'    => __( 'Há alterações não salvas.', 'ml-clipping-pro' ),
					'badDate'    => __( 'Data incompleta. Use DD/MM/AAAA.', 'ml-clipping-pro' ),
					'queueEmpty' => __( 'Fila vazia. Nenhuma matéria aguardando revisão.', 'ml-clipping-pro' ),
				),
			)
		);
	}

	/* ====================================================================
	 * Mensagens (toast) entre o POST e a tela
	 * ================================================================== */

	/**
	 * Guarda uma mensagem para a próxima tela.
	 */
	public static function flash( string $message, string $type = 'success' ): void {
		set_transient( 'mlclip_toast_' . get_current_user_id(), array( 'm' => $message, 't' => $type ), MINUTE_IN_SECONDS );
	}

	/**
	 * Lê e apaga a mensagem.
	 *
	 * @return array{m:string,t:string}
	 */
	private static function take_flash(): array {
		$key  = 'mlclip_toast_' . get_current_user_id();
		$data = get_transient( $key );
		delete_transient( $key );
		return is_array( $data ) ? array( 'm' => (string) $data['m'], 't' => (string) $data['t'] ) : array( 'm' => '', 't' => 'success' );
	}

	/**
	 * Confere permissão e nonce de um POST.
	 */
	private static function guard( string $nonce_action, string $cap = self::CAP ): void {
		if ( ! current_user_can( $cap ) ) {
			wp_die( esc_html__( 'Você não tem permissão para isso.', 'ml-clipping-pro' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( $nonce_action );
	}

	/**
	 * Confere permissão e nonce de um AJAX.
	 */
	private static function ajax_guard( string $cap = self::CAP ): void {
		if ( ! check_ajax_referer( 'mlclip_ajax', 'nonce', false ) ) {
			wp_send_json_error( array( 'message' => __( 'Sessão expirada. Recarregue a página.', 'ml-clipping-pro' ) ), 403 );
		}
		if ( ! current_user_can( $cap ) ) {
			wp_send_json_error( array( 'message' => __( 'Você não tem permissão para isso.', 'ml-clipping-pro' ) ), 403 );
		}
	}

	/**
	 * Volta para uma aba.
	 *
	 * @param array<string, mixed> $args Argumentos extras.
	 */
	private static function back( string $tab, array $args = array() ): void {
		wp_safe_redirect( MLCLIP_Helpers::admin_url( $tab, $args ) );
		exit;
	}

	/**
	 * Campos enviados em mlclip[...].
	 *
	 * @return array<string, mixed>
	 */
	private static function input(): array {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- nonce conferido em guard(); cada campo é limpo ao gravar.
		$in = isset( $_POST['mlclip'] ) && is_array( $_POST['mlclip'] ) ? wp_unslash( $_POST['mlclip'] ) : array();
		return is_array( $in ) ? $in : array();
	}

	/**
	 * Data DD/MM/AAAA (ou AAAA-MM-DD) + hora opcional → timestamp no fuso do site.
	 */
	private static function parse_date( string $value ): int {
		$value = trim( $value );
		if ( preg_match( '#^(\d{2})/(\d{2})/(\d{4})$#', $value, $m ) ) {
			$value = $m[3] . '-' . $m[2] . '-' . $m[1];
		}
		if ( ! preg_match( '/^(\d{4})-(\d{2})-(\d{2})$/', $value, $m ) || ! checkdate( (int) $m[2], (int) $m[3], (int) $m[1] ) ) {
			return 0;
		}
		try {
			$d = new \DateTimeImmutable( $value . ' 12:00:00', wp_timezone() );
		} catch ( \Exception $e ) {
			return 0;
		}
		return $d->getTimestamp();
	}

	/* ====================================================================
	 * Gravações (admin-post)
	 * ================================================================== */

	/**
	 * Salva um nome monitorado.
	 */
	public static function handle_save_name(): void {
		self::guard( 'mlclip_save_name' );
		$id  = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- conferido em guard().
		$res = MLCLIP_Names::save( self::input(), $id );
		if ( is_wp_error( $res ) ) {
			self::flash( $res->get_error_message(), 'error' );
			self::back( 'names', array( 'edit' => $id ? $id : 'new' ) );
		}
		self::flash( $id ? __( 'Nome atualizado.', 'ml-clipping-pro' ) : __( 'Nome adicionado. Clique em "Buscar agora" no Painel para a primeira busca.', 'ml-clipping-pro' ) );
		self::back( 'names' );
	}

	/**
	 * Liga/pausa ou remove um nome.
	 */
	public static function handle_name_action(): void {
		self::guard( 'mlclip_name_action' );
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- conferido em guard().
		$id = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
		$op = isset( $_POST['op'] ) ? sanitize_key( wp_unslash( $_POST['op'] ) ) : '';
		// phpcs:enable
		if ( 'toggle' === $op && MLCLIP_Names::toggle( $id ) ) {
			self::flash( __( 'Nome atualizado.', 'ml-clipping-pro' ) );
		} elseif ( 'delete' === $op && MLCLIP_Names::delete( $id ) ) {
			self::flash( __( 'Nome removido da lista. As matérias dele continuam no clipping.', 'ml-clipping-pro' ) );
		} else {
			self::flash( __( 'Não foi possível concluir.', 'ml-clipping-pro' ), 'error' );
		}
		self::back( 'names' );
	}

	/**
	 * Salva uma matéria (nova ou editada).
	 */
	public static function handle_save_item(): void {
		self::guard( 'mlclip_save_item' );
		$id  = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- conferido em guard().
		$in  = self::input();
		$old = $id ? MLCLIP_Model::get( $id ) : null;
		if ( $id && ! $old ) {
			self::flash( __( 'Matéria não encontrada.', 'ml-clipping-pro' ), 'error' );
			self::back( 'items' );
		}
		$date = self::parse_date( (string) ( $in['date'] ?? '' ) );
		if ( ! $date ) {
			self::flash( __( 'Informe a data da matéria (DD/MM/AAAA).', 'ml-clipping-pro' ), 'error' );
			self::back( 'items', array( 'edit' => $id ? $id : 'new' ) );
		}
		// Mantém a hora original quando o dia não mudou.
		if ( $old && wp_date( 'Y-m-d', (int) $old['date'] ) === wp_date( 'Y-m-d', $date ) ) {
			$date = (int) $old['date'];
		}
		$data = array(
			'title'    => (string) ( $in['title'] ?? '' ),
			'url'      => (string) ( $in['url'] ?? '' ),
			'excerpt'  => (string) ( $in['excerpt'] ?? '' ),
			'outlet'   => (string) ( $in['outlet'] ?? '' ),
			'image'    => (string) ( $in['image'] ?? '' ),
			'date'     => $date,
			'media'    => (string) ( $in['media'] ?? 'texto' ),
			'featured' => ! empty( $in['featured'] ),
			'status'   => (string) ( $in['status'] ?? 'publish' ),
			'names'    => array_map( 'absint', (array) ( $in['names'] ?? array() ) ),
		);
		if ( $old && false !== strpos( (string) $old['reasons'], '; confira' ) ) {
			// Data e título foram conferidos na ficha: tira os avisos.
			$clean           = trim( (string) preg_replace( '/\s*·\s*[^·]*; confira(\s*·\s*no archive\.org desde [0-9\/]+)?/u', '', (string) $old['reasons'] ) );
			$data['reasons'] = false !== strpos( $clean, __( 'conferida', 'ml-clipping-pro' ) ) ? $clean : $clean . ' · ' . __( 'conferida', 'ml-clipping-pro' );
		}
		if ( ! $id ) {
			$data['origin']  = 'manual';
			$data['score']   = 100;
			$data['reasons'] = __( 'Adicionada à mão', 'ml-clipping-pro' );
		}
		$res = MLCLIP_Model::save( $data, $id );
		if ( is_wp_error( $res ) ) {
			self::flash( $res->get_error_message(), 'error' );
			$dup = $res->get_error_data();
			self::back( 'items', array( 'edit' => is_array( $dup ) && ! empty( $dup['id'] ) ? (int) $dup['id'] : ( $id ? $id : 'new' ) ) );
		}
		self::flash( $id ? __( 'Matéria salva.', 'ml-clipping-pro' ) : __( 'Matéria adicionada ao clipping.', 'ml-clipping-pro' ) );
		self::back( 'items', array( 'edit' => (int) $res ) );
	}

	/**
	 * Ação em uma matéria (aprovar, descartar, voltar para a fila, destaque, excluir).
	 */
	public static function handle_item_action(): void {
		self::guard( 'mlclip_item_action' );
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- conferido em guard().
		$id   = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
		$op   = isset( $_POST['op'] ) ? sanitize_key( wp_unslash( $_POST['op'] ) ) : '';
		$back = isset( $_POST['back'] ) ? sanitize_key( wp_unslash( $_POST['back'] ) ) : 'items';
		$view = isset( $_POST['view'] ) ? sanitize_key( wp_unslash( $_POST['view'] ) ) : '';
		// phpcs:enable
		$msg = self::apply( $id, $op );
		if ( is_wp_error( $msg ) ) {
			self::flash( $msg->get_error_message(), 'error' );
		} else {
			self::flash( $msg );
		}
		self::back( in_array( $back, array( 'items', 'review' ), true ) ? $back : 'items', '' !== $view ? array( 'view' => $view ) : array() );
	}

	/**
	 * Aplica uma ação a uma matéria.
	 *
	 * @return string|\WP_Error Mensagem.
	 */
	private static function apply( int $id, string $op ) {
		if ( MLCLIP_Model::TYPE !== get_post_type( $id ) ) {
			return new \WP_Error( 'mlclip_item', __( 'Matéria não encontrada.', 'ml-clipping-pro' ) );
		}
		if ( 'approve' === $op && ! current_user_can( 'publish_posts' ) ) {
			return new \WP_Error( 'mlclip_cap', __( 'Você não tem permissão para publicar.', 'ml-clipping-pro' ) );
		}
		if ( 'delete' === $op && ! current_user_can( 'delete_post', $id ) ) {
			return new \WP_Error( 'mlclip_cap', __( 'Você não tem permissão para excluir.', 'ml-clipping-pro' ) );
		}
		switch ( $op ) {
			case 'approve':
				MLCLIP_Model::set_status( $id, 'publish' );
				return __( 'Aprovada: já aparece no site.', 'ml-clipping-pro' );
			case 'discard':
				MLCLIP_Model::set_status( $id, MLCLIP_Model::DISCARD );
				return __( 'Descartada (dá para recuperar em Matérias > Descartadas).', 'ml-clipping-pro' );
			case 'pending':
				MLCLIP_Model::set_status( $id, 'pending' );
				return __( 'A matéria voltou para a fila de revisão.', 'ml-clipping-pro' );
			case 'feature':
				$on = '1' !== (string) get_post_meta( $id, '_mlclip_featured', true );
				update_post_meta( $id, '_mlclip_featured', $on ? '1' : '0' );
				MLCLIP_Render::bump_cache();
				return $on ? __( 'Marcada como manchete do mês.', 'ml-clipping-pro' ) : __( 'Destaque removido.', 'ml-clipping-pro' );
			case 'recheck':
				$st = MLCLIP_Links::check_one( $id );
				return 'down' === $st ? __( 'O link continua fora do ar.', 'ml-clipping-pro' ) : __( 'Link conferido.', 'ml-clipping-pro' );
			case 'delete':
				// Exclusão definitiva a pedido (com confirmação); a busca não traz de volta.
				MLCLIP_Model::forget( $id );
				MLCLIP_Render::bump_cache();
				return __( 'Matéria excluída definitivamente.', 'ml-clipping-pro' );
		}
		return new \WP_Error( 'mlclip_op', __( 'Ação desconhecida.', 'ml-clipping-pro' ) );
	}

	/**
	 * Ações em lote da revisão.
	 */
	public static function handle_bulk(): void {
		self::guard( 'mlclip_bulk' );
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- conferido em guard().
		$op  = isset( $_POST['op'] ) ? sanitize_key( wp_unslash( $_POST['op'] ) ) : '';
		$ids = isset( $_POST['ids'] ) ? array_map( 'absint', (array) wp_unslash( $_POST['ids'] ) ) : array();
		$tab = isset( $_POST['back'] ) && 'items' === $_POST['back'] ? 'items' : 'review';
		// phpcs:enable
		if ( 'approve_high' === $op ) {
			$ids = get_posts(
				array(
					'post_type'      => MLCLIP_Model::TYPE,
					'post_status'    => 'pending',
					'posts_per_page' => 500,
					'fields'         => 'ids',
					'no_found_rows'  => true,
					'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
						'relation' => 'AND',
						array(
							'key'     => '_mlclip_score',
							'value'   => 60,
							'compare' => '>=',
							'type'    => 'NUMERIC',
						),
						// Data ou título não confirmados ("...; confira") não entram em massa: conferência uma a uma.
						array(
							'relation' => 'OR',
							array(
								'key'     => '_mlclip_reasons',
								'compare' => 'NOT EXISTS',
							),
							array(
								'key'     => '_mlclip_reasons',
								'value'   => '; confira',
								'compare' => 'NOT LIKE',
							),
						),
					),
				)
			);
			$op  = 'approve';
		}
		$ids = array_filter( array_map( 'intval', $ids ) );
		if ( ! $ids || ! in_array( $op, array( 'approve', 'discard', 'pending', 'delete' ), true ) ) {
			self::flash( 'approve' === $op ? __( 'Nenhuma matéria de nota Alta na fila.', 'ml-clipping-pro' ) : __( 'Marque pelo menos uma matéria.', 'ml-clipping-pro' ), 'warning' );
			self::back( $tab );
		}
		$n = 0;
		foreach ( $ids as $id ) {
			if ( ! is_wp_error( self::apply( (int) $id, $op ) ) ) {
				$n++;
			}
		}
		$labels = array(
			/* translators: %d: count. */
			'approve' => _n( '%d matéria aprovada.', '%d matérias aprovadas.', $n, 'ml-clipping-pro' ),
			/* translators: %d: count. */
			'discard' => _n( '%d matéria descartada.', '%d matérias descartadas.', $n, 'ml-clipping-pro' ),
			/* translators: %d: count. */
			'pending' => _n( '%d matéria voltou para a fila.', '%d matérias voltaram para a fila.', $n, 'ml-clipping-pro' ),
			/* translators: %d: count. */
			'delete'  => _n( '%d matéria excluída.', '%d matérias excluídas.', $n, 'ml-clipping-pro' ),
		);
		self::flash( sprintf( $labels[ $op ], $n ) );
		self::back( $tab );
	}

	/**
	 * Busca e avisos.
	 */
	public static function handle_save_search(): void {
		self::guard( 'mlclip_save_search', self::ADMIN );
		MLCLIP_Settings::save_search( self::input() );
		self::flash( __( 'Configurações salvas.', 'ml-clipping-pro' ) );
		self::back( 'search' );
	}

	/**
	 * Aparência.
	 */
	public static function handle_save_appearance(): void {
		self::guard( 'mlclip_save_appearance', self::ADMIN );
		MLCLIP_Settings::save_appearance( self::input() );
		MLCLIP_Render::bump_cache();
		self::flash( __( 'Aparência salva.', 'ml-clipping-pro' ) );
		self::back( 'appearance' );
	}

	/**
	 * E-mail de teste.
	 */
	public static function handle_test_email(): void {
		self::guard( 'mlclip_test_email', self::ADMIN );
		$res = MLCLIP_Notify::send_digest( (int) get_option( 'mlclip_last_email', 0 ), true );
		if ( is_wp_error( $res ) ) {
			self::flash( $res->get_error_message(), 'error' );
		} else {
			/* translators: %s: emails. */
			self::flash( sprintf( __( 'E-mail de teste enviado para %s.', 'ml-clipping-pro' ), implode( ', ', (array) MLCLIP_Settings::get( 'notify_to' ) ) ) );
		}
		self::back( 'search' );
	}

	/**
	 * Cria a página "Clipping" com o shortcode.
	 */
	public static function handle_create_page(): void {
		self::guard( 'mlclip_create_page', self::ADMIN );
		$existing = (int) get_option( 'mlclip_page_id', 0 );
		if ( $existing && 'publish' === get_post_status( $existing ) ) {
			self::flash( __( 'A página do clipping já existe.', 'ml-clipping-pro' ), 'warning' );
			self::back( 'dashboard' );
		}
		$id = wp_insert_post(
			array(
				'post_type'    => 'page',
				'post_status'  => 'publish',
				'post_title'   => __( 'Clipping', 'ml-clipping-pro' ),
				'post_name'    => 'clipping-imprensa',
				'post_content' => '<!-- wp:shortcode -->[ml_clipping]<!-- /wp:shortcode -->',
			),
			true
		);
		if ( is_wp_error( $id ) ) {
			self::flash( $id->get_error_message(), 'error' );
		} else {
			update_option( 'mlclip_page_id', (int) $id, false );
			self::flash( __( 'Página "Clipping" criada e publicada. Adicione-a ao menu do site em Aparência > Menus.', 'ml-clipping-pro' ) );
		}
		self::back( 'dashboard' );
	}

	/**
	 * Esquece as matérias já vistas (próxima busca reavalia tudo da janela).
	 */
	public static function handle_forget_seen(): void {
		self::guard( 'mlclip_forget_seen', self::ADMIN );
		MLCLIP_Engine::forget_seen();
		self::flash( __( 'Pronto. A próxima busca reavalia todas as matérias da janela (as que já estão no clipping não se repetem).', 'ml-clipping-pro' ) );
		self::back( 'search' );
	}

	/**
	 * Licença.
	 */
	public static function handle_license(): void {
		self::guard( 'mlclip_license', self::ADMIN );
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- conferido em guard().
		$op  = isset( $_POST['op'] ) ? sanitize_key( wp_unslash( $_POST['op'] ) ) : '';
		$key = isset( $_POST['license_key'] ) ? sanitize_text_field( wp_unslash( $_POST['license_key'] ) ) : '';
		// phpcs:enable
		$res = MLCLIP_License::handle( $op, $key );
		if ( is_wp_error( $res ) ) {
			self::flash( $res->get_error_message(), 'error' );
		} else {
			$messages = array(
				'activate'   => __( 'Licença ativada neste site.', 'ml-clipping-pro' ),
				'trial'      => __( 'Teste grátis ativo.', 'ml-clipping-pro' ),
				'refresh'    => __( 'Licença conferida.', 'ml-clipping-pro' ),
				'deactivate' => __( 'Site liberado. A chave pode ser usada em outro site.', 'ml-clipping-pro' ),
			);
			self::flash( $messages[ $op ] ?? __( 'Feito.', 'ml-clipping-pro' ) );
		}
		self::back( 'license' );
	}

	/* ====================================================================
	 * AJAX
	 * ================================================================== */

	/**
	 * Buscar agora: start + passos.
	 */
	public static function ajax_run(): void {
		self::ajax_guard();
		$op = isset( $_POST['op'] ) ? sanitize_key( wp_unslash( $_POST['op'] ) ) : 'step'; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- conferido em ajax_guard().
		if ( 'start' === $op ) {
			$name = isset( $_POST['name'] ) ? absint( $_POST['name'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- conferido em ajax_guard().
			$res  = MLCLIP_Engine::start( 'manual', $name );
			if ( is_wp_error( $res ) ) {
				wp_send_json_error( array( 'message' => $res->get_error_message() ) );
			}
		}
		$step = MLCLIP_Engine::step();
		if ( ! empty( $step['done'] ) ) {
			$step['pending'] = MLCLIP_Model::pending_count();
		}
		wp_send_json_success( $step );
	}

	/**
	 * Situação da busca (para retomar a barra de andamento).
	 */
	public static function ajax_run_status(): void {
		self::ajax_guard();
		$job = MLCLIP_Engine::job();
		wp_send_json_success( array( 'running' => (bool) $job ) );
	}

	/**
	 * "Preencher pelo link" na matéria manual.
	 */
	public static function ajax_fetch_link(): void {
		self::ajax_guard();
		$url = isset( $_POST['url'] ) ? esc_url_raw( trim( wp_unslash( (string) $_POST['url'] ) ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- conferido em ajax_guard().
		if ( ! MLCLIP_Helpers::is_url( $url ) ) {
			wp_send_json_error( array( 'message' => __( 'Link inválido. Cole o endereço completo (começando com http).', 'ml-clipping-pro' ) ) );
		}
		$dup = MLCLIP_Model::exists( MLCLIP_Helpers::url_key( $url ) );
		$res = MLCLIP_Extractor::fetch( $url );
		if ( is_wp_error( $res ) ) {
			wp_send_json_error( array( 'message' => $res->get_error_message() . ' ' . __( 'Preencha os campos à mão.', 'ml-clipping-pro' ) ) );
		}
		unset( $res['body'] );
		$res['date_br'] = $res['date'] ? wp_date( 'd/m/Y', (int) $res['date'] ) : '';
		$res['dup']     = $dup ? MLCLIP_Helpers::admin_url( 'items', array( 'edit' => $dup ) ) : '';
		wp_send_json_success( $res );
	}

	/**
	 * Importação: prepare + passos.
	 */
	public static function ajax_import(): void {
		self::ajax_guard();
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- conferido em ajax_guard().
		$op = isset( $_POST['op'] ) ? sanitize_key( wp_unslash( $_POST['op'] ) ) : 'step';
		if ( 'prepare' === $op ) {
			$in = array(
				'mode'    => isset( $_POST['mode'] ) ? sanitize_key( wp_unslash( $_POST['mode'] ) ) : '',
				'page_id' => isset( $_POST['page_id'] ) ? absint( $_POST['page_id'] ) : 0,
				'url'     => isset( $_POST['url'] ) ? esc_url_raw( wp_unslash( (string) $_POST['url'] ) ) : '',
				'list'    => isset( $_POST['list'] ) ? sanitize_textarea_field( wp_unslash( (string) $_POST['list'] ) ) : '',
				'status'  => isset( $_POST['status'] ) ? sanitize_key( wp_unslash( $_POST['status'] ) ) : 'publish',
				'names'   => isset( $_POST['names'] ) ? array_map( 'absint', (array) wp_unslash( $_POST['names'] ) ) : array(),
			);
			// phpcs:enable
			$res = MLCLIP_Importer::prepare( $in );
			if ( is_wp_error( $res ) ) {
				wp_send_json_error( array( 'message' => $res->get_error_message() ) );
			}
			wp_send_json_success(
				array(
					'total'    => (int) $res['total'],
					'done'     => 0,
					'finished' => false,
				)
			);
		}
		$res = MLCLIP_Importer::step();
		if ( is_wp_error( $res ) ) {
			wp_send_json_error( array( 'message' => $res->get_error_message() ) );
		}
		wp_send_json_success( $res );
	}

	/**
	 * Reler matérias: prepare + passos.
	 */
	public static function ajax_repair(): void {
		self::ajax_guard( 'edit_others_posts' );
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- conferido em ajax_guard().
		$op = isset( $_POST['op'] ) ? sanitize_key( wp_unslash( $_POST['op'] ) ) : 'step';
		if ( 'prepare' === $op ) {
			$res = MLCLIP_Repair::prepare( ! empty( $_POST['unpublish'] ) );
			// phpcs:enable
			wp_send_json_success(
				array(
					'total'    => (int) $res['total'],
					'done'     => 0,
					'fixed'    => 0,
					'down'     => 0,
					'nodate'   => 0,
					'finished' => 0 === (int) $res['total'],
				)
			);
		}
		$res = MLCLIP_Repair::step();
		if ( is_wp_error( $res ) ) {
			wp_send_json_error( array( 'message' => $res->get_error_message() ) );
		}
		wp_send_json_success( $res );
	}

	/**
	 * Revisão rápida (aprovar/descartar/destacar sem recarregar).
	 */
	public static function ajax_review(): void {
		self::ajax_guard();
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- conferido em ajax_guard().
		$id = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
		$op = isset( $_POST['op'] ) ? sanitize_key( wp_unslash( $_POST['op'] ) ) : '';
		// phpcs:enable
		if ( ! in_array( $op, array( 'approve', 'discard', 'feature', 'pending', 'delete' ), true ) ) {
			wp_send_json_error( array( 'message' => __( 'Ação desconhecida.', 'ml-clipping-pro' ) ) );
		}
		$msg = self::apply( $id, $op );
		if ( is_wp_error( $msg ) ) {
			wp_send_json_error( array( 'message' => $msg->get_error_message() ) );
		}
		wp_send_json_success(
			array(
				'message' => $msg,
				'pending' => MLCLIP_Model::pending_count(),
			)
		);
	}

	/* ====================================================================
	 * Tela
	 * ================================================================== */

	/**
	 * Página do plugin.
	 */
	public static function page(): void {
		if ( ! current_user_can( self::CAP ) ) {
			return;
		}
		if ( current_user_can( self::ADMIN ) ) {
			MLCLIP_License::maybe_auto_trial();
		}
		$tabs = self::tabs();
		if ( ! current_user_can( self::ADMIN ) ) {
			unset( $tabs['search'], $tabs['appearance'], $tabs['license'] );
		}
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- navegação.
		$tab  = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'dashboard';
		$tab  = isset( $tabs[ $tab ] ) ? $tab : 'dashboard';
		$edit = isset( $_GET['edit'] ) ? sanitize_key( wp_unslash( $_GET['edit'] ) ) : '';
		// phpcs:enable
		$toast   = self::take_flash();
		$lic     = MLCLIP_License::view();
		$pending = MLCLIP_Model::pending_count();
		?>
		<div class="wrap mlclip-admin" data-toast-message="<?php echo esc_attr( $toast['m'] ); ?>" data-toast-type="<?php echo esc_attr( $toast['t'] ); ?>">
			<h1 class="screen-reader-text"><?php esc_html_e( 'ML Clipping Pro', 'ml-clipping-pro' ); ?></h1>
			<div id="mlclip-toast-area" aria-live="polite" aria-atomic="true"></div>

			<section class="mlclip-hero">
				<div class="mlclip-hero-brand">
					<div class="mlclip-hero-mark"><img src="<?php echo esc_url( MLCLIP_Helpers::logo_url() ); ?>" alt="ML Lopes Design" width="72" height="72"></div>
					<div class="mlclip-hero-copy">
						<span class="mlclip-eyebrow"><?php esc_html_e( 'ML Lopes Design · Plugins', 'ml-clipping-pro' ); ?></span>
						<h2 class="mlclip-title"><?php esc_html_e( 'ML Clipping Pro', 'ml-clipping-pro' ); ?></h2>
						<p class="mlclip-intro"><?php esc_html_e( 'Todo dia o plugin procura as matérias que citam os nomes da sua lista. Você aprova, e elas aparecem no site em layout de jornal.', 'ml-clipping-pro' ); ?></p>
					</div>
				</div>
				<div class="mlclip-hero-meta">
					<span class="mlclip-version">v<?php echo esc_html( MLCLIP_VERSION ); ?></span>
					<span class="mlclip-chip mlclip-chip-<?php echo esc_attr( $lic['tone'] ); ?>"><?php echo esc_html( $lic['label'] ); ?></span>
				</div>
			</section>

			<?php if ( ! $lic['active'] ) : ?>
				<div class="mlclip-lockbar" role="status">
					<strong><?php esc_html_e( 'Licença necessária.', 'ml-clipping-pro' ); ?></strong>
					<span><?php echo esc_html( $lic['message'] ); ?></span>
					<?php if ( current_user_can( self::ADMIN ) ) : ?>
						<a class="mlclip-ab mlclip-ab-light" href="<?php echo esc_url( MLCLIP_Helpers::admin_url( 'license' ) ); ?>"><?php esc_html_e( 'Resolver', 'ml-clipping-pro' ); ?></a>
					<?php endif; ?>
				</div>
			<?php endif; ?>

			<nav class="mlclip-tabs" aria-label="<?php esc_attr_e( 'Seções do plugin', 'ml-clipping-pro' ); ?>">
				<?php foreach ( $tabs as $key => $label ) : ?>
					<a class="mlclip-tab<?php echo $tab === $key ? ' is-active' : ''; ?>" href="<?php echo esc_url( MLCLIP_Helpers::admin_url( $key ) ); ?>"<?php echo $tab === $key ? ' aria-current="page"' : ''; ?>><?php echo esc_html( $label ); ?><?php if ( 'review' === $key && $pending > 0 ) : ?><em class="mlclip-tab-count"><?php echo (int) $pending; ?></em><?php endif; ?></a>
				<?php endforeach; ?>
			</nav>

			<div class="mlclip-panel">
				<?php
				switch ( $tab ) {
					case 'review':
						self::tab_review( $lic['active'] );
						break;
					case 'items':
						'' !== $edit ? self::tab_item_editor( $edit, $lic['active'] ) : self::tab_items( $lic['active'] );
						break;
					case 'names':
						'' !== $edit ? self::tab_name_editor( $edit, $lic['active'] ) : self::tab_names( $lic['active'] );
						break;
					case 'search':
						self::tab_search();
						break;
					case 'import':
						self::tab_import( $lic['active'] );
						break;
					case 'appearance':
						self::tab_appearance();
						break;
					case 'license':
						self::tab_license( $lic );
						break;
					default:
						self::tab_dashboard( $lic['active'] );
				}
				?>
			</div>
		</div>
		<?php
	}

	/**
	 * Formulário-botão de POST.
	 *
	 * @param array<string, string|int> $fields Campos ocultos.
	 */
	private static function post_button( string $action, array $fields, string $label, string $class = 'mlclip-ab', string $confirm = '' ): void {
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="mlclip-inline-form"<?php echo '' !== $confirm ? ' data-confirm="' . esc_attr( $confirm ) . '"' : ''; ?>>
			<?php wp_nonce_field( $action ); ?>
			<input type="hidden" name="action" value="<?php echo esc_attr( $action ); ?>">
			<?php foreach ( $fields as $name => $value ) : ?>
				<input type="hidden" name="<?php echo esc_attr( (string) $name ); ?>" value="<?php echo esc_attr( (string) $value ); ?>">
			<?php endforeach; ?>
			<button type="submit" class="<?php echo esc_attr( $class ); ?>"><?php echo esc_html( $label ); ?></button>
		</form>
		<?php
	}

	/**
	 * Campo de texto.
	 *
	 * @param array<string, mixed> $o Opções (type, placeholder, help, mask, id, required).
	 */
	private static function text( string $name, string $label, string $value, array $o = array() ): void {
		$id = 'mlclip-' . str_replace( '_', '-', $name );
		?>
		<div class="mlclip-field<?php echo ! empty( $o['wide'] ) ? ' is-wide' : ''; ?>">
			<label for="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $label ); ?><?php echo ! empty( $o['required'] ) ? ' <span class="mlclip-req">*</span>' : ''; ?></label>
			<input type="<?php echo esc_attr( $o['type'] ?? 'text' ); ?>" id="<?php echo esc_attr( $id ); ?>" name="mlclip[<?php echo esc_attr( $name ); ?>]" value="<?php echo esc_attr( $value ); ?>"<?php echo ! empty( $o['placeholder'] ) ? ' placeholder="' . esc_attr( (string) $o['placeholder'] ) . '"' : ''; ?><?php echo ! empty( $o['mask'] ) ? ' data-mask="' . esc_attr( (string) $o['mask'] ) . '" inputmode="numeric"' : ''; ?><?php echo isset( $o['min'] ) ? ' min="' . (int) $o['min'] . '"' : ''; ?><?php echo isset( $o['max'] ) ? ' max="' . (int) $o['max'] . '"' : ''; ?><?php echo ! empty( $o['required'] ) ? ' required' : ''; ?>>
			<?php if ( ! empty( $o['help'] ) ) : ?>
				<p class="mlclip-field-help"><?php echo esc_html( (string) $o['help'] ); ?></p>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Área de texto.
	 */
	private static function textarea( string $name, string $label, string $value, string $help = '', int $rows = 3, string $placeholder = '' ): void {
		$id = 'mlclip-' . str_replace( '_', '-', $name );
		?>
		<div class="mlclip-field is-wide">
			<label for="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $label ); ?></label>
			<textarea id="<?php echo esc_attr( $id ); ?>" name="mlclip[<?php echo esc_attr( $name ); ?>]" rows="<?php echo (int) $rows; ?>"<?php echo '' !== $placeholder ? ' placeholder="' . esc_attr( $placeholder ) . '"' : ''; ?>><?php echo esc_textarea( $value ); ?></textarea>
			<?php if ( '' !== $help ) : ?>
				<p class="mlclip-field-help"><?php echo esc_html( $help ); ?></p>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Lista de escolha.
	 *
	 * @param array<string, string> $choices Opções.
	 */
	private static function select( string $name, string $label, array $choices, string $value, string $help = '' ): void {
		$id = 'mlclip-' . str_replace( '_', '-', $name );
		?>
		<div class="mlclip-field">
			<label for="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $label ); ?></label>
			<select id="<?php echo esc_attr( $id ); ?>" name="mlclip[<?php echo esc_attr( $name ); ?>]">
				<?php foreach ( $choices as $k => $l ) : ?>
					<option value="<?php echo esc_attr( (string) $k ); ?>"<?php selected( $value, (string) $k ); ?>><?php echo esc_html( $l ); ?></option>
				<?php endforeach; ?>
			</select>
			<?php if ( '' !== $help ) : ?>
				<p class="mlclip-field-help"><?php echo esc_html( $help ); ?></p>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Interruptor.
	 */
	private static function toggle( string $name, string $label, bool $on, string $help = '', string $confirm_on = '' ): void {
		?>
		<div class="mlclip-field">
			<label class="mlclip-switch">
				<input type="checkbox" name="mlclip[<?php echo esc_attr( $name ); ?>]" value="1"<?php checked( $on ); ?><?php echo '' !== $confirm_on ? ' data-confirm-on="' . esc_attr( $confirm_on ) . '"' : ''; ?>>
				<span class="mlclip-switch-ui" aria-hidden="true"></span>
				<span><?php echo esc_html( $label ); ?></span>
			</label>
			<?php if ( '' !== $help ) : ?>
				<p class="mlclip-field-help"><?php echo esc_html( $help ); ?></p>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Caixas de nomes (etiquetas).
	 *
	 * @param array<int, int> $selected Selecionados.
	 */
	private static function name_checks( string $field, array $selected, string $label, string $help = '' ): void {
		$names = MLCLIP_Names::all();
		?>
		<div class="mlclip-field is-wide">
			<span class="mlclip-field-label"><?php echo esc_html( $label ); ?></span>
			<?php if ( ! $names ) : ?>
				<p class="mlclip-field-help"><?php esc_html_e( 'Nenhum nome cadastrado ainda.', 'ml-clipping-pro' ); ?></p>
			<?php else : ?>
				<div class="mlclip-pills">
					<?php foreach ( $names as $n ) : ?>
						<label class="mlclip-pill"><input type="checkbox" name="<?php echo esc_attr( $field ); ?>[]" value="<?php echo (int) $n['id']; ?>"<?php checked( in_array( (int) $n['id'], $selected, true ) ); ?>><span><?php echo esc_html( (string) $n['name'] ); ?></span></label>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
			<?php if ( '' !== $help ) : ?>
				<p class="mlclip-field-help"><?php echo esc_html( $help ); ?></p>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Selo da nota.
	 */
	private static function score_chip( int $score ): string {
		return '<span class="mlclip-score mlclip-score-' . esc_attr( MLCLIP_Model::band( $score ) ) . '" title="' . esc_attr__( 'Nota de relevância', 'ml-clipping-pro' ) . '">' . esc_html( MLCLIP_Model::band_label( $score ) ) . ' <b>' . (int) $score . '</b></span>';
	}

	/**
	 * Rótulo da origem.
	 */
	private static function origin_label( string $origin ): string {
		$labels = array(
			'google' => 'Google Notícias',
			'bing'   => 'Bing Notícias',
			'gdelt'  => 'GDELT',
			'manual' => __( 'Manual', 'ml-clipping-pro' ),
			'import' => __( 'Importada', 'ml-clipping-pro' ),
		);
		return $labels[ $origin ] ?? $origin;
	}

	/* ------------------------------------------------------------ Painel */

	/**
	 * Aba Painel.
	 */
	private static function tab_dashboard( bool $licensed ): void {
		$c     = MLCLIP_Model::counts();
		$names = MLCLIP_Names::all();
		$s     = MLCLIP_Settings::all();
		$next  = MLCLIP_Engine::next_run();
		$runs  = MLCLIP_Engine::runs();
		$page  = (int) get_option( 'mlclip_page_id', 0 );
		$page  = $page && 'publish' === get_post_status( $page ) ? $page : 0;
		$steps = array(
			array( count( $names ) > 0, __( 'Cadastre os nomes que o clipping vai acompanhar', 'ml-clipping-pro' ), MLCLIP_Helpers::admin_url( 'names', array( 'edit' => 'new' ) ), __( '+ Nome', 'ml-clipping-pro' ) ),
			array( (int) $c['publish'] > 0, __( 'Busque, revise e aprove as primeiras matérias (ou importe o clipping antigo)', 'ml-clipping-pro' ), MLCLIP_Helpers::admin_url( 'import' ), __( 'Importar', 'ml-clipping-pro' ) ),
			array( (bool) $page, __( 'Crie a página do clipping no site', 'ml-clipping-pro' ), '', __( 'Criar página', 'ml-clipping-pro' ) ),
		);
		$freq = MLCLIP_Settings::frequency_labels();
		?>
		<div class="mlclip-cards-4">
			<a class="mlclip-stat mlclip-stat-alert" href="<?php echo esc_url( MLCLIP_Helpers::admin_url( 'review' ) ); ?>"><span><?php esc_html_e( 'Aguardando revisão', 'ml-clipping-pro' ); ?></span><strong><?php echo (int) $c['pending']; ?></strong><small><?php esc_html_e( 'Aprove ou descarte', 'ml-clipping-pro' ); ?></small></a>
			<a class="mlclip-stat" href="<?php echo esc_url( MLCLIP_Helpers::admin_url( 'items' ) ); ?>"><span><?php esc_html_e( 'No site', 'ml-clipping-pro' ); ?></span><strong><?php echo (int) $c['publish']; ?></strong><small><?php esc_html_e( 'Matérias aprovadas', 'ml-clipping-pro' ); ?></small></a>
			<a class="mlclip-stat" href="<?php echo esc_url( MLCLIP_Helpers::admin_url( 'items', array( 'view' => 'discard' ) ) ); ?>"><span><?php esc_html_e( 'Descartadas', 'ml-clipping-pro' ); ?></span><strong><?php echo (int) $c[ MLCLIP_Model::DISCARD ]; ?></strong><small><?php esc_html_e( 'Guardadas, dá para recuperar', 'ml-clipping-pro' ); ?></small></a>
			<a class="mlclip-stat" href="<?php echo esc_url( MLCLIP_Helpers::admin_url( 'items', array( 'view' => 'down' ) ) ); ?>"><span><?php esc_html_e( 'Links fora do ar', 'ml-clipping-pro' ); ?></span><strong><?php echo (int) $c['down']; ?></strong><small><?php esc_html_e( 'Usando a cópia arquivada', 'ml-clipping-pro' ); ?></small></a>
		</div>

		<article class="mlclip-card mlclip-runner" id="mlclip-runner">
			<header class="mlclip-card-head mlclip-card-head-row">
				<div>
					<h3><?php esc_html_e( 'Busca automática', 'ml-clipping-pro' ); ?></h3>
					<p>
						<?php
						echo esc_html(
							sprintf(
								/* translators: 1: frequency, 2: names count, 3: next run. */
								__( '%1$s · %2$d nome(s) ativo(s) · próxima busca: %3$s', 'ml-clipping-pro' ),
								$freq[ $s['frequency'] ] ?? '',
								count( MLCLIP_Names::all( true ) ),
								$next ? MLCLIP_Helpers::show_datetime( $next ) : __( 'não agendada', 'ml-clipping-pro' )
							)
						);
						?>
					</p>
				</div>
				<button type="button" class="mlclip-ab" data-run="start"<?php disabled( ! $licensed || ! $names ); ?>><?php esc_html_e( 'Buscar agora', 'ml-clipping-pro' ); ?></button>
			</header>
			<div class="mlclip-progress" hidden>
				<div class="mlclip-progress-bar"><span></span></div>
				<p class="mlclip-progress-text" aria-live="polite"></p>
			</div>
			<?php if ( $runs ) : ?>
				<div class="mlclip-table-wrap mlclip-mt">
					<table class="mlclip-table mlclip-table-sm">
						<thead><tr><th><?php esc_html_e( 'Quando', 'ml-clipping-pro' ); ?></th><th><?php esc_html_e( 'Como', 'ml-clipping-pro' ); ?></th><th><?php esc_html_e( 'Encontradas', 'ml-clipping-pro' ); ?></th><th><?php esc_html_e( 'Novas na fila', 'ml-clipping-pro' ); ?></th><th><?php esc_html_e( 'Descartadas pela nota', 'ml-clipping-pro' ); ?></th><th><?php esc_html_e( 'Observação', 'ml-clipping-pro' ); ?></th></tr></thead>
						<tbody>
							<?php foreach ( array_slice( $runs, 0, 8 ) as $r ) : ?>
								<tr>
									<td data-label="<?php esc_attr_e( 'Quando', 'ml-clipping-pro' ); ?>"><?php echo esc_html( MLCLIP_Helpers::show_datetime( (int) ( $r['time'] ?? 0 ) ) ); ?></td>
									<td data-label="<?php esc_attr_e( 'Como', 'ml-clipping-pro' ); ?>"><?php echo esc_html( 'manual' === ( $r['trigger'] ?? '' ) ? __( 'Buscar agora', 'ml-clipping-pro' ) : __( 'Agendada', 'ml-clipping-pro' ) ); ?></td>
									<?php if ( ! empty( $r['paused'] ) ) : ?>
										<td colspan="3">—</td>
										<td class="mlclip-warn-text"><?php echo esc_html( (string) $r['paused'] ); ?></td>
									<?php else : ?>
										<td data-label="<?php esc_attr_e( 'Encontradas', 'ml-clipping-pro' ); ?>"><?php echo (int) ( $r['stats']['found'] ?? 0 ); ?></td>
										<td data-label="<?php esc_attr_e( 'Novas na fila', 'ml-clipping-pro' ); ?>"><strong><?php echo (int) ( $r['stats']['added'] ?? 0 ); ?></strong></td>
										<td data-label="<?php esc_attr_e( 'Descartadas pela nota', 'ml-clipping-pro' ); ?>"><?php echo (int) ( $r['stats']['discarded'] ?? 0 ); ?></td>
										<td data-label="<?php esc_attr_e( 'Observação', 'ml-clipping-pro' ); ?>"><small><?php echo esc_html( ! empty( $r['errors'] ) ? implode( ' | ', (array) $r['errors'] ) : __( 'Tudo certo', 'ml-clipping-pro' ) ); ?></small></td>
									<?php endif; ?>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				</div>
			<?php else : ?>
				<p class="mlclip-muted"><?php esc_html_e( 'Nenhuma busca feita ainda.', 'ml-clipping-pro' ); ?></p>
			<?php endif; ?>
		</article>

		<div class="mlclip-grid-2 mlclip-mt">
			<article class="mlclip-card">
				<header class="mlclip-card-head"><h3><?php esc_html_e( 'Comece em 3 passos', 'ml-clipping-pro' ); ?></h3><p><?php esc_html_e( 'Em poucos minutos o clipping fica no ar.', 'ml-clipping-pro' ); ?></p></header>
				<ol class="mlclip-steps">
					<?php foreach ( $steps as $i => $step ) : ?>
						<li class="<?php echo $step[0] ? 'is-done' : ''; ?>">
							<span class="mlclip-step-n"><?php echo $step[0] ? '✓' : (int) ( $i + 1 ); ?></span>
							<span class="mlclip-step-t"><?php echo esc_html( $step[1] ); ?></span>
							<?php
							if ( 2 === $i ) {
								if ( $page ) {
									echo '<a class="mlclip-ab mlclip-ab-light" href="' . esc_url( (string) get_permalink( $page ) ) . '" target="_blank" rel="noopener">' . esc_html__( 'Ver página', 'ml-clipping-pro' ) . '</a>';
								} elseif ( current_user_can( self::ADMIN ) ) {
									self::post_button( 'mlclip_create_page', array(), $step[3], 'mlclip-ab mlclip-ab-light' );
								}
							} else {
								echo '<a class="mlclip-ab mlclip-ab-light" href="' . esc_url( $step[2] ) . '">' . esc_html( $step[3] ) . '</a>';
							}
							?>
						</li>
					<?php endforeach; ?>
				</ol>
			</article>
			<article class="mlclip-card">
				<header class="mlclip-card-head"><h3><?php esc_html_e( 'Mostrar no site', 'ml-clipping-pro' ); ?></h3><p><?php esc_html_e( 'Use o módulo "Clipping (jornal)" no ML Builder, o bloco "Clipping" no editor ou o shortcode.', 'ml-clipping-pro' ); ?></p></header>
				<ul class="mlclip-codes">
					<li><code class="mlclip-code" data-copy="[ml_clipping]">[ml_clipping]</code><span><?php esc_html_e( 'Todos os nomes', 'ml-clipping-pro' ); ?></span></li>
					<?php foreach ( array_slice( $names, 0, 6 ) as $n ) : ?>
						<?php $code = '[ml_clipping nomes="' . $n['slug'] . '"]'; ?>
						<li><code class="mlclip-code" data-copy="<?php echo esc_attr( $code ); ?>"><?php echo esc_html( $code ); ?></code><span><?php echo esc_html( (string) $n['name'] ); ?></span></li>
					<?php endforeach; ?>
				</ul>
				<details class="mlclip-details">
					<summary><?php esc_html_e( 'Outras opções do shortcode', 'ml-clipping-pro' ); ?></summary>
					<p class="mlclip-field-help"><code>titulo="…"</code> <code>subtitulo="…"</code> <code>colunas="1-4"</code> <code>por_pagina="24"</code> <code>agrupar="auto|mes|ano"</code> <code>filtros="sim|nao"</code> <code>manchete="sim|nao"</code> <code>imagens="sim|nao"</code> <code>resumo="sim|nao"</code> <code>cabecalho="sim|nao"</code> <code>cor="#b32e34"</code></p>
				</details>
			</article>
		</div>
		<?php
	}

	/* ------------------------------------------------------------ Revisão */

	/**
	 * Fila de revisão, ordenada pela nota.
	 */
	private static function tab_review( bool $licensed ): void {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- filtros de leitura.
		$name = isset( $_GET['name'] ) ? absint( $_GET['name'] ) : 0;
		$band = isset( $_GET['band'] ) ? MLCLIP_Helpers::choice( wp_unslash( $_GET['band'] ), array( 'alta', 'media', 'baixa' ), '' ) : '';
		$pg   = isset( $_GET['pg'] ) ? max( 1, absint( $_GET['pg'] ) ) : 1;
		// phpcs:enable
		$args = array(
			'post_type'      => MLCLIP_Model::TYPE,
			'post_status'    => 'pending',
			'posts_per_page' => 40,
			'paged'          => $pg,
			'meta_key'       => '_mlclip_score', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
			'orderby'        => array(
				'meta_value_num' => 'DESC',
				'date'           => 'DESC',
			),
		);
		if ( $name ) {
			$args['tax_query'] = array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
				array(
					'taxonomy' => MLCLIP_Model::TAX,
					'field'    => 'term_id',
					'terms'    => $name,
				),
			);
		}
		if ( '' !== $band ) {
			$ranges             = array(
				'alta'  => array( 60, 100 ),
				'media' => array( 35, 59 ),
				'baixa' => array( 0, 34 ),
			);
			$args['meta_query'] = array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
				array(
					'key'     => '_mlclip_score',
					'value'   => $ranges[ $band ],
					'compare' => 'BETWEEN',
					'type'    => 'NUMERIC',
				),
			);
		}
		$q     = new \WP_Query( $args );
		$names = MLCLIP_Names::all();
		?>
		<div class="mlclip-toolbar">
			<div>
				<h3 class="mlclip-section-title"><?php esc_html_e( 'Fila de revisão', 'ml-clipping-pro' ); ?></h3>
				<p class="mlclip-muted"><?php esc_html_e( 'Ordenada pela nota de relevância: as mais importantes primeiro. Nada aparece no site sem a sua aprovação.', 'ml-clipping-pro' ); ?></p>
			</div>
			<?php if ( $licensed ) : ?>
				<?php self::post_button( 'mlclip_bulk', array( 'op' => 'approve_high' ), __( 'Aprovar todas de nota Alta', 'ml-clipping-pro' ), 'mlclip-ab mlclip-ab-light', __( 'Aprovar todas as matérias de nota Alta que estão na fila?', 'ml-clipping-pro' ) ); ?>
			<?php endif; ?>
		</div>
		<div class="mlclip-filterbar">
			<div class="mlclip-chips-nav">
				<a class="mlclip-fchip<?php echo '' === $band ? ' is-active' : ''; ?>" href="<?php echo esc_url( MLCLIP_Helpers::admin_url( 'review', $name ? array( 'name' => $name ) : array() ) ); ?>"><?php esc_html_e( 'Todas', 'ml-clipping-pro' ); ?></a>
				<?php foreach ( array( 'alta' => __( 'Nota Alta', 'ml-clipping-pro' ), 'media' => __( 'Média', 'ml-clipping-pro' ), 'baixa' => __( 'Baixa', 'ml-clipping-pro' ) ) as $k => $l ) : ?>
					<a class="mlclip-fchip mlclip-fchip-<?php echo esc_attr( $k ); ?><?php echo $band === $k ? ' is-active' : ''; ?>" href="<?php echo esc_url( MLCLIP_Helpers::admin_url( 'review', array_filter( array( 'band' => $k, 'name' => $name ) ) ) ); ?>"><?php echo esc_html( $l ); ?></a>
				<?php endforeach; ?>
			</div>
			<?php if ( count( $names ) > 1 ) : ?>
				<form method="get" class="mlclip-search">
					<input type="hidden" name="page" value="<?php echo esc_attr( self::SLUG ); ?>">
					<input type="hidden" name="tab" value="review">
					<?php if ( '' !== $band ) : ?><input type="hidden" name="band" value="<?php echo esc_attr( $band ); ?>"><?php endif; ?>
					<select name="name" data-autosubmit>
						<option value="0"><?php esc_html_e( 'Todos os nomes', 'ml-clipping-pro' ); ?></option>
						<?php foreach ( $names as $n ) : ?>
							<option value="<?php echo (int) $n['id']; ?>"<?php selected( $name, (int) $n['id'] ); ?>><?php echo esc_html( (string) $n['name'] ); ?></option>
						<?php endforeach; ?>
					</select>
				</form>
			<?php endif; ?>
		</div>

		<?php if ( ! $q->have_posts() ) : ?>
			<div class="mlclip-empty-state">
				<p><?php esc_html_e( 'Fila vazia. Nenhuma matéria aguardando revisão.', 'ml-clipping-pro' ); ?></p>
				<a class="mlclip-ab mlclip-ab-light" href="<?php echo esc_url( MLCLIP_Helpers::admin_url( 'dashboard' ) ); ?>"><?php esc_html_e( 'Ir para a busca', 'ml-clipping-pro' ); ?></a>
			</div>
			<?php
			return;
		endif;
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="mlclip-review-form">
			<?php wp_nonce_field( 'mlclip_bulk' ); ?>
			<input type="hidden" name="action" value="mlclip_bulk">
			<div class="mlclip-bulkbar">
				<label class="mlclip-check"><input type="checkbox" data-check-all> <?php esc_html_e( 'Marcar todas desta página', 'ml-clipping-pro' ); ?></label>
				<span class="mlclip-bulk-count" data-bulk-count></span>
				<?php if ( $licensed ) : ?>
					<button type="submit" name="op" value="approve" class="mlclip-ab mlclip-ab-sm" data-needs-check><?php esc_html_e( 'Aprovar marcadas', 'ml-clipping-pro' ); ?></button>
					<button type="submit" name="op" value="discard" class="mlclip-ab mlclip-ab-sm mlclip-ab-danger" data-needs-check><?php esc_html_e( 'Descartar marcadas', 'ml-clipping-pro' ); ?></button>
					<button type="submit" name="op" value="delete" class="mlclip-ab mlclip-ab-sm mlclip-ab-ghost" data-needs-check data-confirm-click="<?php esc_attr_e( 'Excluir de vez as matérias marcadas? Elas não voltam nas próximas buscas.', 'ml-clipping-pro' ); ?>"><?php esc_html_e( 'Excluir marcadas', 'ml-clipping-pro' ); ?></button>
				<?php endif; ?>
			</div>
			<div class="mlclip-review-list">
				<?php foreach ( $q->posts as $p ) : ?>
					<?php
					$d = MLCLIP_Model::get( $p );
					if ( ! $d ) {
						continue;
					}
					?>
					<article class="mlclip-rv" data-id="<?php echo (int) $d['id']; ?>">
						<label class="mlclip-rv-check"><input type="checkbox" name="ids[]" value="<?php echo (int) $d['id']; ?>"><span class="screen-reader-text"><?php esc_html_e( 'Marcar', 'ml-clipping-pro' ); ?></span></label>
						<div class="mlclip-rv-thumb" data-outlet="<?php echo esc_attr( (string) $d['outlet'] ); ?>"><?php if ( '' !== (string) $d['image'] ) : ?><img src="<?php echo esc_url( (string) $d['image'] ); ?>" alt="" loading="lazy" referrerpolicy="no-referrer"><?php else : ?><span class="mlclip-rv-ph"><?php echo esc_html( (string) $d['outlet'] ); ?></span><?php endif; ?></div>
						<div class="mlclip-rv-body">
							<div class="mlclip-rv-meta">
								<?php echo self::score_chip( (int) $d['score'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escapado em score_chip(). ?>
								<strong><?php echo esc_html( (string) $d['outlet'] ); ?></strong>
								<span><?php echo esc_html( MLCLIP_Helpers::show_date( (int) $d['date'] ) ); ?></span>
								<?php if ( 'video' === $d['media'] ) : ?><span class="mlclip-chip"><?php esc_html_e( 'Vídeo', 'ml-clipping-pro' ); ?></span><?php endif; ?>
								<?php if ( false !== strpos( (string) $d['reasons'], __( 'Data não encontrada', 'ml-clipping-pro' ) ) ) : ?><span class="mlclip-chip mlclip-chip-warning"><?php esc_html_e( 'Confira a data', 'ml-clipping-pro' ); ?></span><?php endif; ?><?php if ( false !== strpos( (string) $d['reasons'], __( 'Título não encontrado', 'ml-clipping-pro' ) ) ) : ?><span class="mlclip-chip mlclip-chip-warning"><?php esc_html_e( 'Confira o título', 'ml-clipping-pro' ); ?></span><?php endif; ?>
								<?php foreach ( (array) $d['names'] as $label ) : ?><span class="mlclip-chip mlclip-chip-trial"><?php echo esc_html( (string) $label ); ?></span><?php endforeach; ?>
							</div>
							<a class="mlclip-rv-title" href="<?php echo esc_url( (string) $d['url'] ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( (string) $d['title'] ); ?> <span aria-hidden="true">↗</span></a>
							<?php if ( '' !== (string) $d['excerpt'] ) : ?><p class="mlclip-rv-dek"><?php echo esc_html( (string) $d['excerpt'] ); ?></p><?php endif; ?>
							<p class="mlclip-rv-why"><?php echo esc_html( (string) $d['reasons'] ); ?> · <?php echo esc_html( self::origin_label( (string) $d['origin'] ) ); ?></p>
						</div>
						<div class="mlclip-rv-actions">
							<?php if ( $licensed ) : ?>
								<button type="button" class="mlclip-ab mlclip-ab-sm" data-review="approve"><?php esc_html_e( 'Aprovar', 'ml-clipping-pro' ); ?></button>
								<button type="button" class="mlclip-ab mlclip-ab-sm mlclip-ab-light" data-review="discard"><?php esc_html_e( 'Descartar', 'ml-clipping-pro' ); ?></button>
								<button type="button" class="mlclip-ab mlclip-ab-sm mlclip-ab-ghost" data-review="delete" data-confirm-click="<?php esc_attr_e( 'Excluir esta matéria de vez? Ela não volta nas próximas buscas.', 'ml-clipping-pro' ); ?>"><?php esc_html_e( 'Excluir', 'ml-clipping-pro' ); ?></button>
								<a class="mlclip-ab mlclip-ab-sm mlclip-ab-ghost" href="<?php echo esc_url( MLCLIP_Helpers::admin_url( 'items', array( 'edit' => (int) $d['id'] ) ) ); ?>"><?php esc_html_e( 'Editar', 'ml-clipping-pro' ); ?></a>
							<?php endif; ?>
						</div>
					</article>
				<?php endforeach; ?>
			</div>
		</form>
		<?php
		self::pager( $q, 'review', array_filter( array( 'name' => $name, 'band' => $band ) ), $pg );
	}

	/**
	 * Paginação simples.
	 *
	 * @param array<string, mixed> $args Argumentos.
	 */
	private static function pager( \WP_Query $q, string $tab, array $args, int $pg ): void {
		if ( $q->max_num_pages < 2 ) {
			return;
		}
		?>
		<nav class="mlclip-pager" aria-label="<?php esc_attr_e( 'Páginas', 'ml-clipping-pro' ); ?>">
			<?php if ( $pg > 1 ) : ?>
				<a class="mlclip-ab mlclip-ab-light mlclip-ab-sm" href="<?php echo esc_url( MLCLIP_Helpers::admin_url( $tab, array_merge( $args, array( 'pg' => $pg - 1 ) ) ) ); ?>">← <?php esc_html_e( 'Anterior', 'ml-clipping-pro' ); ?></a>
			<?php endif; ?>
			<span><?php echo esc_html( sprintf( /* translators: 1: page, 2: pages. */ __( 'Página %1$d de %2$d', 'ml-clipping-pro' ), $pg, (int) $q->max_num_pages ) ); ?></span>
			<?php if ( $pg < $q->max_num_pages ) : ?>
				<a class="mlclip-ab mlclip-ab-light mlclip-ab-sm" href="<?php echo esc_url( MLCLIP_Helpers::admin_url( $tab, array_merge( $args, array( 'pg' => $pg + 1 ) ) ) ); ?>"><?php esc_html_e( 'Próxima', 'ml-clipping-pro' ); ?> →</a>
			<?php endif; ?>
		</nav>
		<?php
	}

	/* ------------------------------------------------------------ Matérias */

	/**
	 * Lista de matérias (aprovadas, descartadas, fora do ar).
	 */
	private static function tab_items( bool $licensed ): void {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- filtros de leitura.
		$view = isset( $_GET['view'] ) ? MLCLIP_Helpers::choice( wp_unslash( $_GET['view'] ), array( 'publish', 'discard', 'down', 'all' ), 'publish' ) : 'publish';
		$s    = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';
		$name = isset( $_GET['name'] ) ? absint( $_GET['name'] ) : 0;
		$pg   = isset( $_GET['pg'] ) ? max( 1, absint( $_GET['pg'] ) ) : 1;
		// phpcs:enable
		$status = array(
			'publish' => 'publish',
			'discard' => MLCLIP_Model::DISCARD,
			'down'    => 'publish',
			'all'     => array( 'publish', 'pending', MLCLIP_Model::DISCARD ),
		);
		$args   = array(
			'post_type'      => MLCLIP_Model::TYPE,
			'post_status'    => $status[ $view ],
			'posts_per_page' => 30,
			'paged'          => $pg,
			'orderby'        => 'date',
			'order'          => 'DESC',
			's'              => $s,
		);
		if ( 'down' === $view ) {
			$args['meta_key']   = '_mlclip_link_status'; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
			$args['meta_value'] = 'down'; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
		}
		if ( $name ) {
			$args['tax_query'] = array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
				array(
					'taxonomy' => MLCLIP_Model::TAX,
					'field'    => 'term_id',
					'terms'    => $name,
				),
			);
		}
		$q      = new \WP_Query( $args );
		$c      = MLCLIP_Model::counts();
		$chips  = array(
			'publish' => array( __( 'No site', 'ml-clipping-pro' ), $c['publish'] ),
			'discard' => array( __( 'Descartadas', 'ml-clipping-pro' ), $c[ MLCLIP_Model::DISCARD ] ),
			'down'    => array( __( 'Fora do ar', 'ml-clipping-pro' ), $c['down'] ),
			'all'     => array( __( 'Todas', 'ml-clipping-pro' ), $c['publish'] + $c[ MLCLIP_Model::DISCARD ] + $c['pending'] ),
		);
		$labels = array(
			'publish'           => __( 'No site', 'ml-clipping-pro' ),
			'pending'           => __( 'Na fila', 'ml-clipping-pro' ),
			MLCLIP_Model::DISCARD => __( 'Descartada', 'ml-clipping-pro' ),
		);
		?>
		<div class="mlclip-toolbar">
			<div>
				<h3 class="mlclip-section-title"><?php esc_html_e( 'Matérias', 'ml-clipping-pro' ); ?></h3>
				<p class="mlclip-muted"><?php esc_html_e( 'Tudo o que já passou pela revisão. Descartadas ficam guardadas e podem voltar.', 'ml-clipping-pro' ); ?></p>
			</div>
			<?php if ( $licensed ) : ?>
				<a class="mlclip-ab" href="<?php echo esc_url( MLCLIP_Helpers::admin_url( 'items', array( 'edit' => 'new' ) ) ); ?>"><?php esc_html_e( '+ Adicionar matéria', 'ml-clipping-pro' ); ?></a>
			<?php endif; ?>
		</div>
		<div class="mlclip-filterbar">
			<div class="mlclip-chips-nav">
				<?php foreach ( $chips as $k => $chip ) : ?>
					<a class="mlclip-fchip<?php echo $view === $k ? ' is-active' : ''; ?>" href="<?php echo esc_url( MLCLIP_Helpers::admin_url( 'items', array_filter( array( 'view' => $k, 'name' => $name ) ) ) ); ?>"><?php echo esc_html( $chip[0] ); ?> <em><?php echo (int) $chip[1]; ?></em></a>
				<?php endforeach; ?>
			</div>
			<form method="get" class="mlclip-search">
				<input type="hidden" name="page" value="<?php echo esc_attr( self::SLUG ); ?>">
				<input type="hidden" name="tab" value="items">
				<input type="hidden" name="view" value="<?php echo esc_attr( $view ); ?>">
				<?php $names = MLCLIP_Names::all(); ?>
				<?php if ( count( $names ) > 1 ) : ?>
					<select name="name" data-autosubmit>
						<option value="0"><?php esc_html_e( 'Todos os nomes', 'ml-clipping-pro' ); ?></option>
						<?php foreach ( $names as $n ) : ?>
							<option value="<?php echo (int) $n['id']; ?>"<?php selected( $name, (int) $n['id'] ); ?>><?php echo esc_html( (string) $n['name'] ); ?></option>
						<?php endforeach; ?>
					</select>
				<?php endif; ?>
				<input type="search" name="s" value="<?php echo esc_attr( $s ); ?>" placeholder="<?php esc_attr_e( 'Procurar pelo título…', 'ml-clipping-pro' ); ?>">
				<button type="submit" class="mlclip-ab mlclip-ab-light"><?php esc_html_e( 'Procurar', 'ml-clipping-pro' ); ?></button>
			</form>
		</div>

		<?php if ( ! $q->have_posts() ) : ?>
			<div class="mlclip-empty-state"><p><?php esc_html_e( 'Nenhuma matéria aqui.', 'ml-clipping-pro' ); ?></p></div>
			<?php
			return;
		endif;
		?>
		<div class="mlclip-table-wrap">
			<table class="mlclip-table">
				<thead><tr><th><?php esc_html_e( 'Matéria', 'ml-clipping-pro' ); ?></th><th><?php esc_html_e( 'Veículo', 'ml-clipping-pro' ); ?></th><th><?php esc_html_e( 'Data', 'ml-clipping-pro' ); ?></th><th><?php esc_html_e( 'Situação', 'ml-clipping-pro' ); ?></th><th class="mlclip-col-actions"><?php esc_html_e( 'Ações', 'ml-clipping-pro' ); ?></th></tr></thead>
				<tbody>
					<?php foreach ( $q->posts as $p ) : ?>
						<?php
						$d = MLCLIP_Model::get( $p );
						if ( ! $d ) {
							continue;
						}
						?>
						<tr>
							<td data-label="<?php esc_attr_e( 'Matéria', 'ml-clipping-pro' ); ?>">
								<a class="mlclip-strong-link" href="<?php echo esc_url( MLCLIP_Helpers::admin_url( 'items', array( 'edit' => (int) $d['id'] ) ) ); ?>"><?php echo esc_html( (string) $d['title'] ); ?></a>
								<small class="mlclip-muted">
									<?php if ( $d['featured'] ) : ?><span class="mlclip-chip mlclip-chip-ok"><?php esc_html_e( 'Manchete', 'ml-clipping-pro' ); ?></span><?php endif; ?>
									<?php if ( 'down' === $d['link_status'] ) : ?><span class="mlclip-chip mlclip-chip-error"><?php esc_html_e( 'Fora do ar', 'ml-clipping-pro' ); ?></span><?php endif; ?>
									<?php if ( false !== strpos( (string) $d['reasons'], __( 'Data não encontrada', 'ml-clipping-pro' ) ) ) : ?><span class="mlclip-chip mlclip-chip-warning"><?php esc_html_e( 'Confira a data', 'ml-clipping-pro' ); ?></span><?php endif; ?><?php if ( false !== strpos( (string) $d['reasons'], __( 'Título não encontrado', 'ml-clipping-pro' ) ) ) : ?><span class="mlclip-chip mlclip-chip-warning"><?php esc_html_e( 'Confira o título', 'ml-clipping-pro' ); ?></span><?php endif; ?>
									<?php echo esc_html( implode( ', ', (array) $d['names'] ) ); ?>
								</small>
							</td>
							<td data-label="<?php esc_attr_e( 'Veículo', 'ml-clipping-pro' ); ?>"><?php echo esc_html( (string) $d['outlet'] ); ?></td>
							<td data-label="<?php esc_attr_e( 'Data', 'ml-clipping-pro' ); ?>"><?php echo esc_html( MLCLIP_Helpers::show_date( (int) $d['date'] ) ); ?></td>
							<td data-label="<?php esc_attr_e( 'Situação', 'ml-clipping-pro' ); ?>"><?php echo esc_html( $labels[ $d['status'] ] ?? $d['status'] ); ?></td>
							<td class="mlclip-col-actions">
								<div class="mlclip-actions">
									<a class="mlclip-ab mlclip-ab-sm mlclip-ab-light" href="<?php echo esc_url( (string) $d['url'] ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Abrir', 'ml-clipping-pro' ); ?></a>
									<?php if ( $licensed ) : ?>
										<?php if ( 'publish' === $d['status'] ) : ?>
											<?php self::post_button( 'mlclip_item_action', array( 'id' => (int) $d['id'], 'op' => 'feature', 'view' => $view ), $d['featured'] ? __( 'Tirar destaque', 'ml-clipping-pro' ) : __( 'Manchete', 'ml-clipping-pro' ), 'mlclip-ab mlclip-ab-sm mlclip-ab-light' ); ?>
											<?php self::post_button( 'mlclip_item_action', array( 'id' => (int) $d['id'], 'op' => 'discard', 'view' => $view ), __( 'Tirar do site', 'ml-clipping-pro' ), 'mlclip-ab mlclip-ab-sm mlclip-ab-ghost' ); ?>
											<?php self::post_button( 'mlclip_item_action', array( 'id' => (int) $d['id'], 'op' => 'delete', 'view' => $view ), __( 'Excluir', 'ml-clipping-pro' ), 'mlclip-ab mlclip-ab-sm mlclip-ab-ghost', __( 'Excluir esta matéria de vez? Ela não volta nas próximas buscas.', 'ml-clipping-pro' ) ); ?>
										<?php elseif ( MLCLIP_Model::DISCARD === $d['status'] ) : ?>
											<?php self::post_button( 'mlclip_item_action', array( 'id' => (int) $d['id'], 'op' => 'approve', 'view' => $view ), __( 'Aprovar', 'ml-clipping-pro' ), 'mlclip-ab mlclip-ab-sm' ); ?>
											<?php self::post_button( 'mlclip_item_action', array( 'id' => (int) $d['id'], 'op' => 'delete', 'view' => $view ), __( 'Excluir de vez', 'ml-clipping-pro' ), 'mlclip-ab mlclip-ab-sm mlclip-ab-ghost', __( 'Excluir esta matéria definitivamente? Isso não pode ser desfeito.', 'ml-clipping-pro' ) ); ?>
										<?php else : ?>
											<?php self::post_button( 'mlclip_item_action', array( 'id' => (int) $d['id'], 'op' => 'approve', 'view' => $view ), __( 'Aprovar', 'ml-clipping-pro' ), 'mlclip-ab mlclip-ab-sm' ); ?>
											<?php self::post_button( 'mlclip_item_action', array( 'id' => (int) $d['id'], 'op' => 'delete', 'view' => $view ), __( 'Excluir', 'ml-clipping-pro' ), 'mlclip-ab mlclip-ab-sm mlclip-ab-ghost', __( 'Excluir esta matéria de vez? Ela não volta nas próximas buscas.', 'ml-clipping-pro' ) ); ?>
										<?php endif; ?>
									<?php endif; ?>
								</div>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
		<?php
		self::pager( $q, 'items', array_filter( array( 'view' => $view, 's' => $s, 'name' => $name ) ), $pg );
	}

	/**
	 * Ficha da matéria (nova ou edição).
	 */
	private static function tab_item_editor( string $edit, bool $licensed ): void {
		$id = 'new' === $edit ? 0 : absint( $edit );
		$d  = $id ? MLCLIP_Model::get( $id ) : null;
		if ( $id && ! $d ) {
			echo '<div class="mlclip-empty-state"><p>' . esc_html__( 'Matéria não encontrada.', 'ml-clipping-pro' ) . '</p></div>';
			return;
		}
		$d = $d ? $d : array(
			'id'          => 0,
			'title'       => '',
			'url'         => '',
			'excerpt'     => '',
			'outlet'      => '',
			'image'       => '',
			'date'        => time(),
			'media'       => 'texto',
			'featured'    => false,
			'status'      => 'publish',
			'names'       => array(),
			'score'       => 100,
			'reasons'     => '',
			'origin'      => 'manual',
			'archive_url' => '',
			'link_status' => '',
		);
		$selected = array_map( 'intval', array_keys( (array) $d['names'] ) );
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="mlclip-editor" data-unsaved>
			<?php wp_nonce_field( 'mlclip_save_item' ); ?>
			<input type="hidden" name="action" value="mlclip_save_item">
			<input type="hidden" name="id" value="<?php echo (int) $d['id']; ?>">
			<div class="mlclip-editor-bar">
				<a class="mlclip-back" href="<?php echo esc_url( MLCLIP_Helpers::admin_url( 'items' ) ); ?>">← <?php esc_html_e( 'Matérias', 'ml-clipping-pro' ); ?></a>
				<strong class="mlclip-editor-name"><?php echo esc_html( $d['id'] ? (string) $d['title'] : __( 'Nova matéria', 'ml-clipping-pro' ) ); ?></strong>
				<?php if ( ! $licensed ) : ?><span class="mlclip-locked-note"><?php esc_html_e( 'Licença necessária para salvar', 'ml-clipping-pro' ); ?></span><?php endif; ?>
				<button type="submit" class="mlclip-ab mlclip-save"<?php disabled( ! $licensed ); ?>><?php esc_html_e( 'Salvar matéria', 'ml-clipping-pro' ); ?></button>
			</div>
			<div class="mlclip-grid-2">
				<article class="mlclip-card">
					<header class="mlclip-card-head"><h3><?php esc_html_e( 'Matéria', 'ml-clipping-pro' ); ?></h3><p><?php esc_html_e( 'Cole o link e clique em "Preencher pelo link": título, resumo, foto, data e veículo vêm da página da matéria.', 'ml-clipping-pro' ); ?></p></header>
					<div class="mlclip-field is-wide">
						<label for="mlclip-url"><?php esc_html_e( 'Link da matéria', 'ml-clipping-pro' ); ?> <span class="mlclip-req">*</span></label>
						<div class="mlclip-input-row">
							<input type="url" id="mlclip-url" name="mlclip[url]" value="<?php echo esc_attr( (string) $d['url'] ); ?>" placeholder="https://" required>
							<button type="button" class="mlclip-ab mlclip-ab-light" data-fetch-link><?php esc_html_e( 'Preencher pelo link', 'ml-clipping-pro' ); ?></button>
						</div>
					</div>
					<div class="mlclip-form-grid">
						<?php
						self::text( 'title', __( 'Título', 'ml-clipping-pro' ), (string) $d['title'], array( 'required' => true, 'wide' => true ) );
						self::text( 'outlet', __( 'Veículo', 'ml-clipping-pro' ), (string) $d['outlet'], array( 'placeholder' => __( 'Ex.: O Globo', 'ml-clipping-pro' ) ) );
						self::text( 'date', __( 'Data da matéria', 'ml-clipping-pro' ), wp_date( 'd/m/Y', (int) $d['date'] ), array( 'mask' => 'date', 'placeholder' => 'DD/MM/AAAA', 'required' => true ) );
						?>
					</div>
					<?php self::textarea( 'excerpt', __( 'Resumo', 'ml-clipping-pro' ), (string) $d['excerpt'], __( 'Aparece abaixo do título no jornal. Até 2 ou 3 linhas.', 'ml-clipping-pro' ), 3 ); ?>
					<div class="mlclip-field is-wide">
						<label for="mlclip-image"><?php esc_html_e( 'Foto (endereço da imagem)', 'ml-clipping-pro' ); ?></label>
						<div class="mlclip-image-row">
							<span class="mlclip-image-preview"><?php if ( '' !== (string) $d['image'] ) : ?><img src="<?php echo esc_url( (string) $d['image'] ); ?>" alt="" referrerpolicy="no-referrer"><?php endif; ?></span>
							<input type="url" id="mlclip-image" name="mlclip[image]" value="<?php echo esc_attr( (string) $d['image'] ); ?>" placeholder="https://">
						</div>
						<p class="mlclip-field-help"><?php esc_html_e( 'Vazio: a matéria aparece sem foto.', 'ml-clipping-pro' ); ?></p>
					</div>
				</article>
				<article class="mlclip-card">
					<header class="mlclip-card-head"><h3><?php esc_html_e( 'No site', 'ml-clipping-pro' ); ?></h3><p><?php esc_html_e( 'Situação, destaque e a quem a matéria se refere.', 'ml-clipping-pro' ); ?></p></header>
					<div class="mlclip-form-grid">
						<?php
						self::select(
							'status',
							__( 'Situação', 'ml-clipping-pro' ),
							array(
								'publish'             => __( 'No site (aprovada)', 'ml-clipping-pro' ),
								'pending'             => __( 'Na fila de revisão', 'ml-clipping-pro' ),
								MLCLIP_Model::DISCARD => __( 'Descartada', 'ml-clipping-pro' ),
							),
							(string) $d['status']
						);
						self::select(
							'media',
							__( 'Tipo', 'ml-clipping-pro' ),
							array(
								'texto' => __( 'Matéria (texto)', 'ml-clipping-pro' ),
								'video' => __( 'Vídeo / reportagem de TV', 'ml-clipping-pro' ),
							),
							(string) $d['media']
						);
						?>
					</div>
					<?php
					self::toggle( 'featured', __( 'Manchete do mês (destaque no topo)', 'ml-clipping-pro' ), (bool) $d['featured'] );
					self::name_checks( 'mlclip[names]', $selected, __( 'Nomes citados', 'ml-clipping-pro' ), __( 'Define em quais páginas de clipping a matéria aparece.', 'ml-clipping-pro' ) );
					?>
					<?php if ( $d['id'] ) : ?>
						<dl class="mlclip-account-data mlclip-mt">
							<div><dt><?php esc_html_e( 'Nota', 'ml-clipping-pro' ); ?></dt><dd><?php echo self::score_chip( (int) $d['score'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escapado em score_chip(). ?></dd></div>
							<div><dt><?php esc_html_e( 'Origem', 'ml-clipping-pro' ); ?></dt><dd><?php echo esc_html( self::origin_label( (string) $d['origin'] ) ); ?></dd></div>
							<div><dt><?php esc_html_e( 'Por quê', 'ml-clipping-pro' ); ?></dt><dd><?php echo esc_html( '' !== (string) $d['reasons'] ? (string) $d['reasons'] : '—' ); ?></dd></div>
							<div><dt><?php esc_html_e( 'Cópia arquivada', 'ml-clipping-pro' ); ?></dt><dd><?php echo '' !== (string) $d['archive_url'] ? '<a href="' . esc_url( (string) $d['archive_url'] ) . '" target="_blank" rel="noopener">' . esc_html__( 'Abrir', 'ml-clipping-pro' ) . '</a>' : esc_html__( 'Ainda não', 'ml-clipping-pro' ); ?></dd></div>
						</dl>
					<?php endif; ?>
				</article>
			</div>
		</form>
		<?php if ( $d['id'] && $licensed && 'publish' === $d['status'] ) : ?>
			<div class="mlclip-actions mlclip-mt">
				<?php self::post_button( 'mlclip_item_action', array( 'id' => (int) $d['id'], 'op' => 'recheck' ), __( 'Conferir o link agora', 'ml-clipping-pro' ), 'mlclip-ab mlclip-ab-light' ); ?>
			</div>
		<?php endif; ?>
		<?php
	}

	/* ------------------------------------------------------------ Nomes */

	/**
	 * Lista dos nomes monitorados.
	 */
	private static function tab_names( bool $licensed ): void {
		$names = MLCLIP_Names::all();
		$rules = MLCLIP_Names::rules();
		?>
		<div class="mlclip-toolbar">
			<div>
				<h3 class="mlclip-section-title"><?php esc_html_e( 'Nomes monitorados', 'ml-clipping-pro' ); ?></h3>
				<p class="mlclip-muted"><?php esc_html_e( 'Quantos nomes quiser: entidade, pessoa, artista, empresa, evento. Cada um vira uma etiqueta para montar páginas de clipping separadas.', 'ml-clipping-pro' ); ?></p>
			</div>
			<?php if ( $licensed ) : ?>
				<a class="mlclip-ab" href="<?php echo esc_url( MLCLIP_Helpers::admin_url( 'names', array( 'edit' => 'new' ) ) ); ?>"><?php esc_html_e( '+ Adicionar nome', 'ml-clipping-pro' ); ?></a>
			<?php endif; ?>
		</div>
		<?php if ( ! $names ) : ?>
			<div class="mlclip-empty-state">
				<p><?php esc_html_e( 'Nenhum nome ainda. Comece pelo nome principal do site (ex.: o nome da entidade).', 'ml-clipping-pro' ); ?></p>
				<?php if ( $licensed ) : ?><a class="mlclip-ab" href="<?php echo esc_url( MLCLIP_Helpers::admin_url( 'names', array( 'edit' => 'new' ) ) ); ?>"><?php esc_html_e( '+ Adicionar nome', 'ml-clipping-pro' ); ?></a><?php endif; ?>
			</div>
			<?php
			return;
		endif;
		?>
		<div class="mlclip-table-wrap">
			<table class="mlclip-table">
				<thead><tr><th><?php esc_html_e( 'Nome', 'ml-clipping-pro' ); ?></th><th><?php esc_html_e( 'Regra de entrada', 'ml-clipping-pro' ); ?></th><th><?php esc_html_e( 'Matérias', 'ml-clipping-pro' ); ?></th><th><?php esc_html_e( 'Última busca', 'ml-clipping-pro' ); ?></th><th class="mlclip-col-actions"><?php esc_html_e( 'Ações', 'ml-clipping-pro' ); ?></th></tr></thead>
				<tbody>
					<?php foreach ( $names as $n ) : ?>
						<?php $c = MLCLIP_Model::counts( (int) $n['id'] ); ?>
						<tr>
							<td data-label="<?php esc_attr_e( 'Nome', 'ml-clipping-pro' ); ?>">
								<a class="mlclip-strong-link" href="<?php echo esc_url( MLCLIP_Helpers::admin_url( 'names', array( 'edit' => (int) $n['id'] ) ) ); ?>"><?php echo esc_html( (string) $n['name'] ); ?></a>
								<?php if ( ! $n['active'] ) : ?><span class="mlclip-chip mlclip-chip-warning"><?php esc_html_e( 'Pausado', 'ml-clipping-pro' ); ?></span><?php endif; ?>
								<small class="mlclip-muted"><?php echo esc_html( $n['aliases'] ? __( 'Variações:', 'ml-clipping-pro' ) . ' ' . implode( ', ', $n['aliases'] ) : __( 'Sem variações', 'ml-clipping-pro' ) ); ?></small>
								<small><code class="mlclip-code" data-copy="<?php echo esc_attr( '[ml_clipping nomes="' . $n['slug'] . '"]' ); ?>">[ml_clipping nomes="<?php echo esc_html( (string) $n['slug'] ); ?>"]</code></small>
							</td>
							<td data-label="<?php esc_attr_e( 'Regra de entrada', 'ml-clipping-pro' ); ?>"><?php echo esc_html( $rules[ $n['rule'] ] ?? '' ); ?></td>
							<td data-label="<?php esc_attr_e( 'Matérias', 'ml-clipping-pro' ); ?>"><strong><?php echo (int) $c['publish']; ?></strong> <?php esc_html_e( 'no site', 'ml-clipping-pro' ); ?><small class="mlclip-muted"><?php echo esc_html( sprintf( /* translators: %d: count. */ __( '%d na fila', 'ml-clipping-pro' ), $c['pending'] ) ); ?></small></td>
							<td data-label="<?php esc_attr_e( 'Última busca', 'ml-clipping-pro' ); ?>"><?php echo esc_html( $n['last_run'] ? MLCLIP_Helpers::show_datetime( (int) $n['last_run'] ) : '—' ); ?></td>
							<td class="mlclip-col-actions">
								<div class="mlclip-actions">
									<?php if ( $licensed ) : ?>
										<a class="mlclip-ab mlclip-ab-sm mlclip-ab-light" href="<?php echo esc_url( MLCLIP_Helpers::admin_url( 'names', array( 'edit' => (int) $n['id'] ) ) ); ?>"><?php esc_html_e( 'Editar', 'ml-clipping-pro' ); ?></a>
										<?php self::post_button( 'mlclip_name_action', array( 'id' => (int) $n['id'], 'op' => 'toggle' ), $n['active'] ? __( 'Pausar', 'ml-clipping-pro' ) : __( 'Ligar', 'ml-clipping-pro' ), 'mlclip-ab mlclip-ab-sm mlclip-ab-light' ); ?>
										<?php self::post_button( 'mlclip_name_action', array( 'id' => (int) $n['id'], 'op' => 'delete' ), __( 'Remover', 'ml-clipping-pro' ), 'mlclip-ab mlclip-ab-sm mlclip-ab-ghost', __( 'Remover este nome da lista? As matérias dele continuam no clipping.', 'ml-clipping-pro' ) ); ?>
									<?php endif; ?>
								</div>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
		<?php
	}

	/**
	 * Ficha de um nome.
	 */
	private static function tab_name_editor( string $edit, bool $licensed ): void {
		$id = 'new' === $edit ? 0 : absint( $edit );
		$n  = $id ? MLCLIP_Names::get( $id ) : MLCLIP_Names::defaults();
		if ( ! $n ) {
			echo '<div class="mlclip-empty-state"><p>' . esc_html__( 'Nome não encontrado.', 'ml-clipping-pro' ) . '</p></div>';
			return;
		}
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="mlclip-editor" data-unsaved>
			<?php wp_nonce_field( 'mlclip_save_name' ); ?>
			<input type="hidden" name="action" value="mlclip_save_name">
			<input type="hidden" name="id" value="<?php echo (int) $n['id']; ?>">
			<div class="mlclip-editor-bar">
				<a class="mlclip-back" href="<?php echo esc_url( MLCLIP_Helpers::admin_url( 'names' ) ); ?>">← <?php esc_html_e( 'Nomes monitorados', 'ml-clipping-pro' ); ?></a>
				<strong class="mlclip-editor-name"><?php echo esc_html( $n['id'] ? (string) $n['name'] : __( 'Novo nome', 'ml-clipping-pro' ) ); ?></strong>
				<?php if ( ! $licensed ) : ?><span class="mlclip-locked-note"><?php esc_html_e( 'Licença necessária para salvar', 'ml-clipping-pro' ); ?></span><?php endif; ?>
				<button type="submit" class="mlclip-ab mlclip-save"<?php disabled( ! $licensed ); ?>><?php esc_html_e( 'Salvar nome', 'ml-clipping-pro' ); ?></button>
			</div>
			<div class="mlclip-grid-2">
				<article class="mlclip-card">
					<header class="mlclip-card-head"><h3><?php esc_html_e( 'O que procurar', 'ml-clipping-pro' ); ?></h3><p><?php esc_html_e( 'O nome é buscado como expressão exata. Acentos e maiúsculas não importam.', 'ml-clipping-pro' ); ?></p></header>
					<div class="mlclip-form-grid">
						<?php
						self::text( 'name', __( 'Nome', 'ml-clipping-pro' ), (string) $n['name'], array( 'required' => true, 'placeholder' => __( 'Ex.: Cacique de Ramos', 'ml-clipping-pro' ) ) );
						self::text( 'slug', __( 'Etiqueta (para o shortcode)', 'ml-clipping-pro' ), (string) $n['slug'], array( 'placeholder' => __( 'gerada pelo nome', 'ml-clipping-pro' ), 'help' => __( 'Usada em [ml_clipping nomes="etiqueta"].', 'ml-clipping-pro' ) ) );
						?>
					</div>
					<?php
					self::textarea( 'aliases', __( 'Variações e apelidos', 'ml-clipping-pro' ), implode( "\n", (array) $n['aliases'] ), __( 'Um por linha. Ex.: Bloco Cacique de Ramos, G.R.B.C. Cacique de Ramos.', 'ml-clipping-pro' ), 3 );
					self::textarea( 'exclude', __( 'Palavras a excluir', 'ml-clipping-pro' ), implode( "\n", (array) $n['exclude'] ), __( 'Um por linha. Matéria com qualquer uma delas nem entra na fila (ex.: um endereço ou um homônimo).', 'ml-clipping-pro' ), 3 );
					self::textarea( 'required', __( 'Palavras obrigatórias (opcional)', 'ml-clipping-pro' ), implode( "\n", (array) $n['required'] ), __( 'Um por linha. Se preencher, a matéria precisa ter pelo menos uma delas para ganhar nota boa (útil para nomes comuns).', 'ml-clipping-pro' ), 2 );
					?>
				</article>
				<article class="mlclip-card">
					<header class="mlclip-card-head"><h3><?php esc_html_e( 'Como filtrar', 'ml-clipping-pro' ); ?></h3><p><?php esc_html_e( 'Para nomes muito citados, a regra "título ou resumo" evita matérias que só mencionam o nome de passagem.', 'ml-clipping-pro' ); ?></p></header>
					<?php
					self::select( 'rule', __( 'Regra de entrada', 'ml-clipping-pro' ), MLCLIP_Names::rules(), (string) $n['rule'] );
					self::select( 'region', __( 'Idioma e país da busca', 'ml-clipping-pro' ), MLCLIP_Names::regions(), (string) $n['region'] );
					self::toggle( 'active', __( 'Buscar este nome automaticamente', 'ml-clipping-pro' ), (bool) $n['active'], __( 'Desligado: o nome fica pausado; as matérias continuam no site.', 'ml-clipping-pro' ) );
					?>
					<div class="mlclip-note"><?php esc_html_e( 'Nota de relevância: nome no título +50, no resumo +20, no início do texto +15, cada citação +3 (até 15), veículo preferido +15. Abaixo da nota mínima (Busca e avisos), a matéria é descartada sozinha e fica guardada em Descartadas.', 'ml-clipping-pro' ); ?></div>
				</article>
			</div>
		</form>
		<?php
	}

	/* ------------------------------------------------------------ Busca e avisos */

	/**
	 * Aba Busca e avisos.
	 */
	private static function tab_search(): void {
		$s = MLCLIP_Settings::all();
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" data-unsaved>
			<?php wp_nonce_field( 'mlclip_save_search' ); ?>
			<input type="hidden" name="action" value="mlclip_save_search">
			<div class="mlclip-grid-2">
				<article class="mlclip-card">
					<header class="mlclip-card-head"><h3><?php esc_html_e( 'Busca automática', 'ml-clipping-pro' ); ?></h3><p><?php esc_html_e( 'Roda em segundo plano, em lotes pequenos. Peso no servidor: poucos acessos por dia para cada nome.', 'ml-clipping-pro' ); ?></p></header>
					<div class="mlclip-form-grid">
						<?php
						self::select( 'frequency', __( 'Frequência', 'ml-clipping-pro' ), MLCLIP_Settings::frequency_labels(), (string) $s['frequency'] );
						$hours = array();
						for ( $h = 0; $h < 24; $h++ ) {
							$hours[ (string) $h ] = sprintf( '%02d:07', $h );
						}
						self::select( 'hour', __( 'Horário', 'ml-clipping-pro' ), $hours, (string) (int) $s['hour'], __( 'De madrugada o site tem menos visitas.', 'ml-clipping-pro' ) );
						self::text( 'min_score', __( 'Nota mínima', 'ml-clipping-pro' ), (string) (int) $s['min_score'], array( 'type' => 'number', 'min' => 0, 'max' => 90, 'help' => __( 'Abaixo dela a matéria é descartada sozinha (fica guardada).', 'ml-clipping-pro' ) ) );
						self::text( 'max_per_run', __( 'Teto de matérias novas por busca', 'ml-clipping-pro' ), (string) (int) $s['max_per_run'], array( 'type' => 'number', 'min' => 5, 'max' => 200 ) );
						self::text( 'lookback', __( 'Primeira busca: últimos dias', 'ml-clipping-pro' ), (string) (int) $s['lookback'], array( 'type' => 'number', 'min' => 1, 'max' => 365, 'help' => __( 'Depois disso cada busca pega só o que saiu desde a anterior.', 'ml-clipping-pro' ) ) );
						?>
					</div>
					<h4 class="mlclip-group"><?php esc_html_e( 'Fontes (grátis, sem chave)', 'ml-clipping-pro' ); ?></h4>
					<?php
					self::toggle( 'src_google', __( 'Google Notícias', 'ml-clipping-pro' ), '1' === $s['src_google'] );
					self::toggle( 'src_bing', __( 'Bing Notícias', 'ml-clipping-pro' ), '1' === $s['src_bing'] );
					self::toggle( 'src_gdelt', __( 'GDELT (base mundial de notícias)', 'ml-clipping-pro' ), '1' === $s['src_gdelt'] );
					self::toggle( 'auto_publish', __( 'Publicar sozinho, sem revisão', 'ml-clipping-pro' ), '1' === $s['auto_publish'], __( 'Desligado (recomendado): toda matéria passa pela sua aprovação.', 'ml-clipping-pro' ) );
					?>
				</article>
				<article class="mlclip-card">
					<header class="mlclip-card-head"><h3><?php esc_html_e( 'Aviso de matéria nova', 'ml-clipping-pro' ); ?></h3><p><?php esc_html_e( 'No máximo um e-mail por dia, só quando houver novidade.', 'ml-clipping-pro' ); ?></p></header>
					<?php
					self::toggle( 'notify_email', __( 'Mandar e-mail com as matérias novas', 'ml-clipping-pro' ), '1' === $s['notify_email'] );
					self::textarea( 'notify_to', __( 'Enviar para', 'ml-clipping-pro' ), implode( "\n", (array) $s['notify_to'] ), __( 'Um e-mail por linha.', 'ml-clipping-pro' ), 2 );
					self::toggle( 'notify_admin', __( 'Contador vermelho no menu e na barra do WordPress + faixa no Painel', 'ml-clipping-pro' ), '1' === $s['notify_admin'] );
					?>
					<h4 class="mlclip-group"><?php esc_html_e( 'Veículos', 'ml-clipping-pro' ); ?></h4>
					<?php
					self::textarea( 'preferred', __( 'Veículos preferidos (sobem na nota)', 'ml-clipping-pro' ), implode( "\n", (array) $s['preferred'] ), __( 'Um domínio por linha. Ex.: oglobo.globo.com', 'ml-clipping-pro' ), 2 );
					self::textarea( 'auto_outlets', __( 'Veículos aprovados automaticamente', 'ml-clipping-pro' ), implode( "\n", (array) $s['auto_outlets'] ), __( 'Um domínio por linha. Matéria desses veículos (com data conhecida e nota acima da mínima) é publicada sem passar pela fila; as demais continuam aguardando sua aprovação. Ex.: g1.globo.com', 'ml-clipping-pro' ), 3 );
					self::textarea( 'blocked', __( 'Veículos bloqueados (nunca entram)', 'ml-clipping-pro' ), implode( "\n", (array) $s['blocked'] ), __( 'Um domínio por linha.', 'ml-clipping-pro' ), 2 );
					?>
					<h4 class="mlclip-group"><?php esc_html_e( 'Links das matérias', 'ml-clipping-pro' ); ?></h4>
					<?php
					self::toggle( 'archive', __( 'Guardar cópia de cada matéria aprovada no Arquivo da Internet (archive.org)', 'ml-clipping-pro' ), '1' === $s['archive'] );
					self::toggle( 'linkcheck', __( 'Conferir os links toda semana (marca "Fora do ar", nunca apaga)', 'ml-clipping-pro' ), '1' === $s['linkcheck'] );
					self::toggle( 'remove_data', __( 'Apagar todas as matérias ao excluir o plugin', 'ml-clipping-pro' ), '1' === $s['remove_data'], __( 'Desligado (recomendado): excluir o plugin não apaga nada.', 'ml-clipping-pro' ), __( 'Ligar esta opção faz com que EXCLUIR o plugin apague definitivamente todas as matérias, nomes e configurações do clipping. Tem certeza?', 'ml-clipping-pro' ) );
					?>
				</article>
			</div>
			<div class="mlclip-sticky-actions"><button type="submit" class="mlclip-ab"><?php esc_html_e( 'Salvar configurações', 'ml-clipping-pro' ); ?></button></div>
		</form>
		<div class="mlclip-actions mlclip-mt">
			<?php self::post_button( 'mlclip_test_email', array(), __( 'Mandar e-mail de teste', 'ml-clipping-pro' ), 'mlclip-ab mlclip-ab-light' ); ?>
			<?php self::post_button( 'mlclip_forget_seen', array(), __( 'Reavaliar matérias já vistas', 'ml-clipping-pro' ), 'mlclip-ab mlclip-ab-ghost', __( 'A próxima busca vai reabrir as matérias da janela que foram ignoradas antes (útil depois de mudar a regra de um nome). Continuar?', 'ml-clipping-pro' ) ); ?>
		</div>
		<?php
	}

	/* ------------------------------------------------------------ Importar */

	/**
	 * Aba Importar.
	 */
	private static function tab_import( bool $licensed ): void {
		$plt   = MLCLIP_Importer::page_links_to_count();
		$pages = get_posts(
			array(
				'post_type'      => 'page',
				'post_status'    => array( 'publish', 'private', 'draft' ),
				'posts_per_page' => 300,
				'orderby'        => 'title',
				'order'          => 'ASC',
				'no_found_rows'  => true,
			)
		);
		$guess = 0;
		foreach ( $pages as $p ) {
			if ( false !== stripos( $p->post_name . ' ' . $p->post_title, 'clipping' ) && false === strpos( (string) $p->post_content, '[ml_clipping' ) ) {
				$guess = (int) $p->ID;
				break;
			}
		}
		?>
		<div class="mlclip-grid-2">
			<article class="mlclip-card" id="mlclip-importer">
				<header class="mlclip-card-head"><h3><?php esc_html_e( 'Importar clipping existente', 'ml-clipping-pro' ); ?></h3><p><?php esc_html_e( 'Cada link é aberto para preencher título, resumo, foto, data e veículo. Links repetidos são ignorados.', 'ml-clipping-pro' ); ?></p></header>
				<div class="mlclip-pills" role="radiogroup">
					<label class="mlclip-pill"><input type="radio" name="mlclip_imp_mode" value="page" checked><span><?php esc_html_e( 'Página deste site', 'ml-clipping-pro' ); ?></span></label>
					<label class="mlclip-pill"><input type="radio" name="mlclip_imp_mode" value="url"><span><?php esc_html_e( 'Página de outro site', 'ml-clipping-pro' ); ?></span></label>
					<label class="mlclip-pill"><input type="radio" name="mlclip_imp_mode" value="list"><span><?php esc_html_e( 'Colar lista de links', 'ml-clipping-pro' ); ?></span></label>
					<?php if ( $plt > 0 ) : ?>
						<label class="mlclip-pill"><input type="radio" name="mlclip_imp_mode" value="plt"><span><?php echo esc_html( sprintf( /* translators: %d: count. */ __( 'Posts do Page Links To (%d)', 'ml-clipping-pro' ), $plt ) ); ?></span></label>
					<?php endif; ?>
				</div>
				<div class="mlclip-imp-panel mlclip-mt" data-mode="page">
					<div class="mlclip-field is-wide">
						<label for="mlclip-imp-page"><?php esc_html_e( 'Página com a lista de links', 'ml-clipping-pro' ); ?></label>
						<select id="mlclip-imp-page">
							<option value="0"><?php esc_html_e( 'Escolha…', 'ml-clipping-pro' ); ?></option>
							<?php foreach ( $pages as $p ) : ?>
								<option value="<?php echo (int) $p->ID; ?>"<?php selected( $guess, (int) $p->ID ); ?>><?php echo esc_html( '' !== $p->post_title ? $p->post_title : '#' . $p->ID ); ?></option>
							<?php endforeach; ?>
						</select>
						<p class="mlclip-field-help"><?php esc_html_e( 'Só os links para outros sites entram (redes sociais e links do próprio site ficam de fora).', 'ml-clipping-pro' ); ?></p>
					</div>
				</div>
				<div class="mlclip-imp-panel mlclip-mt" data-mode="url" hidden>
					<div class="mlclip-field is-wide">
						<label for="mlclip-imp-url"><?php esc_html_e( 'Endereço da página', 'ml-clipping-pro' ); ?></label>
						<input type="url" id="mlclip-imp-url" placeholder="https://">
					</div>
				</div>
				<div class="mlclip-imp-panel mlclip-mt" data-mode="list" hidden>
					<div class="mlclip-field is-wide">
						<label for="mlclip-imp-list"><?php esc_html_e( 'Links (um por linha)', 'ml-clipping-pro' ); ?></label>
						<textarea id="mlclip-imp-list" rows="8" placeholder="https://g1.globo.com/...&#10;Título da matéria | https://oglobo.globo.com/..."></textarea>
					</div>
				</div>
				<div class="mlclip-imp-panel mlclip-mt" data-mode="plt" hidden>
					<p class="mlclip-muted"><?php esc_html_e( 'Importa os posts que apontam para matérias de outros sites (plugin Page Links To). Os posts originais não são alterados.', 'ml-clipping-pro' ); ?></p>
				</div>
				<div class="mlclip-form-grid">
					<div class="mlclip-field">
						<label for="mlclip-imp-status"><?php esc_html_e( 'Entrar como', 'ml-clipping-pro' ); ?></label>
						<select id="mlclip-imp-status">
							<option value="publish"><?php esc_html_e( 'Aprovadas (já no site)', 'ml-clipping-pro' ); ?></option>
							<option value="pending"><?php esc_html_e( 'Na fila de revisão', 'ml-clipping-pro' ); ?></option>
						</select>
					</div>
				</div>
				<?php self::name_checks( 'mlclip_imp_names', array(), __( 'Etiquetar com os nomes', 'ml-clipping-pro' ) ); ?>
				<div class="mlclip-actions">
					<button type="button" class="mlclip-ab" data-import<?php disabled( ! $licensed ); ?>><?php esc_html_e( 'Importar', 'ml-clipping-pro' ); ?></button>
				</div>
				<div class="mlclip-progress mlclip-mt" hidden>
					<div class="mlclip-progress-bar"><span></span></div>
					<p class="mlclip-progress-text" aria-live="polite"></p>
				</div>
			</article>
			<article class="mlclip-card">
				<header class="mlclip-card-head"><h3><?php esc_html_e( 'Como funciona', 'ml-clipping-pro' ); ?></h3><p><?php esc_html_e( 'A importação não altera nem apaga a página ou os posts de origem.', 'ml-clipping-pro' ); ?></p></header>
				<ol class="mlclip-list">
					<li><?php esc_html_e( 'Escolha de onde vêm os links.', 'ml-clipping-pro' ); ?></li>
					<li><?php esc_html_e( 'O plugin abre cada matéria e preenche os dados. Matéria que saiu do ar é lida da cópia guardada no archive.org.', 'ml-clipping-pro' ); ?></li>
					<li><?php esc_html_e( 'Quando nenhuma data é encontrada, a matéria vai para a fila de revisão com o selo "Confira a data" e não é aprovada em massa.', 'ml-clipping-pro' ); ?></li>
					<li><?php esc_html_e( 'Depois de conferir, troque o conteúdo da página antiga pelo módulo "Clipping (jornal)" ou pelo shortcode [ml_clipping].', 'ml-clipping-pro' ); ?></li>
				</ol>
			</article>
		</div>
		<article class="mlclip-card mlclip-mt" id="mlclip-repair">
			<header class="mlclip-card-head"><h3><?php esc_html_e( 'Reler matérias', 'ml-clipping-pro' ); ?></h3><p><?php esc_html_e( 'Abre de novo as matérias sem foto, sem data confirmada ou com título genérico e completa o que faltar (pela página do veículo ou pela cópia do archive.org). Nada que você escreveu é trocado; links fora do ar são marcados.', 'ml-clipping-pro' ); ?></p></header>
			<label class="mlclip-check"><input type="checkbox" id="mlclip-rep-unpublish" value="1"> <span><?php esc_html_e( 'Tirar do site (voltar para a fila) as que continuarem sem data ou ficarem com título provisório', 'ml-clipping-pro' ); ?></span></label>
			<div class="mlclip-actions mlclip-mt">
				<button type="button" class="mlclip-ab" data-repair<?php disabled( ! $licensed ); ?>><?php esc_html_e( 'Reler matérias', 'ml-clipping-pro' ); ?></button>
			</div>
			<div class="mlclip-progress mlclip-mt" hidden>
				<div class="mlclip-progress-bar"><span></span></div>
				<p class="mlclip-progress-text" aria-live="polite"></p>
			</div>
		</article>
		<?php
	}

	/* ------------------------------------------------------------ Aparência */

	/**
	 * Aba Aparência.
	 */
	private static function tab_appearance(): void {
		$s = MLCLIP_Settings::all();
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" data-unsaved>
			<?php wp_nonce_field( 'mlclip_save_appearance' ); ?>
			<input type="hidden" name="action" value="mlclip_save_appearance">
			<div class="mlclip-grid-2">
				<article class="mlclip-card">
					<header class="mlclip-card-head"><h3><?php esc_html_e( 'Jornal', 'ml-clipping-pro' ); ?></h3><p><?php esc_html_e( 'Padrão para todas as páginas de clipping. Cada módulo ou shortcode pode mudar o título e as opções.', 'ml-clipping-pro' ); ?></p></header>
					<div class="mlclip-form-grid">
						<?php
						self::text( 'paper_title', __( 'Título do jornal', 'ml-clipping-pro' ), (string) $s['paper_title'], array( 'wide' => true, 'placeholder' => __( 'Ex.: Clipping Cacique de Ramos', 'ml-clipping-pro' ) ) );
						self::text( 'paper_subtitle', __( 'Linha abaixo do título', 'ml-clipping-pro' ), (string) $s['paper_subtitle'], array( 'wide' => true, 'placeholder' => __( 'Ex.: O que a imprensa diz sobre nós', 'ml-clipping-pro' ) ) );
						?>
						<div class="mlclip-field">
							<label for="mlclip-accent"><?php esc_html_e( 'Cor de destaque', 'ml-clipping-pro' ); ?></label>
							<div class="mlclip-input-row">
								<input type="color" id="mlclip-accent" class="mlclip-color" value="<?php echo esc_attr( '' !== $s['accent'] ? (string) $s['accent'] : '#8b1e24' ); ?>" data-color-for="mlclip-accent-hex">
								<input type="text" id="mlclip-accent-hex" name="mlclip[accent]" value="<?php echo esc_attr( (string) $s['accent'] ); ?>" placeholder="<?php esc_attr_e( 'vazio = cor do tema', 'ml-clipping-pro' ); ?>">
							</div>
							<p class="mlclip-field-help"><?php esc_html_e( 'Vazio: usa a cor principal do tema do site.', 'ml-clipping-pro' ); ?></p>
						</div>
						<?php
						self::select( 'columns', __( 'Colunas', 'ml-clipping-pro' ), array( '1' => '1', '2' => '2', '3' => '3', '4' => '4' ), (string) (int) $s['columns'], __( 'No celular fica sempre 1 coluna.', 'ml-clipping-pro' ) );
						self::text( 'per_page', __( 'Matérias por página', 'ml-clipping-pro' ), (string) (int) $s['per_page'], array( 'type' => 'number', 'min' => 6, 'max' => 100 ) );
						self::select(
							'group',
							__( 'Organizar por', 'ml-clipping-pro' ),
							array(
								'auto'  => __( 'Automático (mês quando há bastante matéria, senão ano)', 'ml-clipping-pro' ),
								'month' => __( 'Mês', 'ml-clipping-pro' ),
								'year'  => __( 'Ano', 'ml-clipping-pro' ),
							),
							(string) $s['group']
						);
						?>
					</div>
				</article>
				<article class="mlclip-card">
					<header class="mlclip-card-head"><h3><?php esc_html_e( 'O que mostrar', 'ml-clipping-pro' ); ?></h3><p><?php esc_html_e( 'O plugin não altera nada do tema: só o bloco do clipping usa este visual.', 'ml-clipping-pro' ); ?></p></header>
					<?php
					self::toggle( 'headline', __( 'Manchete em destaque no topo', 'ml-clipping-pro' ), '1' === $s['headline'] );
					self::toggle( 'images', __( 'Fotos das matérias', 'ml-clipping-pro' ), '1' === $s['images'] );
					self::toggle( 'excerpt', __( 'Resumo abaixo do título', 'ml-clipping-pro' ), '1' === $s['excerpt'] );
					self::toggle( 'filters', __( 'Filtros (nome, ano, veículo, tipo)', 'ml-clipping-pro' ), '1' === $s['filters'] );
					self::toggle( 'serif', __( 'Títulos com fonte de jornal (serifada)', 'ml-clipping-pro' ), '1' === $s['serif'], __( 'Desligado: usa a fonte do tema.', 'ml-clipping-pro' ) );
					self::toggle( 'new_tab', __( 'Abrir as matérias em nova aba', 'ml-clipping-pro' ), '1' === $s['new_tab'] );
					?>
				</article>
			</div>
			<div class="mlclip-sticky-actions"><button type="submit" class="mlclip-ab"><?php esc_html_e( 'Salvar aparência', 'ml-clipping-pro' ); ?></button></div>
		</form>
		<?php
	}

	/* ------------------------------------------------------------ Licença */

	/**
	 * Aba Licença.
	 *
	 * @param array<string, mixed> $lic Licença.
	 */
	private static function tab_license( array $lic ): void {
		?>
		<div class="mlclip-grid-2">
			<article class="mlclip-card">
				<header class="mlclip-card-head mlclip-card-head-row"><div><h3><?php esc_html_e( 'Licença deste site', 'ml-clipping-pro' ); ?></h3><p><?php echo esc_html( $lic['message'] ); ?></p></div><span class="mlclip-chip mlclip-chip-<?php echo esc_attr( $lic['tone'] ); ?>"><?php echo esc_html( $lic['label'] ); ?></span></header>
				<dl class="mlclip-account-data mlclip-account-data-3">
					<div><dt><?php esc_html_e( 'Plano', 'ml-clipping-pro' ); ?></dt><dd><?php echo esc_html( $lic['plan'] ); ?></dd></div>
					<div><dt><?php esc_html_e( 'Validade', 'ml-clipping-pro' ); ?></dt><dd><?php echo esc_html( '' !== $lic['expires'] ? $lic['expires'] : '—' ); ?></dd></div>
					<div><dt><?php esc_html_e( 'Chave', 'ml-clipping-pro' ); ?></dt><dd><?php echo esc_html( '' !== $lic['key_masked'] ? $lic['key_masked'] : '—' ); ?></dd></div>
				</dl>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="mlclip-license-form">
					<?php wp_nonce_field( 'mlclip_license' ); ?>
					<input type="hidden" name="action" value="mlclip_license">
					<input type="hidden" name="op" value="activate">
					<label for="mlclip-key"><?php echo esc_html( 'license' === $lic['mode'] && $lic['active'] ? __( 'Trocar a chave', 'ml-clipping-pro' ) : __( 'Chave da licença', 'ml-clipping-pro' ) ); ?></label>
					<div class="mlclip-input-row">
						<input id="mlclip-key" type="text" name="license_key" placeholder="ML-XXXXX-XXXXX-XXXXX-XXXXX" autocomplete="off" spellcheck="false">
						<button type="submit" class="mlclip-ab"><?php esc_html_e( 'Ativar licença', 'ml-clipping-pro' ); ?></button>
					</div>
				</form>
				<div class="mlclip-actions mlclip-mt">
					<?php
					if ( $lic['can_start_trial'] ) {
						self::post_button( 'mlclip_license', array( 'op' => 'trial' ), __( 'Começar teste grátis de 30 dias', 'ml-clipping-pro' ), 'mlclip-ab mlclip-ab-light' );
					}
					if ( 'none' !== $lic['mode'] ) {
						self::post_button( 'mlclip_license', array( 'op' => 'refresh' ), __( 'Conferir agora', 'ml-clipping-pro' ), 'mlclip-ab mlclip-ab-light' );
					}
					if ( 'license' === $lic['mode'] ) {
						self::post_button( 'mlclip_license', array( 'op' => 'deactivate' ), __( 'Liberar este site', 'ml-clipping-pro' ), 'mlclip-ab mlclip-ab-ghost', __( 'Liberar este site? A chave poderá ser usada em outro site.', 'ml-clipping-pro' ) );
					}
					?>
				</div>
			</article>
			<article class="mlclip-card">
				<header class="mlclip-card-head"><h3><?php esc_html_e( 'Comprar ou gerenciar', 'ml-clipping-pro' ); ?></h3><p><?php esc_html_e( 'Uma licença vale para um site. Agências podem usar o Pacote Agência (todos os plugins ML).', 'ml-clipping-pro' ); ?></p></header>
				<div class="mlclip-actions">
					<a class="mlclip-ab" href="<?php echo esc_url( $lic['buy_url'] ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Comprar licença', 'ml-clipping-pro' ); ?></a>
					<a class="mlclip-ab mlclip-ab-light" href="<?php echo esc_url( $lic['account_url'] ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Minha conta', 'ml-clipping-pro' ); ?></a>
				</div>
				<div class="mlclip-note"><?php esc_html_e( 'Sem licença, o clipping continua aparecendo normalmente no site e nada é apagado. A busca automática pausa e o painel não grava.', 'ml-clipping-pro' ); ?></div>
			</article>
		</div>
		<?php
	}
}
