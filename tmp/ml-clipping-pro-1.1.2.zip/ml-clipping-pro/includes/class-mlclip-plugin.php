<?php
/**
 * Inicialização.
 *
 * @package MLClippingPro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class MLCLIP_Plugin {

	/**
	 * Instância.
	 *
	 * @var MLCLIP_Plugin|null
	 */
	private static $instance = null;

	/**
	 * Instância única.
	 */
	public static function instance(): self {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Construtor: registra os ganchos.
	 */
	private function __construct() {
		add_action( 'init', array( $this, 'init' ), 5 );
		MLCLIP_Engine::hooks();
		MLCLIP_Links::hooks();
		MLCLIP_Notify::hooks();
		MLCLIP_Frontend::hooks();
		MLCLIP_License::hooks();
		MLCLIP_GitHub_Updater::init();
		if ( is_admin() ) {
			MLCLIP_Admin::hooks();
		}
	}

	/**
	 * init.
	 */
	public function init(): void {
		load_plugin_textdomain( 'ml-clipping-pro', false, dirname( MLCLIP_BASENAME ) . '/languages' );
		MLCLIP_Model::register();
		// Agendamentos perdidos (restauração de backup, migração): agenda de novo.
		if ( is_admin() || wp_doing_cron() ) {
			MLCLIP_Engine::ensure_scheduled();
			MLCLIP_Links::ensure_scheduled();
		}
	}

	/**
	 * Ativação: configurações padrão (sem sobrescrever) e agendamentos.
	 */
	public static function activate(): void {
		if ( false === get_option( MLCLIP_Settings::OPTION, false ) ) {
			add_option( MLCLIP_Settings::OPTION, MLCLIP_Settings::defaults(), '', false );
		}
		MLCLIP_Model::register();
		MLCLIP_Engine::reschedule();
		MLCLIP_Links::ensure_scheduled();
		update_option( 'mlclip_installed_version', MLCLIP_VERSION, false );
	}

	/**
	 * Desativação: só tira os agendamentos. Nenhum dado é apagado.
	 */
	public static function deactivate(): void {
		wp_clear_scheduled_hook( MLCLIP_Engine::HOOK );
		wp_clear_scheduled_hook( MLCLIP_Engine::HOOK_NEXT );
		wp_clear_scheduled_hook( MLCLIP_Links::HOOK_CHECK );
		wp_unschedule_hook( MLCLIP_Links::HOOK_ARCHIVE );
		wp_clear_scheduled_hook( MLCLIP_License::cron_hook() );
	}
}
