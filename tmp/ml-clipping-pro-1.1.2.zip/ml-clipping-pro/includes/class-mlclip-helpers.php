<?php
/**
 * Funções utilitárias compartilhadas.
 *
 * @package MLClippingPro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class MLCLIP_Helpers {

	/**
	 * URL do logo oficial ML.
	 */
	public static function logo_url(): string {
		return MLCLIP_URL . 'assets/images/logo-ml.png';
	}

	/**
	 * URL de uma aba do painel.
	 *
	 * @param array<string, mixed> $args Argumentos extras.
	 */
	public static function admin_url( string $tab = 'dashboard', array $args = array() ): string {
		$args = array_merge( array( 'page' => 'ml-clipping-pro', 'tab' => $tab ), $args );
		return add_query_arg( $args, admin_url( 'admin.php' ) );
	}

	/**
	 * Cor hexadecimal ou vazio.
	 *
	 * @param mixed $value Valor.
	 */
	public static function color( $value ): string {
		$value = trim( (string) $value );
		return preg_match( '/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/', $value ) ? strtolower( $value ) : '';
	}

	/**
	 * Inteiro dentro de um intervalo.
	 *
	 * @param mixed $value Valor.
	 */
	public static function int_range( $value, int $min, int $max, int $default ): int {
		if ( ! is_numeric( $value ) ) {
			return $default;
		}
		return max( $min, min( $max, (int) $value ) );
	}

	/**
	 * Valor dentro de uma lista permitida.
	 *
	 * @param mixed              $value   Valor.
	 * @param array<int, string> $allowed Permitidos.
	 */
	public static function choice( $value, array $allowed, string $default ): string {
		$value = sanitize_key( (string) $value );
		return in_array( $value, $allowed, true ) ? $value : $default;
	}

	/**
	 * Lista de palavras a partir de texto (uma por linha ou separadas por vírgula).
	 *
	 * @param mixed $value Texto ou lista.
	 * @return array<int, string>
	 */
	public static function words( $value ): array {
		$list = is_array( $value ) ? $value : preg_split( '/[\r\n,;]+/', (string) $value );
		$out  = array();
		foreach ( (array) $list as $item ) {
			$item = trim( sanitize_text_field( (string) $item ), " \t\"'" );
			if ( '' !== $item && ! in_array( $item, $out, true ) ) {
				$out[] = $item;
			}
		}
		return array_slice( $out, 0, 50 );
	}

	/**
	 * Lista de e-mails válidos.
	 *
	 * @param mixed $value Texto.
	 * @return array<int, string>
	 */
	public static function emails( $value ): array {
		$out = array();
		foreach ( preg_split( '/[\s,;]+/', (string) $value ) as $item ) {
			$item = sanitize_email( $item );
			if ( '' !== $item && is_email( $item ) && ! in_array( $item, $out, true ) ) {
				$out[] = $item;
			}
		}
		return array_slice( $out, 0, 20 );
	}

	/**
	 * Lista de domínios (veículos) normalizados: "g1.globo.com".
	 *
	 * @param mixed $value Texto.
	 * @return array<int, string>
	 */
	public static function domains( $value ): array {
		$out = array();
		foreach ( preg_split( '/[\s,;]+/', (string) $value ) as $item ) {
			$item = self::host( $item );
			if ( '' !== $item && ! in_array( $item, $out, true ) ) {
				$out[] = $item;
			}
		}
		return array_slice( $out, 0, 200 );
	}

	/**
	 * Link http(s) bem formado (sem consultar DNS; a proteção contra endereços internos fica
	 * no wp_safe_remote_get, na hora de abrir o link).
	 *
	 * @param mixed $url Link.
	 */
	public static function is_url( $url ): bool {
		$url = trim( (string) $url );
		if ( '' === $url || strlen( $url ) > 2048 || ! preg_match( '#^https?://#i', $url ) ) {
			return false;
		}
		$host = (string) wp_parse_url( $url, PHP_URL_HOST );
		return '' !== $host && false !== strpos( $host, '.' ) && (bool) preg_match( '/^[a-z0-9.-]+$/i', $host ) && false !== filter_var( $url, FILTER_VALIDATE_URL );
	}

	/**
	 * Host sem "www." a partir de URL ou domínio.
	 */
	public static function host( string $value ): string {
		$value = strtolower( trim( $value ) );
		if ( '' === $value ) {
			return '';
		}
		if ( false === strpos( $value, '://' ) ) {
			$value = 'http://' . $value;
		}
		$host = (string) wp_parse_url( $value, PHP_URL_HOST );
		$host = preg_replace( '/^www\./', '', $host );
		return preg_match( '/^[a-z0-9.-]+\.[a-z]{2,}$/', (string) $host ) ? (string) $host : '';
	}

	/**
	 * Confere se um host pertence a um domínio da lista (inclui subdomínios).
	 *
	 * @param array<int, string> $list Domínios.
	 */
	public static function host_in( string $host, array $list ): bool {
		foreach ( $list as $domain ) {
			if ( $host === $domain || ( strlen( $host ) > strlen( $domain ) && substr( $host, -strlen( '.' . $domain ) ) === '.' . $domain ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * URL normalizada para comparação (sem esquema, www, barra final e parâmetros de rastreio).
	 */
	public static function url_key( string $url ): string {
		$parts = wp_parse_url( trim( $url ) );
		if ( empty( $parts['host'] ) ) {
			return '';
		}
		$host = preg_replace( '/^(www|m|amp)\./', '', strtolower( $parts['host'] ) );
		$path = isset( $parts['path'] ) ? rtrim( $parts['path'], '/' ) : '';
		$path = preg_replace( '#/amp$#', '', $path );
		$query = '';
		if ( ! empty( $parts['query'] ) ) {
			parse_str( $parts['query'], $q );
			foreach ( array_keys( $q ) as $k ) {
				if ( preg_match( '/^(utm_[a-z_]+|fbclid|gclid|oc|ocid|ref|cmpid|origin|amp|s)$/i', (string) $k ) ) {
					unset( $q[ $k ] );
				}
			}
			ksort( $q );
			$query = $q ? '?' . http_build_query( $q ) : '';
		}
		return $host . $path . $query;
	}

	/**
	 * Texto comparável: minúsculo, sem acentos e sem pontuação.
	 */
	public static function fold( string $text ): string {
		$text = html_entity_decode( wp_strip_all_tags( $text ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );
		$text = remove_accents( $text );
		$text = function_exists( 'mb_strtolower' ) ? mb_strtolower( $text, 'UTF-8' ) : strtolower( $text );
		$text = preg_replace( '/[^a-z0-9]+/u', ' ', $text );
		return trim( (string) preg_replace( '/\s+/', ' ', (string) $text ) );
	}

	/**
	 * A expressão aparece no texto (comparação sem acento e por palavra inteira)?
	 */
	public static function contains( string $haystack_folded, string $needle ): bool {
		$needle = self::fold( $needle );
		if ( '' === $needle || '' === $haystack_folded ) {
			return false;
		}
		return false !== strpos( ' ' . $haystack_folded . ' ', ' ' . $needle . ' ' );
	}

	/**
	 * Corta texto em N caracteres sem quebrar palavra.
	 */
	public static function excerpt( string $text, int $max = 280 ): string {
		$text = trim( preg_replace( '/\s+/u', ' ', html_entity_decode( wp_strip_all_tags( $text ), ENT_QUOTES | ENT_HTML5, 'UTF-8' ) ) );
		if ( function_exists( 'mb_strlen' ) && mb_strlen( $text, 'UTF-8' ) > $max ) {
			$cut  = mb_substr( $text, 0, $max, 'UTF-8' );
			$last = mb_strrpos( $cut, ' ', 0, 'UTF-8' );
			return rtrim( false !== $last && $last > $max * 0.6 ? mb_substr( $cut, 0, $last, 'UTF-8' ) : $cut, " ,.;:-" ) . '…';
		}
		return $text;
	}

	/**
	 * Data/hora em timestamp a partir dos formatos comuns das fontes. 0 = inválida.
	 */
	public static function timestamp( string $value ): int {
		$value = trim( $value );
		if ( '' === $value ) {
			return 0;
		}
		// GDELT: 20261104T120000Z.
		if ( preg_match( '/^(\d{4})(\d{2})(\d{2})T(\d{2})(\d{2})(\d{2})Z$/', $value, $m ) ) {
			$value = "{$m[1]}-{$m[2]}-{$m[3]}T{$m[4]}:{$m[5]}:{$m[6]}Z";
		}
		$ts = strtotime( $value );
		if ( ! $ts || $ts < 631152000 || $ts > time() + DAY_IN_SECONDS ) {
			return 0; // Antes de 1990 ou no futuro: data errada da fonte.
		}
		return (int) $ts;
	}

	/**
	 * Data para exibição (formato do site).
	 */
	public static function show_date( int $ts ): string {
		return $ts ? wp_date( get_option( 'date_format', 'd/m/Y' ), $ts ) : '';
	}

	/**
	 * Data e hora para exibição.
	 */
	public static function show_datetime( int $ts ): string {
		return $ts ? wp_date( get_option( 'date_format', 'd/m/Y' ) . ' ' . get_option( 'time_format', 'H:i' ), $ts ) : '—';
	}

	/**
	 * Nome do veículo a partir do host ("g1.globo.com" → "G1", "odia.ig.com.br" → "Odia").
	 */
	public static function outlet_from_host( string $host ): string {
		$known = array(
			'g1.globo.com'          => 'G1',
			'oglobo.globo.com'      => 'O Globo',
			'ge.globo.com'          => 'ge',
			'globoplay.globo.com'   => 'Globoplay',
			'extra.globo.com'       => 'Extra',
			'odia.ig.com.br'        => 'O Dia',
			'folha.uol.com.br'      => 'Folha de S.Paulo',
			'www1.folha.uol.com.br' => 'Folha de S.Paulo',
			'estadao.com.br'        => 'Estadão',
			'uol.com.br'            => 'UOL',
			'terra.com.br'          => 'Terra',
			'cnnbrasil.com.br'      => 'CNN Brasil',
			'band.uol.com.br'       => 'Band',
			'r7.com'                => 'R7',
			'metropoles.com'        => 'Metrópoles',
			'diariodorio.com'       => 'Diário do Rio',
			'veja.abril.com.br'     => 'Veja',
			'youtube.com'           => 'YouTube',
		);
		$host = preg_replace( '/^www\./', '', strtolower( $host ) );
		if ( isset( $known[ $host ] ) ) {
			return $known[ $host ];
		}
		foreach ( $known as $domain => $name ) {
			if ( substr( $host, -strlen( '.' . $domain ) ) === '.' . $domain ) {
				return $name;
			}
		}
		$parts = explode( '.', $host );
		$name  = $parts[0];
		if ( in_array( $name, array( 'm', 'amp', 'noticias', 'news', 'blog', 'blogs' ), true ) && isset( $parts[1] ) ) {
			$name = $parts[1];
		}
		return ucfirst( str_replace( '-', ' ', $name ) );
	}

	/**
	 * Ano/mês "2026-11" de um timestamp.
	 */
	public static function month_key( int $ts ): string {
		return wp_date( 'Y-m', $ts );
	}
}
