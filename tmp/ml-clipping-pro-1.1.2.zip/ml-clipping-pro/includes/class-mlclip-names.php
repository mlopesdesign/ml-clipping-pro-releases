<?php
/**
 * Nomes monitorados (lista sem limite). Cada nome é um termo da taxonomia mlclip_nome;
 * a configuração da busca fica nos metadados do termo. O slug do termo é a etiqueta
 * usada no site: [ml_clipping nomes="cacique-de-ramos"].
 *
 * @package MLClippingPro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class MLCLIP_Names {

	/**
	 * Regras de entrada.
	 *
	 * @return array<string, string>
	 */
	public static function rules(): array {
		return array(
			'title'         => __( 'Só quando o nome está no título', 'ml-clipping-pro' ),
			'title_summary' => __( 'Nome no título ou no resumo (recomendado)', 'ml-clipping-pro' ),
			'any'           => __( 'Qualquer citação no texto', 'ml-clipping-pro' ),
		);
	}

	/**
	 * Idiomas/países de busca.
	 *
	 * @return array<string, string>
	 */
	public static function regions(): array {
		return array(
			'pt-BR' => __( 'Português · Brasil', 'ml-clipping-pro' ),
			'pt-PT' => __( 'Português · Portugal', 'ml-clipping-pro' ),
			'en-US' => __( 'Inglês · Estados Unidos', 'ml-clipping-pro' ),
			'es-ES' => __( 'Espanhol · Espanha', 'ml-clipping-pro' ),
			'es-AR' => __( 'Espanhol · Argentina', 'ml-clipping-pro' ),
		);
	}

	/**
	 * Valores padrão de um nome.
	 *
	 * @return array<string, mixed>
	 */
	public static function defaults(): array {
		return array(
			'id'       => 0,
			'name'     => '',
			'slug'     => '',
			'aliases'  => array(),
			'required' => array(),
			'exclude'  => array(),
			'region'   => 'pt-BR',
			'rule'     => 'title_summary',
			'active'   => true,
			'last_run' => 0,
			'last_new' => 0,
		);
	}

	/**
	 * Todos os nomes.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public static function all( bool $only_active = false ): array {
		$terms = get_terms(
			array(
				'taxonomy'   => MLCLIP_Model::TAX,
				'hide_empty' => false,
				'orderby'    => 'name',
			)
		);
		if ( is_wp_error( $terms ) ) {
			return array();
		}
		$out = array();
		foreach ( $terms as $term ) {
			$n = self::from_term( $term );
			if ( ! $only_active || $n['active'] ) {
				$out[] = $n;
			}
		}
		return $out;
	}

	/**
	 * Um nome.
	 *
	 * @return array<string, mixed>|null
	 */
	public static function get( int $id ): ?array {
		$term = get_term( $id, MLCLIP_Model::TAX );
		return ( $term && ! is_wp_error( $term ) ) ? self::from_term( $term ) : null;
	}

	/**
	 * Termo → configuração.
	 *
	 * @return array<string, mixed>
	 */
	private static function from_term( \WP_Term $term ): array {
		$n             = self::defaults();
		$n['id']       = (int) $term->term_id;
		$n['name']     = (string) $term->name;
		$n['slug']     = (string) $term->slug;
		$n['aliases']  = array_values( array_filter( (array) get_term_meta( $term->term_id, '_mlclip_aliases', true ) ) );
		$n['required'] = array_values( array_filter( (array) get_term_meta( $term->term_id, '_mlclip_required', true ) ) );
		$n['exclude']  = array_values( array_filter( (array) get_term_meta( $term->term_id, '_mlclip_exclude', true ) ) );
		$region        = (string) get_term_meta( $term->term_id, '_mlclip_region', true );
		$n['region']   = isset( self::regions()[ $region ] ) ? $region : 'pt-BR';
		$rule          = (string) get_term_meta( $term->term_id, '_mlclip_rule', true );
		$n['rule']     = isset( self::rules()[ $rule ] ) ? $rule : 'title_summary';
		$n['active']   = '0' !== (string) get_term_meta( $term->term_id, '_mlclip_active', true );
		$n['last_run'] = (int) get_term_meta( $term->term_id, '_mlclip_last_run', true );
		$n['last_new'] = (int) get_term_meta( $term->term_id, '_mlclip_last_new', true );
		return $n;
	}

	/**
	 * Cria ou atualiza um nome.
	 *
	 * @param array<string, mixed> $in Entrada.
	 * @return int|\WP_Error
	 */
	public static function save( array $in, int $id = 0 ) {
		$name = trim( sanitize_text_field( (string) ( $in['name'] ?? '' ) ), " \t\"'" );
		if ( '' === $name ) {
			return new \WP_Error( 'mlclip_name', __( 'Informe o nome a monitorar.', 'ml-clipping-pro' ) );
		}
		$slug = sanitize_title( (string) ( $in['slug'] ?? '' ) );
		$args = array( 'slug' => '' !== $slug ? $slug : sanitize_title( $name ) );
		if ( $id ) {
			$args['name'] = $name;
			$res          = wp_update_term( $id, MLCLIP_Model::TAX, $args );
		} else {
			$res = wp_insert_term( $name, MLCLIP_Model::TAX, $args );
		}
		if ( is_wp_error( $res ) ) {
			if ( 'term_exists' === $res->get_error_code() ) {
				return new \WP_Error( 'mlclip_name_dup', __( 'Esse nome (ou essa etiqueta) já está na lista.', 'ml-clipping-pro' ) );
			}
			return $res;
		}
		$tid = (int) $res['term_id'];
		update_term_meta( $tid, '_mlclip_aliases', MLCLIP_Helpers::words( $in['aliases'] ?? '' ) );
		update_term_meta( $tid, '_mlclip_required', MLCLIP_Helpers::words( $in['required'] ?? '' ) );
		update_term_meta( $tid, '_mlclip_exclude', MLCLIP_Helpers::words( $in['exclude'] ?? '' ) );
		update_term_meta( $tid, '_mlclip_region', isset( self::regions()[ (string) ( $in['region'] ?? '' ) ] ) ? (string) $in['region'] : 'pt-BR' );
		update_term_meta( $tid, '_mlclip_rule', isset( self::rules()[ (string) ( $in['rule'] ?? '' ) ] ) ? (string) $in['rule'] : 'title_summary' );
		update_term_meta( $tid, '_mlclip_active', empty( $in['active'] ) ? '0' : '1' );
		return $tid;
	}

	/**
	 * Liga ou pausa um nome.
	 */
	public static function toggle( int $id ): bool {
		$n = self::get( $id );
		if ( ! $n ) {
			return false;
		}
		update_term_meta( $id, '_mlclip_active', $n['active'] ? '0' : '1' );
		return true;
	}

	/**
	 * Remove o nome da lista. As matérias continuam no clipping (só perdem a etiqueta).
	 */
	public static function delete( int $id ): bool {
		$res = wp_delete_term( $id, MLCLIP_Model::TAX );
		return true === $res;
	}

	/**
	 * Registra a última busca completa do nome (define a janela da próxima).
	 */
	public static function mark_run( int $id ): void {
		update_term_meta( $id, '_mlclip_last_run', time() );
	}

	/**
	 * Quantas matérias novas a última rodada trouxe para o nome.
	 */
	public static function mark_new( int $id, int $new ): void {
		update_term_meta( $id, '_mlclip_last_new', $new );
	}

	/**
	 * Todas as formas do nome (principal + variações).
	 *
	 * @param array<string, mixed> $n Nome.
	 * @return array<int, string>
	 */
	public static function forms( array $n ): array {
		return array_values( array_unique( array_filter( array_merge( array( (string) $n['name'] ), (array) $n['aliases'] ) ) ) );
	}
}
