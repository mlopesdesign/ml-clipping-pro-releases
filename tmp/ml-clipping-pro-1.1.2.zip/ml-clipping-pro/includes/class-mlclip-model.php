<?php
/**
 * Matérias do clipping: tipo de post próprio (backup normal do site), sem página própria
 * no site (o link leva para o veículo).
 *
 * Situações:
 * - pending          → Aguardando revisão (fila);
 * - publish          → Aprovada (aparece no site);
 * - mlclip_discard   → Descartada (nunca apagada; dá para recuperar).
 *
 * A data do post é a data de publicação da matéria no veículo.
 *
 * @package MLClippingPro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class MLCLIP_Model {

	public const TYPE    = 'mlclip_item';
	public const TAX     = 'mlclip_nome';
	public const DISCARD = 'mlclip_discard';

	/**
	 * Campos (meta) de cada matéria.
	 *
	 * @return array<string, string>
	 */
	public static function fields(): array {
		return array(
			'url'          => '_mlclip_url',
			'url_key'      => '_mlclip_url_key',
			'title_key'    => '_mlclip_title_key',
			'outlet'       => '_mlclip_outlet',
			'host'         => '_mlclip_host',
			'image'        => '_mlclip_image',
			'score'        => '_mlclip_score',
			'origin'       => '_mlclip_origin',
			'media'        => '_mlclip_media',
			'featured'     => '_mlclip_featured',
			'found_at'     => '_mlclip_found_at',
			'link_status'  => '_mlclip_link_status',
			'link_checked' => '_mlclip_link_checked',
			'archive_url'  => '_mlclip_archive_url',
			'reasons'      => '_mlclip_reasons',
		);
	}

	/**
	 * Registra tipo, taxonomia e situação "Descartada".
	 */
	public static function register(): void {
		register_post_type(
			self::TYPE,
			array(
				'labels'              => array(
					'name'          => __( 'Matérias do clipping', 'ml-clipping-pro' ),
					'singular_name' => __( 'Matéria do clipping', 'ml-clipping-pro' ),
				),
				'public'              => false,
				'publicly_queryable'  => false,
				'exclude_from_search' => true,
				'show_ui'             => false,
				'show_in_rest'        => false,
				'has_archive'         => false,
				'rewrite'             => false,
				'query_var'           => false,
				'supports'            => array( 'title', 'excerpt' ),
				'capability_type'     => 'post',
				'map_meta_cap'        => true,
			)
		);
		register_taxonomy(
			self::TAX,
			self::TYPE,
			array(
				'labels'            => array(
					'name'          => __( 'Nomes monitorados', 'ml-clipping-pro' ),
					'singular_name' => __( 'Nome monitorado', 'ml-clipping-pro' ),
				),
				'public'            => false,
				'show_ui'           => false,
				'show_in_rest'      => false,
				'hierarchical'      => false,
				'rewrite'           => false,
				'query_var'         => false,
				'show_admin_column' => false,
			)
		);
		register_post_status(
			self::DISCARD,
			array(
				'label'                     => __( 'Descartada', 'ml-clipping-pro' ),
				'public'                    => false,
				'internal'                  => false,
				'protected'                 => true,
				'exclude_from_search'       => true,
				'show_in_admin_all_list'    => false,
				'show_in_admin_status_list' => false,
			)
		);
	}

	/**
	 * Lê uma matéria em formato simples.
	 *
	 * @param int|\WP_Post $post Post.
	 * @return array<string, mixed>|null
	 */
	public static function get( $post ): ?array {
		$post = get_post( $post );
		if ( ! $post || self::TYPE !== $post->post_type ) {
			return null;
		}
		$out = array(
			'id'      => (int) $post->ID,
			'title'   => (string) $post->post_title,
			'excerpt' => (string) $post->post_excerpt,
			'status'  => (string) $post->post_status,
			'date'    => (int) get_post_time( 'U', true, $post ),
		);
		foreach ( self::fields() as $key => $meta ) {
			$out[ $key ] = get_post_meta( $post->ID, $meta, true );
		}
		$out['score']    = (int) $out['score'];
		$out['featured'] = '1' === (string) $out['featured'];
		$out['media']    = 'video' === $out['media'] ? 'video' : 'texto';
		$out['names']    = wp_get_object_terms( $post->ID, self::TAX, array( 'fields' => 'id=>name' ) );
		if ( is_wp_error( $out['names'] ) ) {
			$out['names'] = array();
		}
		return $out;
	}

	/**
	 * Já existe matéria com este link (ou mesmo título no mesmo veículo)?
	 */
	public static function forget( int $id ): void {
		// Excluída pelo administrador: a busca nunca mais traz (endereço e título ficam numa lista leve).
		$keys = array_filter( array( (string) get_post_meta( $id, '_mlclip_url_key', true ), (string) get_post_meta( $id, '_mlclip_title_key', true ) ) );
		$list = (array) get_option( 'mlclip_deleted', array() );
		foreach ( $keys as $k ) {
			$list[ md5( $k ) ] = time();
		}
		if ( count( $list ) > 5000 ) {
			asort( $list );
			$list = array_slice( $list, -5000, null, true );
		}
		update_option( 'mlclip_deleted', $list, false );
		wp_delete_post( $id, true );
	}

	/**
	 * Matéria excluída pelo administrador (a busca não traz de volta).
	 */
	public static function deleted( string $url_key, string $title_key = '' ): bool {
		$list = (array) get_option( 'mlclip_deleted', array() );
		return ( '' !== $url_key && isset( $list[ md5( $url_key ) ] ) ) || ( '' !== $title_key && isset( $list[ md5( $title_key ) ] ) );
	}

	/**
	 * Já existe matéria com este endereço ou título?
	 */
	public static function exists( string $url_key, string $title_key = '' ): int {
		global $wpdb;
		if ( '' !== $url_key ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$id = (int) $wpdb->get_var(
				$wpdb->prepare(
					"SELECT pm.post_id FROM {$wpdb->postmeta} pm INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id WHERE pm.meta_key = %s AND pm.meta_value = %s AND p.post_type = %s LIMIT 1",
					'_mlclip_url_key',
					$url_key,
					self::TYPE
				)
			);
			if ( $id ) {
				return $id;
			}
		}
		if ( '' !== $title_key ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$id = (int) $wpdb->get_var(
				$wpdb->prepare(
					"SELECT pm.post_id FROM {$wpdb->postmeta} pm INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id WHERE pm.meta_key = %s AND pm.meta_value = %s AND p.post_type = %s LIMIT 1",
					'_mlclip_title_key',
					$title_key,
					self::TYPE
				)
			);
			if ( $id ) {
				return $id;
			}
		}
		return 0;
	}

	/**
	 * Chave de título para não repetir a mesma matéria vinda de fontes diferentes.
	 */
	public static function title_key( string $title, string $host ): string {
		$t = MLCLIP_Helpers::fold( $title );
		return '' === $t ? '' : md5( $t . '|' . preg_replace( '/^www\./', '', strtolower( $host ) ) );
	}

	/**
	 * Cria ou atualiza uma matéria.
	 *
	 * @param array<string, mixed> $d  Dados (title, url, excerpt, outlet, image, date, score, origin, media, featured, status, names).
	 * @param int                  $id Atualizar este post (0 = novo).
	 * @return int|\WP_Error
	 */
	public static function save( array $d, int $id = 0 ) {
		$url = esc_url_raw( (string) ( $d['url'] ?? '' ) );
		if ( '' === $url || ! MLCLIP_Helpers::is_url( $url ) ) {
			return new \WP_Error( 'mlclip_url', __( 'Informe um link válido da matéria (começando com http).', 'ml-clipping-pro' ) );
		}
		$title = sanitize_text_field( (string) ( $d['title'] ?? '' ) );
		if ( '' === $title ) {
			return new \WP_Error( 'mlclip_title', __( 'Informe o título da matéria.', 'ml-clipping-pro' ) );
		}
		$host    = MLCLIP_Helpers::host( $url );
		$url_key = MLCLIP_Helpers::url_key( $url );
		$dup     = self::exists( $url_key );
		if ( $dup && $dup !== $id ) {
			return new \WP_Error( 'mlclip_dup', __( 'Essa matéria já está no clipping.', 'ml-clipping-pro' ), array( 'id' => $dup ) );
		}

		$ts     = isset( $d['date'] ) ? (int) $d['date'] : 0;
		// Nunca no futuro (senão o WordPress agenda em vez de publicar e a matéria some das listas).
		$ts     = $ts > 0 ? min( $ts, time() ) : time();
		$status = in_array( (string) ( $d['status'] ?? 'pending' ), array( 'pending', 'publish', self::DISCARD ), true ) ? (string) $d['status'] : 'pending';

		$postarr = array(
			'post_type'     => self::TYPE,
			'post_title'    => $title,
			'post_excerpt'  => sanitize_textarea_field( (string) ( $d['excerpt'] ?? '' ) ),
			'post_status'   => $status,
			'post_date'     => wp_date( 'Y-m-d H:i:s', $ts ),
			'post_date_gmt' => gmdate( 'Y-m-d H:i:s', $ts ),
			'post_content'  => '',
		);
		if ( $id ) {
			$postarr['ID'] = $id;
			$res           = wp_update_post( wp_slash( $postarr ), true );
		} else {
			$res = wp_insert_post( wp_slash( $postarr ), true );
		}
		if ( is_wp_error( $res ) ) {
			return $res;
		}
		$pid    = (int) $res;
		$outlet = sanitize_text_field( (string) ( $d['outlet'] ?? '' ) );
		$meta   = array(
			'url'       => $url,
			'url_key'   => $url_key,
			'title_key' => self::title_key( $title, $host ),
			'outlet'    => '' !== $outlet ? $outlet : MLCLIP_Helpers::outlet_from_host( $host ),
			'host'      => $host,
			'image'     => esc_url_raw( (string) ( $d['image'] ?? '' ) ),
			'media'     => 'video' === ( $d['media'] ?? '' ) ? 'video' : 'texto',
			'featured'  => empty( $d['featured'] ) ? '0' : '1',
		);
		if ( isset( $d['score'] ) ) {
			$meta['score'] = (string) max( 0, min( 100, (int) $d['score'] ) );
		}
		if ( isset( $d['origin'] ) ) {
			$meta['origin'] = sanitize_key( (string) $d['origin'] );
		}
		if ( isset( $d['reasons'] ) ) {
			$meta['reasons'] = sanitize_text_field( (string) $d['reasons'] );
		}
		if ( ! empty( $d['link'] ) && 'down' === $d['link'] ) {
			$meta['link_status'] = 'down';
		}
		if ( ! empty( $d['archive'] ) && MLCLIP_Helpers::is_url( (string) $d['archive'] ) ) {
			$meta['archive_url'] = esc_url_raw( (string) $d['archive'] );
		}
		if ( ! $id ) {
			$meta['found_at'] = (string) time();
		}
		$fields = self::fields();
		foreach ( $meta as $key => $value ) {
			update_post_meta( $pid, $fields[ $key ], $value );
		}
		if ( isset( $d['names'] ) ) {
			wp_set_object_terms( $pid, array_map( 'absint', (array) $d['names'] ), self::TAX, false );
		}
		return $pid;
	}

	/**
	 * Muda a situação (aprovar, descartar, voltar para a fila).
	 */
	public static function set_status( int $id, string $status ): bool {
		if ( self::TYPE !== get_post_type( $id ) || ! in_array( $status, array( 'pending', 'publish', self::DISCARD ), true ) ) {
			return false;
		}
		$args = array(
			'ID'          => $id,
			'post_status' => $status,
		);
		$gmt = (string) get_post_field( 'post_date_gmt', $id );
		if ( 'publish' === $status && '' !== $gmt && strtotime( $gmt . ' UTC' ) > time() ) {
			$args['post_date']     = current_time( 'mysql' );
			$args['post_date_gmt'] = current_time( 'mysql', true );
		}
		$res = wp_update_post( $args, true );
		return ! is_wp_error( $res );
	}

	/**
	 * Contagem por situação (opcionalmente de um nome).
	 *
	 * @return array<string, int>
	 */
	public static function counts( int $name = 0 ): array {
		$out = array();
		foreach ( array( 'pending', 'publish', self::DISCARD ) as $status ) {
			$args = array(
				'post_type'      => self::TYPE,
				'post_status'    => $status,
				'posts_per_page' => 1,
				'fields'         => 'ids',
			);
			if ( $name ) {
				$args['tax_query'] = array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
					array(
						'taxonomy' => self::TAX,
						'field'    => 'term_id',
						'terms'    => $name,
					),
				);
			}
			$q              = new \WP_Query( $args );
			$out[ $status ] = (int) $q->found_posts;
		}
		$down = new \WP_Query(
			array(
				'post_type'      => self::TYPE,
				'post_status'    => 'publish',
				'posts_per_page' => 1,
				'fields'         => 'ids',
				'meta_key'       => '_mlclip_link_status', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
				'meta_value'     => 'down', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
			)
		);
		$out['down'] = (int) $down->found_posts;
		return $out;
	}

	/**
	 * Total na fila (rápido, para o contador do menu e da barra).
	 */
	public static function pending_count(): int {
		$c = wp_count_posts( self::TYPE );
		return isset( $c->pending ) ? (int) $c->pending : 0;
	}

	/**
	 * Faixa de nota: alta, media ou baixa.
	 */
	public static function band( int $score ): string {
		if ( $score >= 60 ) {
			return 'alta';
		}
		return $score >= 35 ? 'media' : 'baixa';
	}

	/**
	 * Rótulo da faixa.
	 */
	public static function band_label( int $score ): string {
		$labels = array(
			'alta'  => __( 'Alta', 'ml-clipping-pro' ),
			'media' => __( 'Média', 'ml-clipping-pro' ),
			'baixa' => __( 'Baixa', 'ml-clipping-pro' ),
		);
		return $labels[ self::band( $score ) ];
	}
}
