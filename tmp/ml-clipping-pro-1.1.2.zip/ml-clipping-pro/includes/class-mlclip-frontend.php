<?php
/**
 * Site: shortcode [ml_clipping], bloco do editor, bloco do ML Builder e "Carregar mais".
 * CSS/JS só carregam nas páginas que mostram o clipping. Nada do tema é alterado.
 *
 * @package MLClippingPro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class MLCLIP_Frontend {

	/**
	 * Ganchos.
	 */
	public static function hooks(): void {
		add_action( 'init', array( __CLASS__, 'register' ), 20 );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'maybe_enqueue' ) );
		add_action( 'wp_ajax_mlclip_more', array( __CLASS__, 'ajax_more' ) );
		add_action( 'wp_ajax_nopriv_mlclip_more', array( __CLASS__, 'ajax_more' ) );
		add_filter( 'mlbp_integrations_registry', array( __CLASS__, 'ml_builder' ) );
		foreach ( array( 'save_post_' . MLCLIP_Model::TYPE, 'deleted_post', 'set_object_terms' ) as $hook ) {
			add_action( $hook, array( __CLASS__, 'flush' ) );
		}
		add_action( 'transition_post_status', array( __CLASS__, 'flush_status' ), 10, 3 );
	}

	/**
	 * Shortcode, estilos e bloco.
	 */
	public static function register(): void {
		add_shortcode( 'ml_clipping', array( __CLASS__, 'shortcode' ) );
		wp_register_style( 'mlclip-front', MLCLIP_URL . 'assets/css/front.css', array(), MLCLIP_VERSION );
		wp_register_script( 'mlclip-front', MLCLIP_URL . 'assets/js/front.js', array(), MLCLIP_VERSION, true );
		wp_localize_script(
			'mlclip-front',
			'MLCLIP_FRONT',
			array(
				'ajax'    => admin_url( 'admin-ajax.php' ),
				'loading' => __( 'Carregando…', 'ml-clipping-pro' ),
				'more'    => __( 'Carregar mais matérias', 'ml-clipping-pro' ),
				'error'   => __( 'Não foi possível carregar. Tente de novo.', 'ml-clipping-pro' ),
			)
		);

		if ( ! function_exists( 'register_block_type' ) ) {
			return;
		}
		wp_register_script(
			'mlclip-block',
			MLCLIP_URL . 'assets/js/block.js',
			array( 'wp-blocks', 'wp-element', 'wp-components', 'wp-block-editor', 'wp-server-side-render', 'wp-i18n' ),
			MLCLIP_VERSION,
			true
		);
		add_action( 'enqueue_block_editor_assets', array( __CLASS__, 'block_data' ) );
		register_block_type(
			'ml-clipping-pro/clipping',
			array(
				'api_version'     => 2,
				'editor_script'   => 'mlclip-block',
				'editor_style'    => 'mlclip-front',
				'style'           => 'mlclip-front',
				'render_callback' => array( __CLASS__, 'render_block' ),
				'attributes'      => array(
					'nomes'      => array( 'type' => 'string', 'default' => '' ),
					'titulo'     => array( 'type' => 'string', 'default' => '' ),
					'subtitulo'  => array( 'type' => 'string', 'default' => '' ),
					'colunas'    => array( 'type' => 'number', 'default' => 0 ),
					'por_pagina' => array( 'type' => 'number', 'default' => 0 ),
					'agrupar'    => array( 'type' => 'string', 'default' => '' ),
					'filtros'    => array( 'type' => 'string', 'default' => '' ),
					'manchete'   => array( 'type' => 'string', 'default' => '' ),
					'imagens'    => array( 'type' => 'string', 'default' => '' ),
					'resumo'     => array( 'type' => 'string', 'default' => '' ),
					'cabecalho'  => array( 'type' => 'string', 'default' => '' ),
				),
			)
		);
	}

	/**
	 * Lista dos nomes para o bloco do editor.
	 */
	public static function block_data(): void {
		$names = array();
		foreach ( MLCLIP_Names::all() as $n ) {
			$names[] = array(
				'value' => $n['slug'],
				'label' => $n['name'],
			);
		}
		wp_localize_script( 'mlclip-block', 'MLCLIP_BLOCK', array( 'names' => $names ) );
	}

	/**
	 * Carrega CSS/JS cedo quando a página tem o shortcode ou o bloco.
	 */
	public static function maybe_enqueue(): void {
		$post = get_post();
		if ( $post && ( has_shortcode( (string) $post->post_content, 'ml_clipping' ) || has_block( 'ml-clipping-pro/clipping', $post ) || false !== strpos( (string) $post->post_content, '[ml_clipping' ) ) ) {
			self::enqueue();
		}
	}

	/**
	 * CSS e JS do jornal.
	 */
	public static function enqueue(): void {
		wp_enqueue_style( 'mlclip-front' );
		wp_enqueue_script( 'mlclip-front' );
	}

	/**
	 * [ml_clipping nomes="" titulo="" subtitulo="" colunas="3" por_pagina="24" agrupar="mes|ano" filtros="sim" manchete="sim" imagens="sim" resumo="sim" cabecalho="sim" cor="#hex"].
	 *
	 * @param array<string, mixed>|string $atts Atributos.
	 */
	public static function shortcode( $atts ): string {
		self::enqueue();
		$atts = is_array( $atts ) ? $atts : array();
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- filtros públicos de leitura.
		return MLCLIP_Render::paper( $atts, $_GET );
	}

	/**
	 * Bloco do editor.
	 *
	 * @param array<string, mixed> $attrs Atributos do bloco.
	 */
	public static function render_block( $attrs ): string {
		self::enqueue();
		$atts = array();
		foreach ( (array) $attrs as $k => $v ) {
			if ( '' !== $v && 0 !== $v && null !== $v ) {
				$atts[ $k ] = $v;
			}
		}
		$editor = defined( 'REST_REQUEST' ) && REST_REQUEST;
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- filtros públicos de leitura.
		return MLCLIP_Render::paper( $atts, $editor ? array() : $_GET, $editor );
	}

	/**
	 * "Carregar mais" (leitura pública das matérias aprovadas).
	 */
	public static function ajax_more(): void {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- leitura pública, sem gravação.
		$raw  = isset( $_POST['atts'] ) ? json_decode( wp_unslash( (string) $_POST['atts'] ), true ) : array();
		$flt  = isset( $_POST['filters'] ) ? json_decode( wp_unslash( (string) $_POST['filters'] ), true ) : array();
		$page = isset( $_POST['page'] ) ? max( 2, absint( $_POST['page'] ) ) : 2;
		// phpcs:enable
		$raw = is_array( $raw ) ? array_map( 'sanitize_text_field', array_filter( $raw, 'is_scalar' ) ) : array();
		$f   = array();
		if ( is_array( $flt ) ) {
			foreach ( array( 'nome', 'ano', 'veiculo', 'tipo' ) as $k ) {
				if ( isset( $flt[ $k ] ) && is_scalar( $flt[ $k ] ) ) {
					$f[ 'mlclip_' . $k ] = (string) $flt[ $k ];
				}
			}
		}
		wp_send_json_success( MLCLIP_Render::more( $raw, $f, min( 500, $page ) ) );
	}

	/**
	 * Bloco "Clipping (jornal)" no grupo ML Blocks do ML Builder.
	 *
	 * @param array<string, mixed> $registry Registro.
	 * @return array<string, mixed>
	 */
	public static function ml_builder( $registry ) {
		$registry                    = is_array( $registry ) ? $registry : array();
		$registry['ml-clipping-pro'] = array(
			'label'  => 'ML Clipping Pro',
			'slug'   => 'ml-clipping-pro',
			'main'   => MLCLIP_BASENAME,
			'blocks' => array(
				array(
					'key'       => 'ml_clipping',
					'label'     => __( 'Clipping (jornal)', 'ml-clipping-pro' ),
					'shortcode' => '[ml_clipping]',
				),
			),
		);
		return $registry;
	}

	/**
	 * Matérias mudaram: renova o cache dos filtros.
	 */
	public static function flush( $post_id = 0 ): void {
		if ( ! $post_id || MLCLIP_Model::TYPE === get_post_type( (int) $post_id ) ) {
			MLCLIP_Render::bump_cache();
		}
	}

	/**
	 * Mudança de situação de uma matéria.
	 *
	 * @param string   $new  Nova.
	 * @param string   $old  Antiga.
	 * @param \WP_Post $post Post.
	 */
	public static function flush_status( $new, $old, $post ): void {
		if ( $new !== $old && $post && MLCLIP_Model::TYPE === $post->post_type ) {
			MLCLIP_Render::bump_cache();
		}
	}
}
