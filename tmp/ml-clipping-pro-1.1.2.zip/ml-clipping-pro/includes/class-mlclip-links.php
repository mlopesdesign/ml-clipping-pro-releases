<?php
/**
 * Manutenção dos links:
 * - cópia no Arquivo da Internet (archive.org) de cada matéria aprovada, para o clipping
 *   não perder a matéria quando o veículo apagar;
 * - verificação dos links aprovados (lotes semanais): link que saiu do ar é marcado
 *   "Fora do ar" (nunca apagado) e o site passa a usar a cópia do arquivo, se houver.
 *
 * @package MLClippingPro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class MLCLIP_Links {

	public const HOOK_CHECK   = 'mlclip_linkcheck';
	public const HOOK_ARCHIVE = 'mlclip_archive';
	private const BATCH       = 40;

	/**
	 * Ganchos.
	 */
	public static function hooks(): void {
		add_action( 'transition_post_status', array( __CLASS__, 'on_status' ), 10, 3 );
		add_action( self::HOOK_ARCHIVE, array( __CLASS__, 'archive' ) );
		add_action( self::HOOK_CHECK, array( __CLASS__, 'check_batch' ) );
	}

	/**
	 * Agenda a verificação semanal.
	 */
	public static function ensure_scheduled(): void {
		if ( ! wp_next_scheduled( self::HOOK_CHECK ) ) {
			wp_schedule_event( time() + 2 * HOUR_IN_SECONDS, 'weekly', self::HOOK_CHECK );
		}
	}

	/**
	 * Matéria aprovada: agenda a cópia no arquivo.
	 *
	 * @param string   $new  Nova situação.
	 * @param string   $old  Situação anterior.
	 * @param \WP_Post $post Post.
	 */
	public static function on_status( $new, $old, $post ): void {
		if ( 'publish' !== $new || 'publish' === $old || ! $post || MLCLIP_Model::TYPE !== $post->post_type || ! MLCLIP_Settings::on( 'archive' ) ) {
			return;
		}
		if ( '' === (string) get_post_meta( $post->ID, '_mlclip_archive_url', true ) && ! wp_next_scheduled( self::HOOK_ARCHIVE, array( (int) $post->ID ) ) ) {
			wp_schedule_single_event( time() + 30 + wp_rand( 0, 90 ), self::HOOK_ARCHIVE, array( (int) $post->ID ) );
		}
	}

	/**
	 * Procura uma cópia no archive.org; se não houver, pede para arquivar.
	 */
	public static function archive( $post_id ): void {
		$post_id = (int) $post_id;
		$url     = (string) get_post_meta( $post_id, '_mlclip_url', true );
		if ( '' === $url || MLCLIP_Model::TYPE !== get_post_type( $post_id ) ) {
			return;
		}
		$found = self::snapshot( $url );
		if ( '' !== $found ) {
			update_post_meta( $post_id, '_mlclip_archive_url', $found );
			return;
		}
		$tries = (int) get_post_meta( $post_id, '_mlclip_archive_try', true );
		if ( $tries >= 3 ) {
			return;
		}
		update_post_meta( $post_id, '_mlclip_archive_try', $tries + 1 );
		// Pedido sem esperar a resposta (o arquivo leva minutos para gravar).
		wp_safe_remote_get(
			'https://web.archive.org/save/' . $url,
			array(
				'timeout'    => 3,
				'blocking'   => false,
				'user-agent' => MLCLIP_Http::user_agent(),
			)
		);
	}

	/**
	 * Endereço da cópia mais recente no archive.org ('' = não existe).
	 */
	public static function snapshot( string $url ): string {
		$res = MLCLIP_Http::get( add_query_arg( 'url', rawurlencode( $url ), 'https://archive.org/wayback/available' ), array( 'timeout' => 12, 'headers' => array( 'Accept' => 'application/json' ) ) );
		if ( is_wp_error( $res ) || 200 !== $res[0] ) {
			return '';
		}
		$data = json_decode( $res[1], true );
		$snap = $data['archived_snapshots']['closest'] ?? null;
		if ( is_array( $snap ) && ! empty( $snap['available'] ) && ! empty( $snap['url'] ) ) {
			return esc_url_raw( str_replace( 'http://', 'https://', (string) $snap['url'] ) );
		}
		return '';
	}

	/**
	 * Confere um lote de links aprovados (os conferidos há mais tempo primeiro).
	 */
	public static function check_batch(): void {
		if ( ! MLCLIP_Settings::on( 'linkcheck' ) ) {
			return;
		}
		$ids = get_posts(
			array(
				'post_type'      => MLCLIP_Model::TYPE,
				'post_status'    => 'publish',
				'posts_per_page' => self::BATCH,
				'fields'         => 'ids',
				'no_found_rows'  => true,
				'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
					'relation' => 'OR',
					'never'    => array(
						'key'     => '_mlclip_link_checked',
						'compare' => 'NOT EXISTS',
					),
					'old'      => array(
						'key'     => '_mlclip_link_checked',
						'value'   => time() - 25 * DAY_IN_SECONDS,
						'compare' => '<',
						'type'    => 'NUMERIC',
					),
				),
				'orderby'        => 'date',
				'order'          => 'DESC',
			)
		);
		foreach ( $ids as $id ) {
			self::check_one( (int) $id );
		}
	}

	/**
	 * Confere um link. Só marca "Fora do ar" depois de 2 falhas seguidas.
	 *
	 * @return string ok, down ou unknown.
	 */
	public static function check_one( int $id ): string {
		$url = (string) get_post_meta( $id, '_mlclip_url', true );
		if ( '' === $url ) {
			return 'unknown';
		}
		$res    = MLCLIP_Http::get( $url, array( 'timeout' => 12, 'limit_response_size' => 65536 ) );
		$status = 'ok';
		if ( is_wp_error( $res ) ) {
			$status = 'fail';
		} elseif ( in_array( (int) $res[0], array( 404, 410 ), true ) ) {
			$status = 'fail';
		} elseif ( $res[0] >= 500 || 0 === $res[0] ) {
			$status = 'unknown'; // Instável: não conta como fora do ar.
		}
		update_post_meta( $id, '_mlclip_link_checked', time() );
		if ( 'fail' === $status ) {
			$fails = (int) get_post_meta( $id, '_mlclip_link_fails', true ) + 1;
			update_post_meta( $id, '_mlclip_link_fails', $fails );
			$status = $fails >= 2 ? 'down' : 'unknown';
		} elseif ( 'ok' === $status ) {
			delete_post_meta( $id, '_mlclip_link_fails' );
		}
		if ( 'unknown' !== $status || '' === (string) get_post_meta( $id, '_mlclip_link_status', true ) ) {
			update_post_meta( $id, '_mlclip_link_status', 'unknown' === $status ? 'ok' : $status );
		}
		if ( MLCLIP_Settings::on( 'archive' ) && '' === (string) get_post_meta( $id, '_mlclip_archive_url', true ) ) {
			$snap = self::snapshot( $url );
			if ( '' !== $snap ) {
				update_post_meta( $id, '_mlclip_archive_url', $snap );
			}
		}
		return $status;
	}
}
