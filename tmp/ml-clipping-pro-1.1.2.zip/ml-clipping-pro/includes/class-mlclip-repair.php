<?php
/**
 * Reler matérias: completa foto, data e título de matérias já salvas (clipping antigo,
 * links fora do ar) usando a página do veículo ou a cópia do archive.org.
 *
 * @package ML_Clipping_Pro
 */

defined( 'ABSPATH' ) || exit;

/**
 * Ferramenta de reparo em lotes (prepare + passos via AJAX).
 */
final class MLCLIP_Repair {

	/**
	 * Matérias por passo (cada uma pode abrir até 3 páginas).
	 */
	private const BATCH = 2;

	/**
	 * Marca de data não confirmada (gravada pela importação).
	 */
	private const NODATE = 'Data não encontrada';

	/**
	 * Chave do lote do usuário.
	 */
	private static function key(): string {
		return 'mlclip_repair_' . get_current_user_id();
	}

	/**
	 * Título genérico (texto do link em vez do título da matéria)?
	 */
	public static function generic_title( string $title, string $host ): bool {
		$f = MLCLIP_Helpers::fold( $title );
		if ( '' === $f || in_array( $f, array( 'array', 'null', 'undefined', 'object', 'materia', 'link', 'clique aqui', 'leia mais', 'saiba mais' ), true ) ) {
			return true;
		}
		$h = MLCLIP_Helpers::fold( preg_replace( '/^www\./', '', $host ) );
		return '' !== $h && ( $f === $h || $f === MLCLIP_Helpers::fold( MLCLIP_Helpers::outlet_from_host( $host ) ) || 0 === strpos( $f, 'http' ) );
	}

	/**
	 * Lista as matérias que precisam ser relidas.
	 *
	 * @param bool $unpublish Tirar do site as que continuarem sem data.
	 * @return array<string, mixed>
	 */
	public static function prepare( bool $unpublish ): array {
		$ids  = get_posts(
			array(
				'post_type'      => MLCLIP_Model::TYPE,
				'post_status'    => array( 'publish', 'pending' ),
				'posts_per_page' => 2000,
				'fields'         => 'ids',
				'no_found_rows'  => true,
				'orderby'        => 'ID',
				'order'          => 'ASC',
			)
		);
		$todo = array();
		foreach ( $ids as $id ) {
			$d = MLCLIP_Model::get( (int) $id );
			if ( ! $d ) {
				continue;
			}
			if ( '' === (string) $d['image'] || false !== strpos( (string) $d['reasons'], self::NODATE ) || self::generic_title( (string) $d['title'], (string) $d['host'] ) ) {
				$todo[] = (int) $id;
			}
		}
		$job = array(
			'ids'       => $todo,
			'total'     => count( $todo ),
			'done'      => 0,
			'fixed'     => 0,
			'down'      => 0,
			'nodate'    => 0,
			'unpublish' => $unpublish,
		);
		set_transient( self::key(), $job, 2 * HOUR_IN_SECONDS );
		return $job;
	}

	/**
	 * Processa o próximo lote.
	 *
	 * @return array<string, mixed>|\WP_Error
	 */
	public static function step() {
		$job = get_transient( self::key() );
		if ( ! is_array( $job ) ) {
			return new \WP_Error( 'mlclip_rep_none', __( 'Nenhuma releitura em andamento.', 'ml-clipping-pro' ) );
		}
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 150 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- alguns servidores bloqueiam.
		}
		$slice = array_slice( (array) $job['ids'], (int) $job['done'], self::BATCH );
		$t0    = microtime( true );
		foreach ( $slice as $id ) {
			if ( microtime( true ) - $t0 > 6 ) {
				break; // Servidor com tempo curto de resposta: o resto vai no próximo passo.
			}
			$job['done']++;
			$r = self::fix( (int) $id, ! empty( $job['unpublish'] ) );
			foreach ( array( 'fixed', 'down', 'nodate' ) as $k ) {
				$job[ $k ] += empty( $r[ $k ] ) ? 0 : 1;
			}
		}
		$job['finished'] = (int) $job['done'] >= (int) $job['total'];
		if ( $job['finished'] ) {
			delete_transient( self::key() );
		} else {
			set_transient( self::key(), $job, 2 * HOUR_IN_SECONDS );
		}
		unset( $job['ids'] );
		return $job;
	}

	/**
	 * Relê uma matéria. Só preenche o que falta: nada que o administrador já escreveu é trocado
	 * (o título só muda quando é genérico).
	 *
	 * @return array<string, bool>
	 */
	public static function fix( int $id, bool $unpublish = false ): array {
		$out = array(
			'fixed'  => false,
			'down'   => false,
			'nodate' => false,
		);
		$d = MLCLIP_Model::get( $id );
		if ( ! $d || '' === (string) $d['url'] ) {
			return $out;
		}
		$nodate  = false !== strpos( (string) $d['reasons'], self::NODATE );
		$generic = self::generic_title( (string) $d['title'], (string) $d['host'] );
		$page    = MLCLIP_Extractor::fetch_full( (string) $d['url'], $nodate );
		$new     = $d;
		$reasons = (string) $d['reasons'];
		$retitle = false;
		// 1.1.0 podia gravar "no archive.org desde <hoje>" (cópia feita pelo próprio plugin): sem valor, sai.
		$reasons = (string) preg_replace_callback(
			'/\s*·\s*no archive\.org desde (\d{2})\/(\d{2})\/(\d{4})/u',
			static function ( $m ) {
				$ts = (int) strtotime( $m[3] . '-' . $m[2] . '-' . $m[1] );
				return $ts && $ts > time() - 30 * DAY_IN_SECONDS ? '' : $m[0];
			},
			$reasons
		);
		$changed = $reasons !== (string) $d['reasons'];

		if ( '' === (string) $d['image'] && '' !== (string) $page['image'] ) {
			$new['image'] = (string) $page['image'];
			$changed      = true;
		}
		if ( $generic && '' === (string) $page['title'] && '' !== MLCLIP_Extractor::title_from_url( (string) $d['url'] ) ) {
			$new['title'] = MLCLIP_Extractor::title_from_url( (string) $d['url'] );
			$changed      = true;
			$retitle      = true;
			if ( false === strpos( $reasons, 'Título não encontrado' ) ) {
				$reasons .= ' · ' . __( 'Título não encontrado; confira', 'ml-clipping-pro' );
			}
		}
		if ( $generic && '' !== (string) $page['title'] ) {
			$t = MLCLIP_Extractor::strip_outlet( (string) $page['title'], (string) $page['outlet'], (string) $page['host'] );
			if ( '' !== $t && ! self::generic_title( $t, (string) $d['host'] ) ) {
				$new['title'] = $t;
				$changed      = true;
			}
		}
		if ( '' === (string) $d['excerpt'] && '' !== (string) $page['excerpt'] ) {
			$new['excerpt'] = (string) $page['excerpt'];
			$changed        = true;
		}
		// Data nova só se for anterior à atual: matéria sem data guardava o dia da importação,
		// e uma data igual ou mais nova que essa é cabeçalho de site ou cópia recente, não a da matéria.
		if ( $nodate && (int) $page['date'] && (int) $page['date'] < (int) $d['date'] - DAY_IN_SECONDS ) {
			$new['date'] = (int) $page['date'];
			$changed     = true;
			if ( 'archive' === $page['date_note'] ) {
				// Só um limite (a matéria é dessa data ou anterior): continua com "Confira a data".
				if ( false === strpos( $reasons, 'archive.org desde' ) ) {
					/* translators: %s: date. */
					$reasons .= ' · ' . sprintf( __( 'no archive.org desde %s', 'ml-clipping-pro' ), wp_date( 'd/m/Y', (int) $page['date'] ) );
				}
			} else {
				$reasons = trim( str_replace( ' · ' . self::NODATE . '; confira', '', $reasons ) ) . ' · ' . __( 'Data lida da matéria', 'ml-clipping-pro' );
				$nodate  = false;
			}
		}
		if ( $page['dead'] ) {
			$new['link'] = 'down';
			if ( '' !== (string) $page['archive_url'] && '' === (string) $d['archive_url'] ) {
				$new['archive'] = (string) $page['archive_url'];
			}
			$out['down'] = true;
			$changed     = true;
			// Fora do ar e sem cópia no archive.org: o link não leva a lugar nenhum, sai do site.
			if ( '' === (string) $page['archive_url'] && '' === (string) $d['archive_url'] ) {
				if ( false === strpos( $reasons, 'sem cópia' ) ) {
					$reasons .= ' · ' . __( 'Fora do ar e sem cópia; confira', 'ml-clipping-pro' );
				}
				if ( 'publish' === $d['status'] ) {
					MLCLIP_Model::set_status( $id, 'pending' );
				}
			}
		}
		if ( $nodate ) {
			$out['nodate'] = true;
		}
		// Só com a caixa marcada: sai do site o que segue sem data ou ficou com título provisório.
		if ( $unpublish && ( $nodate || $retitle ) && 'publish' === $d['status'] ) {
			MLCLIP_Model::set_status( $id, 'pending' );
		}
		if ( ! $changed ) {
			return $out;
		}
		$new['reasons'] = $reasons;
		$new['names'] = array_keys( (array) $d['names'] );
		$new['status'] = (string) get_post_status( $id );
		$res          = MLCLIP_Model::save( $new, $id );
		$out['fixed'] = ! is_wp_error( $res );
		return $out;
	}
}
