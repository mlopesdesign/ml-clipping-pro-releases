<?php
/**
 * Aviso de matéria nova: e-mail (no máximo 1 por dia, nunca vazio), contador vermelho no
 * menu e na barra superior do WordPress e faixa no Painel do wp-admin.
 *
 * @package MLClippingPro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class MLCLIP_Notify {

	private const LAST_EMAIL = 'mlclip_last_email';

	/**
	 * Ganchos.
	 */
	public static function hooks(): void {
		add_action( 'admin_bar_menu', array( __CLASS__, 'admin_bar' ), 85 );
		add_action( 'admin_notices', array( __CLASS__, 'dashboard_notice' ) );
		add_action( 'wp_head', array( __CLASS__, 'bar_style' ) );
		add_action( 'admin_head', array( __CLASS__, 'bar_style' ) );
	}

	/**
	 * Fim de uma rodada: manda o resumo se houver matéria nova desde o último aviso
	 * (inclusive as que ficaram para depois por causa do limite de 1 e-mail por dia).
	 */
	public static function after_run(): void {
		if ( ! MLCLIP_Settings::on( 'notify_email' ) ) {
			return;
		}
		$last = (int) get_option( self::LAST_EMAIL, 0 );
		if ( $last && ( time() - $last ) < 20 * HOUR_IN_SECONDS ) {
			return; // Já mandou hoje: as novas entram no próximo e-mail.
		}
		self::send_digest( $last );
	}

	/**
	 * Monta e envia o e-mail com as matérias que chegaram à fila desde o último aviso.
	 *
	 * @return bool|\WP_Error Enviado?
	 */
	public static function send_digest( int $since = 0, bool $test = false ) {
		$items = get_posts(
			array(
				'post_type'      => MLCLIP_Model::TYPE,
				'post_status'    => ( MLCLIP_Settings::on( 'auto_publish' ) || MLCLIP_Settings::get( 'auto_outlets' ) ) ? array( 'pending', 'publish' ) : 'pending',
				'posts_per_page' => 60,
				'no_found_rows'  => true,
				'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
					array(
						'key'     => '_mlclip_origin',
						'value'   => array( 'import', 'manual' ),
						'compare' => 'NOT IN',
					),
					array(
						'key'     => '_mlclip_found_at',
						'value'   => $since,
						'compare' => '>',
						'type'    => 'NUMERIC',
					),
				),
			)
		);
		if ( ! $items && ! $test ) {
			return false;
		}
		$rows = array();
		foreach ( $items as $p ) {
			$d = MLCLIP_Model::get( $p );
			if ( $d ) {
				$rows[] = $d;
			}
		}
		usort(
			$rows,
			static function ( $a, $b ) {
				return $b['score'] <=> $a['score'];
			}
		);
		$total = MLCLIP_Model::pending_count();
		$to    = (array) MLCLIP_Settings::get( 'notify_to' );
		if ( ! $to ) {
			return new \WP_Error( 'mlclip_mail_to', __( 'Informe pelo menos um e-mail para os avisos.', 'ml-clipping-pro' ) );
		}
		$site = wp_specialchars_decode( (string) get_bloginfo( 'name' ), ENT_QUOTES );
		if ( $test && ! $rows ) {
			/* translators: %s: site name. */
			$subject = sprintf( __( '[%s] Teste do aviso do clipping', 'ml-clipping-pro' ), $site );
		} else {
			/* translators: 1: site name, 2: count. */
			$subject = sprintf( _n( '[%1$s] %2$d matéria nova no clipping', '[%1$s] %2$d matérias novas no clipping', count( $rows ), 'ml-clipping-pro' ), $site, count( $rows ) );
		}
		$html = self::email_html( $rows, $total, $test );
		$sent = wp_mail( $to, $subject, $html, array( 'Content-Type: text/html; charset=UTF-8' ) );
		if ( ! $sent ) {
			return new \WP_Error( 'mlclip_mail', __( 'O WordPress não conseguiu enviar o e-mail. Confira o envio de e-mails do site (SMTP).', 'ml-clipping-pro' ) );
		}
		if ( ! $test ) {
			update_option( self::LAST_EMAIL, time(), false );
		}
		return true;
	}

	/**
	 * Corpo do e-mail (HTML simples, compatível com os leitores de e-mail).
	 *
	 * @param array<int, array<string, mixed>> $rows Matérias.
	 */
	private static function email_html( array $rows, int $total, bool $test ): string {
		$review = MLCLIP_Helpers::admin_url( 'review' );
		$site   = (string) get_bloginfo( 'name' );
		$bands  = array(
			'alta'  => '#0e7a37',
			'media' => '#b54708',
			'baixa' => '#6b7280',
		);
		ob_start();
		?>
		<div style="margin:0;padding:24px 12px;background:#f4f1ea;font-family:Georgia,'Times New Roman',serif;color:#1a1a1a">
			<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:640px;margin:0 auto;background:#fffdf8;border:1px solid #d9d2c3">
				<tr><td style="padding:22px 28px 14px;border-bottom:3px double #1a1a1a;text-align:center">
					<div style="font:600 11px/1.4 Arial,sans-serif;letter-spacing:.14em;text-transform:uppercase;color:#6b6457"><?php echo esc_html( $site ); ?></div>
					<div style="font-size:30px;font-weight:700;line-height:1.15;margin-top:4px"><?php esc_html_e( 'Clipping', 'ml-clipping-pro' ); ?></div>
					<div style="font:12px/1.5 Arial,sans-serif;color:#6b6457;margin-top:6px"><?php echo esc_html( wp_date( get_option( 'date_format', 'd/m/Y' ) ) ); ?> · <?php echo esc_html( sprintf( /* translators: %d: total. */ _n( '%d matéria aguardando sua revisão', '%d matérias aguardando sua revisão', $total, 'ml-clipping-pro' ), $total ) ); ?></div>
				</td></tr>
				<?php if ( $test && ! $rows ) : ?>
					<tr><td style="padding:22px 28px;font:15px/1.6 Arial,sans-serif"><?php esc_html_e( 'Este é um e-mail de teste do ML Clipping Pro. Quando a busca encontrar matérias novas, elas aparecem aqui, com a nota de relevância.', 'ml-clipping-pro' ); ?></td></tr>
				<?php endif; ?>
				<?php foreach ( $rows as $r ) : ?>
					<?php $band = MLCLIP_Model::band( (int) $r['score'] ); ?>
					<tr><td style="padding:16px 28px;border-bottom:1px solid #e6dfd0">
						<div style="font:700 11px/1.4 Arial,sans-serif;letter-spacing:.08em;text-transform:uppercase;color:#6b6457">
							<?php echo esc_html( (string) $r['outlet'] ); ?> · <?php echo esc_html( MLCLIP_Helpers::show_date( (int) $r['date'] ) ); ?>
							<span style="display:inline-block;margin-left:6px;padding:1px 8px;border-radius:10px;background:<?php echo esc_attr( $bands[ $band ] ); ?>;color:#fff;letter-spacing:0"><?php echo esc_html( MLCLIP_Model::band_label( (int) $r['score'] ) . ' ' . (int) $r['score'] ); ?></span>
						</div>
						<a href="<?php echo esc_url( (string) $r['url'] ); ?>" style="display:block;margin-top:6px;font-size:19px;font-weight:700;line-height:1.3;color:#1a1a1a;text-decoration:none"><?php echo esc_html( (string) $r['title'] ); ?></a>
						<?php if ( '' !== (string) $r['excerpt'] ) : ?>
							<div style="margin-top:6px;font:14px/1.55 Arial,sans-serif;color:#3d3a33"><?php echo esc_html( (string) $r['excerpt'] ); ?></div>
						<?php endif; ?>
					</td></tr>
				<?php endforeach; ?>
				<tr><td style="padding:24px 28px;text-align:center">
					<a href="<?php echo esc_url( $review ); ?>" style="display:inline-block;padding:13px 28px;border-radius:999px;background:#1a1a1a;color:#fff;font:700 15px/1 Arial,sans-serif;text-decoration:none"><?php esc_html_e( 'Revisar agora', 'ml-clipping-pro' ); ?></a>
					<div style="margin-top:14px;font:12px/1.5 Arial,sans-serif;color:#6b6457"><?php esc_html_e( 'Nada é publicado no site sem a sua aprovação. Você recebe no máximo um aviso por dia.', 'ml-clipping-pro' ); ?></div>
				</td></tr>
			</table>
		</div>
		<?php
		return (string) ob_get_clean();
	}

	/**
	 * Quem pode revisar.
	 */
	public static function can_review(): bool {
		return current_user_can( MLCLIP_Admin::CAP );
	}

	/**
	 * Contador na barra superior.
	 *
	 * @param \WP_Admin_Bar $bar Barra.
	 */
	public static function admin_bar( $bar ): void {
		if ( ! is_admin_bar_showing() || ! self::can_review() || ! MLCLIP_Settings::on( 'notify_admin' ) ) {
			return;
		}
		$count = MLCLIP_Model::pending_count();
		if ( $count < 1 ) {
			return;
		}
		$bar->add_node(
			array(
				'id'    => 'mlclip-pending',
				'title' => '<span class="ab-icon mlclip-ab-icon" aria-hidden="true"></span><span class="ab-label">' . esc_html__( 'Clipping', 'ml-clipping-pro' ) . '</span> <span class="mlclip-ab-count">' . (int) $count . '</span>',
				'href'  => MLCLIP_Helpers::admin_url( 'review' ),
				'meta'  => array(
					/* translators: %d: count. */
					'title' => sprintf( _n( '%d matéria nova aguardando revisão', '%d matérias novas aguardando revisão', $count, 'ml-clipping-pro' ), $count ),
				),
			)
		);
	}

	/**
	 * Estilo do contador da barra (só quando aparece).
	 */
	public static function bar_style(): void {
		if ( ! is_admin_bar_showing() || ! self::can_review() || ! MLCLIP_Settings::on( 'notify_admin' ) || MLCLIP_Model::pending_count() < 1 ) {
			return;
		}
		echo '<style id="mlclip-ab">#wpadminbar #wp-admin-bar-mlclip-pending .mlclip-ab-count{display:inline-block;min-width:18px;height:18px;margin-left:4px;padding:0 5px;border-radius:9px;background:#d63638;color:#fff;font-size:11px;font-weight:600;line-height:18px;text-align:center;vertical-align:middle}#wpadminbar #wp-admin-bar-mlclip-pending .mlclip-ab-icon:before{content:"\f497";top:2px}</style>' . "\n";
	}

	/**
	 * Faixa no Painel (tela inicial) do wp-admin.
	 */
	public static function dashboard_notice(): void {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen || 'dashboard' !== $screen->id || ! self::can_review() || ! MLCLIP_Settings::on( 'notify_admin' ) ) {
			return;
		}
		$count = MLCLIP_Model::pending_count();
		if ( $count < 1 ) {
			return;
		}
		printf(
			'<div class="notice notice-info"><p><strong>%1$s</strong> %2$s <a class="button button-primary" style="margin-left:8px" href="%3$s">%4$s</a></p></div>',
			esc_html__( 'ML Clipping Pro:', 'ml-clipping-pro' ),
			/* translators: %d: count. */
			esc_html( sprintf( _n( '%d matéria nova aguardando revisão.', '%d matérias novas aguardando revisão.', $count, 'ml-clipping-pro' ), $count ) ),
			esc_url( MLCLIP_Helpers::admin_url( 'review' ) ),
			esc_html__( 'Revisar agora', 'ml-clipping-pro' )
		);
	}
}
