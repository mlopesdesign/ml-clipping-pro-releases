<?php
/**
 * Layout de jornal: cabeçalho (nome do jornal), filtros, seções por mês ou ano,
 * manchete em destaque e colunas com filete vertical. Mesmo HTML no site, no bloco
 * do editor e no ML Builder.
 *
 * @package MLClippingPro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class MLCLIP_Render {

	/**
	 * Atributos aceitos (shortcode/bloco/ML Builder) com os padrões vindos da Aparência.
	 *
	 * @param array<string, mixed> $atts Atributos.
	 * @return array<string, mixed>
	 */
	public static function atts( array $atts ): array {
		$s   = MLCLIP_Settings::all();
		$yes = static function ( $v, $def ) {
			if ( null === $v || '' === $v ) {
				return '1' === (string) $def;
			}
			return in_array( strtolower( (string) $v ), array( '1', 'sim', 'yes', 'true', 'on' ), true );
		};
		$names = array();
		foreach ( preg_split( '/[\s,]+/', (string) ( $atts['nomes'] ?? '' ) ) as $slug ) {
			$slug = sanitize_title( $slug );
			if ( '' !== $slug ) {
				$names[] = $slug;
			}
		}
		$accent = MLCLIP_Helpers::color( $atts['cor'] ?? '' );
		return array(
			'nomes'      => array_slice( array_unique( $names ), 0, 30 ),
			'titulo'     => isset( $atts['titulo'] ) && '' !== trim( (string) $atts['titulo'] ) ? sanitize_text_field( (string) $atts['titulo'] ) : (string) $s['paper_title'],
			'subtitulo'  => isset( $atts['subtitulo'] ) ? sanitize_text_field( (string) $atts['subtitulo'] ) : (string) $s['paper_subtitle'],
			'colunas'    => MLCLIP_Helpers::int_range( $atts['colunas'] ?? $s['columns'], 1, 4, (int) $s['columns'] ),
			'por_pagina' => MLCLIP_Helpers::int_range( $atts['por_pagina'] ?? $s['per_page'], 3, 100, (int) $s['per_page'] ),
			'agrupar'    => MLCLIP_Helpers::choice( $atts['agrupar'] ?? $s['group'], array( 'auto', 'month', 'year', 'mes', 'ano' ), (string) $s['group'] ),
			'filtros'    => $yes( $atts['filtros'] ?? null, $s['filters'] ),
			'manchete'   => $yes( $atts['manchete'] ?? null, $s['headline'] ),
			'imagens'    => $yes( $atts['imagens'] ?? null, $s['images'] ),
			'resumo'     => $yes( $atts['resumo'] ?? null, $s['excerpt'] ),
			'cabecalho'  => $yes( $atts['cabecalho'] ?? null, '1' ),
			'cor'        => '' !== $accent ? $accent : (string) $s['accent'],
		);
	}

	/**
	 * Filtros escolhidos pelo visitante (GET), validados.
	 *
	 * @param array<string, mixed> $src Fonte (normalmente $_GET).
	 * @return array{nome:string,ano:int,veiculo:string,tipo:string}
	 */
	public static function filters( array $src ): array {
		return array(
			'nome'    => isset( $src['mlclip_nome'] ) ? sanitize_title( wp_unslash( (string) $src['mlclip_nome'] ) ) : '',
			'ano'     => ! empty( $src['mlclip_ano'] ) && (int) $src['mlclip_ano'] >= 1990 && (int) $src['mlclip_ano'] <= 2100 ? (int) $src['mlclip_ano'] : 0,
			'veiculo' => isset( $src['mlclip_veiculo'] ) ? sanitize_text_field( wp_unslash( (string) $src['mlclip_veiculo'] ) ) : '',
			'tipo'    => isset( $src['mlclip_tipo'] ) ? MLCLIP_Helpers::choice( wp_unslash( (string) $src['mlclip_tipo'] ), array( 'texto', 'video' ), '' ) : '',
		);
	}

	/**
	 * Consulta das matérias aprovadas.
	 *
	 * @param array<string, mixed> $a Atributos.
	 * @param array<string, mixed> $f Filtros.
	 */
	private static function query( array $a, array $f, int $page ): \WP_Query {
		$args = array(
			'post_type'           => MLCLIP_Model::TYPE,
			'post_status'         => 'publish',
			'posts_per_page'      => (int) $a['por_pagina'],
			'paged'               => max( 1, $page ),
			'orderby'             => 'date',
			'order'               => 'DESC',
			'ignore_sticky_posts' => true,
			'suppress_filters'    => true,
		);
		$tax  = array();
		if ( $a['nomes'] ) {
			$tax[] = array(
				'taxonomy' => MLCLIP_Model::TAX,
				'field'    => 'slug',
				'terms'    => $a['nomes'],
			);
		}
		if ( '' !== $f['nome'] && ( ! $a['nomes'] || in_array( $f['nome'], $a['nomes'], true ) ) ) {
			$tax[] = array(
				'taxonomy' => MLCLIP_Model::TAX,
				'field'    => 'slug',
				'terms'    => array( $f['nome'] ),
			);
		}
		if ( $tax ) {
			$args['tax_query'] = array_merge( array( 'relation' => 'AND' ), $tax ); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
		}
		$meta = array();
		if ( '' !== $f['veiculo'] ) {
			$meta[] = array(
				'key'   => '_mlclip_outlet',
				'value' => $f['veiculo'],
			);
		}
		if ( 'video' === $f['tipo'] ) {
			$meta[] = array(
				'key'   => '_mlclip_media',
				'value' => 'video',
			);
		} elseif ( 'texto' === $f['tipo'] ) {
			$meta[] = array(
				'relation' => 'OR',
				array(
					'key'   => '_mlclip_media',
					'value' => 'texto',
				),
				array(
					'key'     => '_mlclip_media',
					'compare' => 'NOT EXISTS',
				),
			);
		}
		if ( $meta ) {
			$args['meta_query'] = $meta; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
		}
		if ( $f['ano'] ) {
			$args['date_query'] = array( array( 'year' => $f['ano'] ) );
		}
		return new \WP_Query( $args );
	}

	/**
	 * Opções dos filtros (anos e veículos existentes).
	 *
	 * @param array<string, mixed> $a Atributos.
	 * @return array{years:array<int,int>,outlets:array<int,string>,names:array<string,string>,total:int,updated:int}
	 */
	private static function facets( array $a ): array {
		global $wpdb;
		$cache_key = 'mlclip_facets_' . md5( implode( ',', $a['nomes'] ) . '|' . (int) get_option( 'mlclip_cache_v', 1 ) );
		$cached    = get_transient( $cache_key );
		if ( is_array( $cached ) ) {
			return $cached;
		}
		$join  = '';
		$where = $wpdb->prepare( 'p.post_type = %s AND p.post_status = %s', MLCLIP_Model::TYPE, 'publish' );
		if ( $a['nomes'] ) {
			$slugs        = array_map( 'sanitize_title', $a['nomes'] );
			$placeholders = implode( ',', array_fill( 0, count( $slugs ), '%s' ) );
			$join         = " INNER JOIN {$wpdb->term_relationships} tr ON tr.object_id = p.ID INNER JOIN {$wpdb->term_taxonomy} tt ON tt.term_taxonomy_id = tr.term_taxonomy_id INNER JOIN {$wpdb->terms} t ON t.term_id = tt.term_id";
			// phpcs:ignore WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$where       .= $wpdb->prepare( " AND tt.taxonomy = %s AND t.slug IN ($placeholders)", array_merge( array( MLCLIP_Model::TAX ), $slugs ) );
		}
		// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $join/$where montados acima com prepare().
		$years   = array_map( 'intval', (array) $wpdb->get_col( "SELECT DISTINCT YEAR(p.post_date) y FROM {$wpdb->posts} p{$join} WHERE {$where} ORDER BY y DESC" ) );
		$per_mon = array_map( 'intval', (array) $wpdb->get_col( "SELECT COUNT(DISTINCT p.ID) FROM {$wpdb->posts} p{$join} WHERE {$where} GROUP BY DATE_FORMAT(p.post_date, '%Y-%m')" ) );
		$months  = count( $per_mon );
		$outlets = (array) $wpdb->get_col( "SELECT DISTINCT pm.meta_value FROM {$wpdb->posts} p{$join} INNER JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID AND pm.meta_key = '_mlclip_outlet' WHERE {$where} AND pm.meta_value <> '' ORDER BY pm.meta_value ASC LIMIT 300" );
		$total   = (int) $wpdb->get_var( "SELECT COUNT(DISTINCT p.ID) FROM {$wpdb->posts} p{$join} WHERE {$where}" );
		$updated = (int) strtotime( (string) $wpdb->get_var( "SELECT MAX(p.post_modified_gmt) FROM {$wpdb->posts} p{$join} WHERE {$where}" ) . ' UTC' );
		// phpcs:enable
		$names = array();
		$terms = get_terms(
			array(
				'taxonomy'   => MLCLIP_Model::TAX,
				'hide_empty' => true,
				'slug'       => $a['nomes'] ? $a['nomes'] : '',
			)
		);
		if ( ! is_wp_error( $terms ) ) {
			foreach ( $terms as $t ) {
				$names[ $t->slug ] = $t->name;
			}
		}
		$out = array(
			'years'   => $years,
			'outlets' => $outlets,
			'names'   => $names,
			'total'   => $total,
			'months'  => $months,
			'per_mon' => $per_mon,
			'updated' => $updated > 0 ? $updated : 0,
		);
		set_transient( $cache_key, $out, 6 * HOUR_IN_SECONDS );
		return $out;
	}

	/**
	 * Limpa os caches do site (chamado quando matérias mudam).
	 */
	public static function bump_cache(): void {
		update_option( 'mlclip_cache_v', (int) get_option( 'mlclip_cache_v', 1 ) + 1, false );
	}

	/**
	 * HTML completo do jornal.
	 *
	 * @param array<string, mixed> $raw Atributos crus.
	 * @param array<string, mixed> $get Filtros (GET).
	 */
	public static function paper( array $raw, array $get = array(), bool $editor = false ): string {
		$a     = self::atts( $raw );
		$f     = self::filters( $get );
		$page  = isset( $get['mlclip_pg'] ) ? max( 1, absint( $get['mlclip_pg'] ) ) : 1;
		$q     = self::query( $a, $f, $page );
		$fx    = self::facets( $a );
		if ( 'auto' === $a['agrupar'] ) {
			// Decide uma vez para o jornal inteiro (o "Carregar mais" usa a mesma escolha).
			// Por mês só quando a maioria dos meses enche pelo menos uma linha inteira; senão por ano
			// (evita um mês com 1 matéria sozinha atrás do outro).
			$full = 0;
			foreach ( (array) ( $fx['per_mon'] ?? array() ) as $count ) {
				if ( (int) $count >= (int) $a['colunas'] ) {
					$full++;
				}
			}
			$a['agrupar'] = ( ! empty( $fx['months'] ) && $full / $fx['months'] >= 0.6 ) ? 'month' : 'year';
		}
		$uid   = 'mlclip-' . substr( md5( wp_json_encode( $raw ) ), 0, 8 );
		$style = '--mlclip-cols:' . (int) $a['colunas'] . ';' . ( '' !== $a['cor'] ? '--mlclip-accent:' . $a['cor'] . ';' : '' );
		$cls   = 'mlclip-paper' . ( MLCLIP_Settings::on( 'serif' ) ? ' is-serif' : '' ) . ( $editor ? ' is-editor' : '' );
		$data  = array(
			'atts'    => array_merge( array_intersect_key( $raw, array_flip( array( 'nomes', 'titulo', 'subtitulo', 'colunas', 'por_pagina', 'filtros', 'manchete', 'imagens', 'resumo', 'cabecalho', 'cor' ) ) ), array( 'agrupar' => $a['agrupar'] ) ),
			'filters' => $f,
		);

		ob_start();
		?>
		<div class="<?php echo esc_attr( $cls ); ?>" id="<?php echo esc_attr( $uid ); ?>" style="<?php echo esc_attr( $style ); ?>" data-cols="<?php echo (int) $a['colunas']; ?>" data-mlclip="<?php echo esc_attr( (string) wp_json_encode( $data ) ); ?>">
			<?php if ( $a['cabecalho'] ) : ?>
				<header class="mlclip-mast">
					<div class="mlclip-mast-line">
						<span><?php echo esc_html( (string) get_bloginfo( 'name' ) ); ?></span>
						<span><?php echo esc_html( $fx['updated'] ? sprintf( /* translators: %s: date. */ __( 'Atualizado em %s', 'ml-clipping-pro' ), MLCLIP_Helpers::show_date( $fx['updated'] ) ) : '' ); ?></span>
						<span><?php echo esc_html( sprintf( /* translators: %d: count. */ _n( '%d matéria', '%d matérias', $fx['total'], 'ml-clipping-pro' ), $fx['total'] ) ); ?></span>
					</div>
					<h2 class="mlclip-mast-title"><?php echo esc_html( (string) $a['titulo'] ); ?></h2>
					<?php if ( '' !== (string) $a['subtitulo'] ) : ?>
						<p class="mlclip-mast-sub"><?php echo esc_html( (string) $a['subtitulo'] ); ?></p>
					<?php endif; ?>
				</header>
			<?php endif; ?>

			<?php if ( $a['filtros'] && $fx['total'] > 0 ) : ?>
				<?php self::filter_form( $uid, $a, $f, $fx ); ?>
			<?php endif; ?>

			<div class="mlclip-sections">
				<?php
				if ( ! $q->have_posts() ) {
					echo '<p class="mlclip-empty">' . esc_html( ( '' !== $f['nome'] || $f['ano'] || '' !== $f['veiculo'] || '' !== $f['tipo'] ) ? __( 'Nenhuma matéria com esses filtros.', 'ml-clipping-pro' ) : __( 'Nenhuma matéria publicada ainda.', 'ml-clipping-pro' ) ) . '</p>';
				} else {
					echo self::sections( $q, $a, 1 === $page && $a['manchete'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- HTML montado com esc_* em sections().
				}
				?>
			</div>

			<?php if ( $q->max_num_pages > $page ) : ?>
				<div class="mlclip-more">
					<a class="mlclip-more-btn" href="<?php echo esc_url( add_query_arg( 'mlclip_pg', $page + 1 ) . '#' . $uid ); ?>" data-page="<?php echo (int) ( $page + 1 ); ?>" data-pages="<?php echo (int) $q->max_num_pages; ?>"><?php esc_html_e( 'Carregar mais matérias', 'ml-clipping-pro' ); ?></a>
				</div>
			<?php endif; ?>
		</div>
		<?php
		wp_reset_postdata();
		return (string) ob_get_clean();
	}

	/**
	 * Próxima página (Carregar mais): só as seções.
	 *
	 * @param array<string, mixed> $raw Atributos.
	 * @param array<string, mixed> $f   Filtros.
	 * @return array{html:string,more:bool}
	 */
	public static function more( array $raw, array $f, int $page ): array {
		$a = self::atts( $raw );
		$q = self::query( $a, self::filters( $f ), $page );
		$html = $q->have_posts() ? self::sections( $q, $a, false ) : '';
		wp_reset_postdata();
		return array(
			'html' => $html,
			'more' => $q->max_num_pages > $page,
		);
	}

	/**
	 * Barra de filtros (funciona sem JavaScript; o JS só envia ao mudar).
	 *
	 * @param array<string, mixed> $a  Atributos.
	 * @param array<string, mixed> $f  Filtros.
	 * @param array<string, mixed> $fx Opções.
	 */
	private static function filter_form( string $uid, array $a, array $f, array $fx ): void {
		$keep = array();
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- só preserva parâmetros de leitura da página.
		foreach ( $_GET as $k => $v ) {
			if ( is_string( $v ) && 0 !== strpos( (string) $k, 'mlclip_' ) ) {
				$keep[ sanitize_key( (string) $k ) ] = sanitize_text_field( wp_unslash( $v ) );
			}
		}
		?>
		<form class="mlclip-filters" method="get" action="#<?php echo esc_attr( $uid ); ?>" role="search" aria-label="<?php esc_attr_e( 'Filtrar o clipping', 'ml-clipping-pro' ); ?>">
			<?php foreach ( $keep as $k => $v ) : ?>
				<input type="hidden" name="<?php echo esc_attr( $k ); ?>" value="<?php echo esc_attr( $v ); ?>">
			<?php endforeach; ?>
			<?php if ( count( $fx['names'] ) > 1 ) : ?>
				<label class="mlclip-f"><span><?php esc_html_e( 'Nome', 'ml-clipping-pro' ); ?></span>
					<select name="mlclip_nome">
						<option value=""><?php esc_html_e( 'Todos', 'ml-clipping-pro' ); ?></option>
						<?php foreach ( $fx['names'] as $slug => $label ) : ?>
							<option value="<?php echo esc_attr( (string) $slug ); ?>"<?php selected( $f['nome'], $slug ); ?>><?php echo esc_html( (string) $label ); ?></option>
						<?php endforeach; ?>
					</select>
				</label>
			<?php endif; ?>
			<?php if ( count( $fx['years'] ) > 1 ) : ?>
				<label class="mlclip-f"><span><?php esc_html_e( 'Ano', 'ml-clipping-pro' ); ?></span>
					<select name="mlclip_ano">
						<option value=""><?php esc_html_e( 'Todos', 'ml-clipping-pro' ); ?></option>
						<?php foreach ( $fx['years'] as $y ) : ?>
							<option value="<?php echo (int) $y; ?>"<?php selected( (int) $f['ano'], (int) $y ); ?>><?php echo (int) $y; ?></option>
						<?php endforeach; ?>
					</select>
				</label>
			<?php endif; ?>
			<?php if ( count( $fx['outlets'] ) > 1 ) : ?>
				<label class="mlclip-f"><span><?php esc_html_e( 'Veículo', 'ml-clipping-pro' ); ?></span>
					<select name="mlclip_veiculo">
						<option value=""><?php esc_html_e( 'Todos', 'ml-clipping-pro' ); ?></option>
						<?php foreach ( $fx['outlets'] as $o ) : ?>
							<option value="<?php echo esc_attr( (string) $o ); ?>"<?php selected( $f['veiculo'], $o ); ?>><?php echo esc_html( (string) $o ); ?></option>
						<?php endforeach; ?>
					</select>
				</label>
			<?php endif; ?>
			<label class="mlclip-f"><span><?php esc_html_e( 'Tipo', 'ml-clipping-pro' ); ?></span>
				<select name="mlclip_tipo">
					<option value=""><?php esc_html_e( 'Tudo', 'ml-clipping-pro' ); ?></option>
					<option value="texto"<?php selected( $f['tipo'], 'texto' ); ?>><?php esc_html_e( 'Matérias', 'ml-clipping-pro' ); ?></option>
					<option value="video"<?php selected( $f['tipo'], 'video' ); ?>><?php esc_html_e( 'Vídeos', 'ml-clipping-pro' ); ?></option>
				</select>
			</label>
			<button type="submit" class="mlclip-f-btn"><?php esc_html_e( 'Filtrar', 'ml-clipping-pro' ); ?></button>
			<?php if ( '' !== $f['nome'] || $f['ano'] || '' !== $f['veiculo'] || '' !== $f['tipo'] ) : ?>
				<a class="mlclip-f-clear" href="<?php echo esc_url( remove_query_arg( array( 'mlclip_nome', 'mlclip_ano', 'mlclip_veiculo', 'mlclip_tipo', 'mlclip_pg' ) ) . '#' . $uid ); ?>"><?php esc_html_e( 'Limpar', 'ml-clipping-pro' ); ?></a>
			<?php endif; ?>
		</form>
		<?php
	}

	/**
	 * Seções por mês/ano.
	 *
	 * @param array<string, mixed> $a Atributos.
	 */
	private static function sections( \WP_Query $q, array $a, bool $lead ): string {
		$by_year = in_array( $a['agrupar'], array( 'year', 'ano' ), true );
		$all     = array();
		foreach ( $q->posts as $p ) {
			$d = MLCLIP_Model::get( $p );
			if ( $d ) {
				$all[] = $d;
			}
		}
		$html = '';
		// Manchete: a matéria marcada como destaque mais recente; senão a mais nova com foto.
		if ( $lead && count( $all ) > 2 ) {
			$pick = -1;
			foreach ( $all as $i => $it ) {
				if ( $it['featured'] ) {
					$pick = $i;
					break;
				}
			}
			if ( $pick < 0 && $a['imagens'] ) {
				foreach ( array_slice( $all, 0, 6, true ) as $i => $it ) {
					if ( '' !== (string) $it['image'] ) {
						$pick = $i;
						break;
					}
				}
			}
			$pick  = $pick < 0 ? 0 : $pick;
			$html .= self::item( $all[ $pick ], $a, true );
			array_splice( $all, $pick, 1 );
		}
		if ( 'auto' === $a['agrupar'] && $all ) {
			// Automático: por mês quando cada mês enche pelo menos uma linha; senão por ano.
			$months  = array();
			foreach ( $all as $d ) {
				$months[ wp_date( 'Y-m', $d['date'] ) ] = true;
			}
			$by_year = ( count( $all ) / count( $months ) ) < (int) $a['colunas'];
		}
		$groups = array();
		foreach ( $all as $d ) {
			$key              = $by_year ? wp_date( 'Y', $d['date'] ) : wp_date( 'Y-m', $d['date'] );
			$groups[ $key ][] = $d;
		}
		foreach ( $groups as $key => $items ) {
			$ts    = (int) $items[0]['date'];
			$label = $by_year ? wp_date( 'Y', $ts ) : wp_date( 'F \\d\\e Y', $ts );
			$html .= '<section class="mlclip-sec" data-key="' . esc_attr( (string) $key ) . '">';
			$html .= '<h3 class="mlclip-sec-title"><span>' . esc_html( $label ) . '</span></h3>';
			$html .= '<div class="mlclip-grid">';
			$cols  = (int) $a['colunas'];
			$wide  = self::spans( count( $items ), $cols );
			$wtab  = self::spans( count( $items ), min( 2, $cols ) );
			foreach ( $items as $i => $it ) {
				$html .= self::item( $it, $a, false, $wide[ $i ], $wtab[ $i ] );
			}
			$html .= '</div></section>';
		}
		return $html;
	}

	/**
	 * Largura (em colunas) de cada matéria para a última linha nunca ficar com buraco:
	 * as que sobram na última linha dividem a largura toda (ex.: 3 colunas e 1 sobrando = 1 matéria larga).
	 *
	 * @return array<int, int>
	 */
	public static function spans( int $n, int $cols ): array {
		$out = array_fill( 0, max( 0, $n ), 1 );
		$r   = $cols > 1 ? $n % $cols : 0;
		if ( $r > 0 ) {
			$base  = intdiv( $cols, $r );
			$extra = $cols % $r;
			for ( $k = 0; $k < $r; $k++ ) {
				$out[ $n - $r + $k ] = $base + ( $k < $extra ? 1 : 0 );
			}
		}
		return $out;
	}

	/**
	 * Uma matéria.
	 *
	 * @param array<string, mixed> $d Matéria.
	 * @param array<string, mixed> $a Atributos.
	 */
	private static function item( array $d, array $a, bool $lead, int $span = 1, int $span_tab = 1 ): string {
		$down    = 'down' === (string) $d['link_status'];
		$archive = (string) $d['archive_url'];
		$href    = $down && '' !== $archive ? $archive : (string) $d['url'];
		$target  = MLCLIP_Settings::on( 'new_tab' ) ? ' target="_blank" rel="noopener nofollow"' : ' rel="nofollow"';
		$cls     = 'mlclip-item' . ( $lead ? ' mlclip-lead' : '' ) . ( 'video' === $d['media'] ? ' is-video' : '' ) . ( $down ? ' is-down' : '' );
		$img     = $a['imagens'] && '' !== (string) $d['image'] ? (string) $d['image'] : '';
		if ( $a['imagens'] ) {
			$cls .= ' has-img';
		}
		if ( ! $lead ) {
			$cls .= ( $span > 1 ? ' w-l' : '' ) . ( $span_tab > 1 ? ' w-m' : '' );
		}
		$style = $lead ? '' : ' style="--sl:' . (int) $span . ';--sm:' . (int) $span_tab . '"';

		$out = '<article class="' . esc_attr( $cls ) . '"' . $style . '>';
		if ( $a['imagens'] ) {
			// Sem foto: quadro tipográfico com o nome do veículo (o card nunca fica com espaço vazio).
			$media = '' !== $img
				? '<img src="' . esc_url( $img ) . '" alt="" loading="lazy" decoding="async" referrerpolicy="no-referrer">'
				: self::placeholder( (string) $d['outlet'] );
			$out  .= '<a class="mlclip-fig" href="' . esc_url( $href ) . '"' . $target . ' tabindex="-1" aria-hidden="true" data-outlet="' . esc_attr( (string) $d['outlet'] ) . '">' . $media . ( 'video' === $d['media'] ? '<span class="mlclip-play"></span>' : '' ) . '</a>';
		}
		$out .= '<div class="mlclip-body">';
		$out .= '<div class="mlclip-kicker"><span class="mlclip-outlet">' . esc_html( (string) $d['outlet'] ) . '</span>';
		$out .= '<time datetime="' . esc_attr( gmdate( 'c', (int) $d['date'] ) ) . '">' . esc_html( MLCLIP_Helpers::show_date( (int) $d['date'] ) ) . '</time>';
		if ( 'video' === $d['media'] ) {
			$out .= '<span class="mlclip-tag">' . esc_html__( 'Vídeo', 'ml-clipping-pro' ) . '</span>';
		}
		$out .= '</div>';
		$out .= ( $lead ? '<h3' : '<h4' ) . ' class="mlclip-hl"><a href="' . esc_url( $href ) . '"' . $target . '>' . esc_html( (string) $d['title'] ) . '</a>' . ( $lead ? '</h3>' : '</h4>' );
		if ( $a['resumo'] && '' !== (string) $d['excerpt'] ) {
			$out .= '<p class="mlclip-dek">' . esc_html( (string) $d['excerpt'] ) . '</p>';
		}
		if ( $down ) {
			$out .= '<p class="mlclip-note">' . esc_html( '' !== $archive ? __( 'A matéria saiu do site do veículo; o link abre a cópia arquivada.', 'ml-clipping-pro' ) : __( 'A matéria saiu do site do veículo.', 'ml-clipping-pro' ) ) . '</p>';
		}
		$out .= '</div></article>';
		return $out;
	}

	/**
	 * Quadro no lugar da foto: nome do veículo em tipografia de jornal.
	 */
	public static function placeholder( string $outlet ): string {
		$name = '' !== $outlet ? $outlet : __( 'Clipping', 'ml-clipping-pro' );
		// Nome nunca é quebrado no meio: corpo menor para nomes longos ou sem espaço.
		$len  = function_exists( 'mb_strlen' ) ? mb_strlen( $name ) : strlen( $name );
		$long = 0;
		foreach ( preg_split( '/\s+/u', $name ) as $w ) {
			$long = max( $long, function_exists( 'mb_strlen' ) ? mb_strlen( $w ) : strlen( $w ) );
		}
		$cls = 'mlclip-ph-name';
		if ( $long > 15 || $len > 34 ) {
			$cls .= ' is-xl';
		} elseif ( $long > 10 || $len > 22 ) {
			$cls .= ' is-l';
		}
		return '<span class="mlclip-ph"><span class="mlclip-ph-rule"></span><span class="' . esc_attr( $cls ) . '">' . esc_html( $name ) . '</span><span class="mlclip-ph-rule"></span></span>';
	}
}
