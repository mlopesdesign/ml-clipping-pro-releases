<?php
/**
 * Plugin Name:       ML Clipping Pro
 * Plugin URI:        https://tools.mlopesdesign.com.br/produtos/
 * Description:       Clipping de imprensa automático: procura todo dia as matérias que citam os nomes que você escolher, coloca numa fila para aprovação, avisa por e-mail e mostra tudo no site em layout de jornal, organizado por data.
 * Version:           1.1.2
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            ML Lopes Design
 * Author URI:        https://mlopesdesign.com.br/
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       ml-clipping-pro
 * Domain Path:       /languages
 * Update URI:        https://github.com/mlopesdesign/ml-clipping-pro-releases
 *
 * @package MLClippingPro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'MLCLIP_VERSION', '1.1.2' );
define( 'MLCLIP_FILE', __FILE__ );
define( 'MLCLIP_DIR', plugin_dir_path( __FILE__ ) );
define( 'MLCLIP_URL', plugin_dir_url( __FILE__ ) );
define( 'MLCLIP_BASENAME', plugin_basename( __FILE__ ) );

// Atualizações: repositório PÚBLICO só de releases (o código fica em repositório privado).
define( 'MLCLIP_GITHUB_OWNER', 'mlopesdesign' );
define( 'MLCLIP_GITHUB_REPO', 'ml-clipping-pro-releases' );
define( 'MLCLIP_GITHUB_REPO_URL', 'https://github.com/mlopesdesign/ml-clipping-pro-releases' );

// O cliente de licença é carregado ANTES de qualquer guarda de classe.
require_once MLCLIP_DIR . 'includes/class-ml-license-client.php';
require_once MLCLIP_DIR . 'includes/class-mlclip-helpers.php';
require_once MLCLIP_DIR . 'includes/class-mlclip-settings.php';
require_once MLCLIP_DIR . 'includes/class-mlclip-model.php';
require_once MLCLIP_DIR . 'includes/class-mlclip-names.php';
require_once MLCLIP_DIR . 'includes/class-mlclip-http.php';
require_once MLCLIP_DIR . 'includes/class-mlclip-sources.php';
require_once MLCLIP_DIR . 'includes/class-mlclip-extractor.php';
require_once MLCLIP_DIR . 'includes/class-mlclip-engine.php';
require_once MLCLIP_DIR . 'includes/class-mlclip-notify.php';
require_once MLCLIP_DIR . 'includes/class-mlclip-links.php';
require_once MLCLIP_DIR . 'includes/class-mlclip-importer.php';
require_once MLCLIP_DIR . 'includes/class-mlclip-repair.php';
require_once MLCLIP_DIR . 'includes/class-mlclip-render.php';
require_once MLCLIP_DIR . 'includes/class-mlclip-frontend.php';
require_once MLCLIP_DIR . 'includes/class-mlclip-license.php';
require_once MLCLIP_DIR . 'includes/class-mlclip-admin.php';
require_once MLCLIP_DIR . 'includes/class-mlclip-github-updater.php';
require_once MLCLIP_DIR . 'includes/class-mlclip-plugin.php';

register_activation_hook( __FILE__, array( 'MLCLIP_Plugin', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'MLCLIP_Plugin', 'deactivate' ) );

MLCLIP_Plugin::instance();
